import React, { useState, useEffect } from 'react';
import { cn } from '../../lib/utils';
import { setsRepo } from '../../db/api';
import type { Set } from '../../types';
import { Check } from 'lucide-react';

export function SetRow({ set, index }: { set: Set, index: number }) {
  const [localSet, setLocalSet] = useState(set);

  // Sync local state when prop changes from DB
  useEffect(() => {
    setLocalSet(set);
  }, [set]);

  const handleUpdate = async (field: keyof Set, value: any) => {
    const updated = { ...localSet, [field]: value };
    setLocalSet(updated);
    
    // Auto-save to DB on blur or check
    await setsRepo.update(set.id, { [field]: value });
  };

  const toggleComplete = async () => {
    const newCompleted = !localSet.completed;
    setLocalSet({ ...localSet, completed: newCompleted });
    await setsRepo.update(set.id, { completed: newCompleted });
  };

  return (
    <div className={cn(
      "grid grid-cols-[3fr_3fr_3fr_1fr] gap-2 items-center",
      localSet.completed && "opacity-50"
    )}>
      {/* Weight */}
      <input
        type="number"
        className="w-full bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border-2 border-transparent focus:border-[#5B7CFF] text-center font-mono py-2 rounded-none outline-none appearance-none"
        value={localSet.weight || ''}
        placeholder="0"
        onChange={(e) => setLocalSet({ ...localSet, weight: parseFloat(e.target.value) || 0 })}
        onBlur={(e) => handleUpdate('weight', parseFloat(e.target.value) || 0)}
      />
      
      {/* Reps */}
      <input
        type="number"
        className="w-full bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border-2 border-transparent focus:border-[#5B7CFF] text-center font-mono py-2 rounded-none outline-none appearance-none"
        value={localSet.reps || ''}
        placeholder="0"
        onChange={(e) => setLocalSet({ ...localSet, reps: parseInt(e.target.value) || 0 })}
        onBlur={(e) => handleUpdate('reps', parseInt(e.target.value) || 0)}
      />
      
      {/* RPE */}
      <input
        type="number"
        className="w-full bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border-2 border-transparent focus:border-[#5B7CFF] text-center font-mono py-2 rounded-none outline-none appearance-none"
        value={localSet.rpe || ''}
        placeholder="-"
        onChange={(e) => setLocalSet({ ...localSet, rpe: parseInt(e.target.value) || undefined })}
        onBlur={(e) => handleUpdate('rpe', parseInt(e.target.value) || undefined)}
      />
      
      {/* Complete Button */}
      <button
        onClick={toggleComplete}
        className={cn(
          "w-full h-full flex items-center justify-center border-2 transition-colors",
          localSet.completed 
            ? "bg-[#5B7CFF] border-[#5B7CFF] text-white" 
            : "bg-transparent border-[#111111] dark:border-[#F7F4ED] text-transparent hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10"
        )}
      >
        <Check size={18} strokeWidth={3} className={localSet.completed ? "text-white" : "opacity-20 text-[#111111] dark:text-[#F7F4ED]"} />
      </button>
    </div>
  );
}
