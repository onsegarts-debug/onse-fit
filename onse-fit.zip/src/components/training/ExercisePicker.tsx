import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { H3, Mono } from '../ui/Typography';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { X, Search } from 'lucide-react';

export function ExercisePicker({ onClose, onSelect }: { onClose: () => void, onSelect: (id: string) => void }) {
  const [search, setSearch] = useState('');
  
  const exercises = useLiveQuery(() => {
    return db.exercises.toArray();
  });

  const filtered = exercises?.filter(e => e.name.toLowerCase().includes(search.toLowerCase())) || [];

  return (
    <div className="fixed inset-0 z-50 bg-[#F7F4ED] dark:bg-[#111111] flex flex-col pt-safe">
      <div className="flex items-center justify-between p-4 border-b-2 border-[#111111] dark:border-[#F7F4ED]">
        <H3>SELECT EXERCISE</H3>
        <button onClick={onClose} className="p-2 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10 rounded-full">
          <X size={24} />
        </button>
      </div>
      
      <div className="p-4 border-b border-[#111111]/20 dark:border-[#F7F4ED]/20">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
          <Input 
            className="pl-10 h-10 text-sm" 
            placeholder="Search library..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {filtered.map(ex => (
          <button 
            key={ex.id}
            onClick={() => onSelect(ex.id)}
            className="w-full flex justify-between items-center p-4 border-2 border-[#111111] dark:border-[#F7F4ED] hover:bg-[#111111]/5 dark:hover:bg-[#F7F4ED]/5 text-left"
          >
            <div>
              <div className="font-bold uppercase tracking-tight">{ex.name}</div>
              <Mono className="text-[10px] opacity-60 mt-1">{ex.targetMuscle} • {ex.category}</Mono>
            </div>
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-8 opacity-50">
            <Mono>NO EXERCISES FOUND</Mono>
          </div>
        )}
      </div>
    </div>
  );
}
