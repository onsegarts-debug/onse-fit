import React, { useState, useEffect } from 'react';
import { Mono } from '../ui/Typography';
import { Button } from '../ui/Button';
import { Play, Square, Plus, Minus } from 'lucide-react';
import { cn } from '../../lib/utils';

export function RestTimer() {
  const [isActive, setIsActive] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(90); // default 90s
  const [initialSeconds, setInitialSeconds] = useState(90);

  useEffect(() => {
    let interval: any;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => setSecondsLeft(s => s - 1), 1000);
    } else if (secondsLeft === 0) {
      setIsActive(false);
      // Here you could trigger a native notification if supported, or a beep.
    }
    return () => clearInterval(interval);
  }, [isActive, secondsLeft]);

  const toggle = () => {
    if (secondsLeft === 0) setSecondsLeft(initialSeconds);
    setIsActive(!isActive);
  };
  
  const reset = () => {
    setIsActive(false);
    setSecondsLeft(initialSeconds);
  };
  
  const adjust = (amount: number) => {
    const newInitial = Math.max(30, initialSeconds + amount);
    setInitialSeconds(newInitial);
    if (!isActive) setSecondsLeft(newInitial);
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] pb-safe z-40">
      <div className="max-w-md mx-auto p-4 flex items-center justify-between">
        
        <div className="flex flex-col">
          <Mono className="text-[10px] opacity-60 mb-1">REST TIMER</Mono>
          <div className="flex items-center gap-4">
            <button onClick={() => adjust(-30)} className="p-1 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10 rounded">
              <Minus size={16} />
            </button>
            <Mono className={cn("text-3xl font-bold tracking-tighter", isActive && "text-[#5B7CFF]")}>
              {formatTime(secondsLeft)}
            </Mono>
            <button onClick={() => adjust(30)} className="p-1 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10 rounded">
              <Plus size={16} />
            </button>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={reset} className="h-10 w-10 border-2 border-[#111111] dark:border-[#F7F4ED]">
            <Square size={16} />
          </Button>
          <Button variant={isActive ? "secondary" : "primary"} size="icon" onClick={toggle} className="h-10 w-10">
            {isActive ? <Square size={16} /> : <Play size={16} className="ml-1" />}
          </Button>
        </div>
        
      </div>
    </div>
  );
}
