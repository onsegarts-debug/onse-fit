import React from 'react';
import { Link } from 'react-router-dom';
import { User } from 'lucide-react';
import { Mono } from '../ui/Typography';

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 h-16 z-50 bg-[#F7F4ED] dark:bg-[#111111] border-b-2 border-[#111111] dark:border-[#F7F4ED]">
      <div className="w-full max-w-md mx-auto h-full px-4 flex items-center justify-between">
        <Link to="/" className="flex flex-col">
          <h1 className="font-sans font-bold text-xl uppercase tracking-tighter leading-none text-[#111111] dark:text-[#F7F4ED]">
            ONSE FIT
          </h1>
          <Mono className="text-[9px] text-[#5B7CFF] font-bold leading-none mt-1">BUILD. TRACK. BECOME.</Mono>
        </Link>
        
        <Link 
          to="/profile" 
          className="w-10 h-10 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] flex items-center justify-center hover:bg-[#111111]/5 dark:hover:bg-[#F7F4ED]/10 transition-colors"
        >
          <User size={18} strokeWidth={2.5} className="text-[#111111] dark:text-[#F7F4ED]" />
        </Link>
      </div>
    </header>
  );
}
