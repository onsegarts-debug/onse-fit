import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Dumbbell, Activity, LineChart, Zap } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Mono } from '../ui/Typography';

export function BottomNav() {
  const navItems = [
    { to: '/', label: 'TRAINING', icon: Dumbbell },
    { to: '/lifestyle', label: 'LIFESTYLE', icon: Activity },
    { to: '/progress', label: 'PROGRESS', icon: LineChart },
    { to: '/smart', label: 'SMART', icon: Zap },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-20 z-50 bg-[#F7F4ED] dark:bg-[#111111] border-t-2 border-[#111111] dark:border-[#F7F4ED] pb-safe">
      <div className="w-full max-w-md mx-auto h-full flex justify-around items-center px-2">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => 
              cn(
                "flex flex-col items-center justify-center w-full h-full gap-1 transition-colors relative",
                isActive ? "text-[#5B7CFF]" : "text-[#111111]/50 dark:text-[#F7F4ED]/50 hover:text-[#111111] dark:hover:text-[#F7F4ED]"
              )
            }
          >
            {({ isActive }) => (
              <>
                {/* Active indicator bar */}
                {isActive && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-1 bg-[#5B7CFF]" />
                )}
                <item.icon size={22} strokeWidth={isActive ? 2.5 : 2} className="mt-1" />
                <Mono className="text-[9px] font-bold mt-1">{item.label}</Mono>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
