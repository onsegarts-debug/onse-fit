import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Header } from './Header';
import { BottomNav } from './BottomNav';
import { AnimatePresence, motion } from 'motion/react';

export function AppShell() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#F7F4ED] text-[#111111] dark:bg-[#111111] dark:text-[#F7F4ED] font-sans selection:bg-[#5B7CFF] selection:text-white pb-20 pt-16">
      <Header />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-md mx-auto relative overflow-x-hidden min-h-[calc(100vh-6rem)]">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
            className="w-full h-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      <BottomNav />
    </div>
  );
}
