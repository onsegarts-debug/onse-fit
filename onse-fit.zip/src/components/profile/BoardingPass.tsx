import React from 'react';
import { cn } from '../../lib/utils';
import { Mono, H3 } from '../ui/Typography';
import { LogbookLabel } from '../ui/LogbookLabel';
import { User, QrCode } from 'lucide-react';

export function BoardingPass({ className }: { className?: string }) {
  return (
    <div 
      className={cn(
        "relative flex flex-col w-full bg-[#F7F4ED] dark:bg-[#111111]",
        "border-2 border-[#111111] dark:border-[#F7F4ED]",
        "shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]",
        className
      )}
    >
      {/* Top Section - Airline branding style */}
      <div className="bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111] p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <User size={18} strokeWidth={2.5} />
          <Mono className="font-bold tracking-widest">ONSE FIT / STATUS</Mono>
        </div>
        <Mono className="opacity-70 text-[10px]">CLASS: ELITE</Mono>
      </div>

      {/* Main Passenger Info */}
      <div className="p-5 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30">
        <div className="flex justify-between items-start mb-6">
          <LogbookLabel label="PASSENGER (NAME)" value="ATHLETE 01" />
          <div className="text-right">
            <Mono className="text-[10px] text-[#111111]/60 dark:text-[#F7F4ED]/60 mb-1 block">FLIGHT DATE</Mono>
            <Mono className="font-bold text-lg">TODAY</Mono>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-y-6 gap-x-4">
          <LogbookLabel label="CURRENT GOAL" value="HYPERTROPHY" />
          <LogbookLabel label="PROGRAM" value="PUSH PULL LEGS" />
          
          <LogbookLabel label="PHASE" value="BLOCK 2 / WK 6" />
          <LogbookLabel label="TRAINING STREAK" value="12 DAYS" />
        </div>
      </div>

      {/* Boarding Footer / Metrics */}
      <div className="p-5 flex items-center justify-between bg-[#111111]/5 dark:bg-[#F7F4ED]/5">
        <div className="flex gap-6">
          <div>
            <Mono className="text-[10px] opacity-60">BODY WEIGHT</Mono>
            <div className="font-bold text-xl uppercase tracking-tighter">82.5 <span className="text-sm text-[#5B7CFF]">KG</span></div>
          </div>
          <div>
            <Mono className="text-[10px] opacity-60">SESSIONS/WK</Mono>
            <div className="font-bold text-xl uppercase tracking-tighter">04 <span className="text-sm text-[#5B7CFF]">/05</span></div>
          </div>
        </div>
        
        <div className="flex flex-col items-end">
          <QrCode size={40} strokeWidth={1.5} className="text-[#111111] dark:text-[#F7F4ED] opacity-80" />
          <Mono className="text-[8px] mt-1 opacity-50 tracking-widest">ID: ONS-8492</Mono>
        </div>
      </div>

      {/* Decorative Cutouts */}
      <div className="absolute top-[80px] -left-3 w-6 h-6 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] z-10" />
      <div className="absolute top-[80px] -right-3 w-6 h-6 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] z-10" />
    </div>
  );
}
