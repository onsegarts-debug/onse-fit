/**
 * ONSE FIT
 * Compact Workout Music Section
 * Embedded in active workout session screen.
 * Displays only relevant information: playlist name, Spotify status, play/open action, and playlist selector.
 */

import React, { useState } from 'react';
import { useSpotify } from '../../lib/spotify/SpotifyContext';
import { Mono } from '../ui/Typography';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Disc3, ExternalLink, Music2, X, Plus, Check } from 'lucide-react';
import { parseSpotifyPlaylistInput } from '../../lib/spotify/spotifyApi';

interface WorkoutMusicSectionProps {
  workoutId: string;
  associatedPlaylistId?: string;
  associatedPlaylistName?: string;
  associatedPlaylistUri?: string;
}

export function WorkoutMusicSection({
  workoutId,
  associatedPlaylistId,
  associatedPlaylistName,
  associatedPlaylistUri
}: WorkoutMusicSectionProps) {
  const { 
    status, 
    playlists, 
    openPlaylist, 
    associatePlaylistWithWorkout, 
    removeWorkoutPlaylist 
  } = useSpotify();

  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [manualName, setManualName] = useState('');
  const [manualError, setManualError] = useState<string | null>(null);

  const hasPlaylist = Boolean(associatedPlaylistName || associatedPlaylistId);

  // Status badge styling
  const getStatusBadge = () => {
    switch (status) {
      case 'connected':
        return <Badge variant="default" className="text-[8px] bg-[#1DB954] text-black border-[#111111] py-0">CONNECTED</Badge>;
      case 'connecting':
        return <Badge variant="outline" className="text-[8px] text-[#5B7CFF] py-0 animate-pulse">CONNECTING</Badge>;
      case 'network_unavailable':
        return <Badge variant="accent2" className="text-[8px] py-0">OFFLINE</Badge>;
      case 'spotify_unavailable':
        return <Badge variant="outline" className="text-[8px] text-amber-500 py-0">SERVICE UNAVAIL</Badge>;
      case 'auth_required':
        return <Badge variant="outline" className="text-[8px] text-amber-500 py-0">RE-AUTH REQ</Badge>;
      case 'permission_denied':
        return <Badge variant="outline" className="text-[8px] text-red-500 py-0">DENIED</Badge>;
      case 'auth_failed':
        return <Badge variant="outline" className="text-[8px] text-red-500 py-0">AUTH FAIL</Badge>;
      default:
        return <Badge variant="outline" className="text-[8px] opacity-60 py-0">STANDBY</Badge>;
    }
  };

  const handleSelectPlaylist = async (playlist: { id: string; name: string; uri: string }) => {
    await associatePlaylistWithWorkout(workoutId, playlist);
    setIsPickerOpen(false);
  };

  const handleRemovePlaylist = async () => {
    await removeWorkoutPlaylist(workoutId);
    setIsPickerOpen(false);
  };

  const handleAddManualPlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    setManualError(null);
    const parsed = parseSpotifyPlaylistInput(manualInput);
    if (!parsed) {
      setManualError('Enter a valid Spotify link (e.g. open.spotify.com/playlist/... or spotify:playlist:...)');
      return;
    }

    const playlistName = manualName.trim() || 'Gym Playlist';
    await associatePlaylistWithWorkout(workoutId, {
      id: parsed.id,
      name: playlistName,
      uri: parsed.uri
    });

    setManualInput('');
    setManualName('');
    setIsPickerOpen(false);
  };

  return (
    <>
      <div 
        id="workout-music-section"
        className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-3 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]"
      >
        <div className="flex items-center justify-between pb-1.5 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15 mb-2">
          <div className="flex items-center gap-2">
            <Disc3 size={15} className="text-[#1DB954]" />
            <Mono className="text-[10px] font-black uppercase tracking-wider text-[#111111] dark:text-[#F7F4ED]">
              WORKOUT MUSIC
            </Mono>
          </div>
          <div className="flex items-center gap-1.5">
            {getStatusBadge()}
          </div>
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0 flex-1">
            {hasPlaylist ? (
              <div className="flex items-center gap-2">
                <Music2 size={14} className="text-[#5B7CFF] shrink-0" />
                <span className="font-sans font-bold text-xs uppercase tracking-tight truncate text-[#111111] dark:text-[#F7F4ED]">
                  {associatedPlaylistName || 'Selected Playlist'}
                </span>
              </div>
            ) : (
              <span className="text-[11px] font-mono text-[#111111]/50 dark:text-[#F7F4ED]/50 italic">
                No playlist assigned
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {hasPlaylist && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => openPlaylist(associatedPlaylistUri || `spotify:playlist:${associatedPlaylistId}`)}
                className="h-7 text-[10px] font-mono font-bold px-2 py-0 flex items-center gap-1 bg-[#1DB954]/10 hover:bg-[#1DB954]/20 border-[#1DB954]/50 text-[#111111] dark:text-[#F7F4ED]"
              >
                OPEN <ExternalLink size={10} />
              </Button>
            )}

            <Button
              variant={hasPlaylist ? "ghost" : "primary"}
              size="sm"
              onClick={() => setIsPickerOpen(true)}
              className="h-7 text-[10px] font-mono font-bold px-2.5 py-0"
            >
              {hasPlaylist ? 'CHANGE' : '+ SELECT'}
            </Button>
          </div>
        </div>
      </div>

      {/* Compact Playlist Selection Modal */}
      {isPickerOpen && (
        <div className="fixed inset-0 z-50 bg-[#111111]/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] text-[#111111] dark:text-[#F7F4ED] p-4 shadow-[6px_6px_0px_0px_#111111] dark:shadow-[6px_6px_0px_0px_#F7F4ED] space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-2">
              <div className="flex items-center gap-2">
                <Disc3 size={18} className="text-[#1DB954]" />
                <h3 className="font-sans font-bold text-sm uppercase tracking-tight">
                  SELECT WORKOUT PLAYLIST
                </h3>
              </div>
              <button 
                onClick={() => setIsPickerOpen(false)}
                className="p-1 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Spotify Connected Playlists */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[120px]">
              <Mono className="text-[9px] uppercase opacity-60 block mb-1">
                {status === 'connected' ? `YOUR SPOTIFY PLAYLISTS (${playlists.length})` : 'SPOTIFY PLAYLISTS'}
              </Mono>

              {status === 'connected' && playlists.length > 0 ? (
                <div className="space-y-1.5">
                  {playlists.map((pl) => {
                    const isSelected = associatedPlaylistId === pl.id;
                    return (
                      <div
                        key={pl.id}
                        onClick={() => handleSelectPlaylist(pl)}
                        className={`p-2 border-2 transition-all flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-[#1DB954] bg-[#1DB954]/10'
                            : 'border-[#111111]/30 dark:border-[#F7F4ED]/30 hover:border-[#111111] dark:hover:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A]'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="font-sans font-bold text-xs truncate uppercase">
                            {pl.name}
                          </div>
                          <Mono className="text-[9px] opacity-60">
                            {pl.tracksTotal} tracks • by {pl.ownerName || 'Spotify'}
                          </Mono>
                        </div>
                        {isSelected && (
                          <div className="text-[#1DB954] pl-2 shrink-0">
                            <Check size={16} strokeWidth={3} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : status === 'connected' && playlists.length === 0 ? (
                <div className="p-4 border border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 text-center">
                  <Mono className="text-xs opacity-60">No playlists found on your Spotify account.</Mono>
                </div>
              ) : (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-left space-y-1">
                  <div className="text-xs font-mono font-bold text-amber-600 dark:text-amber-400">
                    Spotify {status.replace('_', ' ').toUpperCase()}
                  </div>
                  <p className="text-[11px] font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 leading-tight">
                    {status === 'network_unavailable'
                      ? 'Network unavailable. You can still paste or select saved offline playlists.'
                      : 'Connect your Spotify account in Profile > Integrations > Spotify, or paste a playlist link below.'}
                  </p>
                </div>
              )}

              {/* Manual Link / URI Input Form */}
              <form onSubmit={handleAddManualPlaylist} className="pt-3 border-t border-[#111111]/20 dark:border-[#F7F4ED]/20 space-y-2">
                <Mono className="text-[9px] uppercase opacity-60 block">
                  OR LINK PLAYLIST BY SPOTIFY URL / URI
                </Mono>
                <input
                  type="text"
                  placeholder="https://open.spotify.com/playlist/... or spotify:playlist:..."
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-2 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
                />
                <input
                  type="text"
                  placeholder="Custom Name (e.g. Heavy Leg Day)"
                  value={manualName}
                  onChange={(e) => setManualName(e.target.value)}
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-2 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
                />
                {manualError && (
                  <p className="text-[10px] font-mono text-red-500">{manualError}</p>
                )}
                <Button
                  type="submit"
                  variant="outline"
                  size="sm"
                  className="w-full text-xs font-mono font-bold"
                  disabled={!manualInput.trim()}
                >
                  <Plus size={12} /> ATTACH PLAYLIST LINK
                </Button>
              </form>
            </div>

            {hasPlaylist && (
              <div className="pt-2 border-t border-[#111111]/20 dark:border-[#F7F4ED]/20">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleRemovePlaylist}
                  className="w-full text-xs font-mono text-red-500 hover:text-red-600 hover:bg-red-500/10"
                >
                  REMOVE PLAYLIST FROM WORKOUT
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
