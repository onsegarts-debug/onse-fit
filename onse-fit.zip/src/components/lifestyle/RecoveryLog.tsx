import React, { useState, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { sleepRepo, recoveryRepo } from '../../db/api';
import { H3, Mono } from '../ui/Typography';
import { Input } from '../ui/Input';

export function RecoveryLog() {
  const today = new Date().toISOString().split('T')[0];
  
  const sleepEntry = useLiveQuery(() => db.sleepEntries.get({ date: today }));
  const recoveryEntry = useLiveQuery(() => db.recoveryEntries.get({ date: today }));

  const [sleepHours, setSleepHours] = useState('');
  const [soreness, setSoreness] = useState(3);
  const [energy, setEnergy] = useState(3);

  // Sync state when DB updates (only once on load)
  useEffect(() => {
    if (sleepEntry?.durationMinutes) {
      setSleepHours((sleepEntry.durationMinutes / 60).toString());
    }
    if (recoveryEntry) {
      setSoreness(recoveryEntry.soreness);
      setEnergy(recoveryEntry.energy);
    }
  }, [sleepEntry?.id, recoveryEntry?.id]);

  const handleSleepChange = async (val: string) => {
    setSleepHours(val);
    const hrs = parseFloat(val);
    if (isNaN(hrs)) return;
    
    if (sleepEntry) {
      await sleepRepo.update(sleepEntry.id, { durationMinutes: hrs * 60 });
    } else {
      await sleepRepo.create({
        id: crypto.randomUUID(),
        date: today,
        durationMinutes: hrs * 60,
      });
    }
  };

  const handleRecoveryChange = async (field: 'soreness' | 'energy', val: number) => {
    if (field === 'soreness') setSoreness(val);
    if (field === 'energy') setEnergy(val);

    const changes = { [field]: val, rating: 3, stress: 3 }; // defaults for required fields

    if (recoveryEntry) {
      await recoveryRepo.update(recoveryEntry.id, changes);
    } else {
      await recoveryRepo.create({
        id: crypto.randomUUID(),
        date: today,
        ...changes,
        soreness: field === 'soreness' ? val : soreness,
        energy: field === 'energy' ? val : energy,
      });
    }
  };

  return (
    <div className="space-y-6">
      <H3>RECOVERY LOG</H3>
      
      <div className="space-y-4">
        <div>
          <Mono className="text-[10px] opacity-60 mb-2 block">SLEEP (HOURS)</Mono>
          <Input 
            type="number" 
            placeholder="e.g. 7.5" 
            value={sleepHours}
            onChange={(e) => handleSleepChange(e.target.value)}
          />
        </div>

        <div>
          <Mono className="text-[10px] opacity-60 mb-2 block flex justify-between">
            <span>SORENESS</span>
            <span>{soreness}/5</span>
          </Mono>
          <input 
            type="range" 
            min="1" max="5" 
            value={soreness}
            onChange={(e) => handleRecoveryChange('soreness', parseInt(e.target.value))}
            className="w-full accent-[#5B7CFF]"
          />
          <div className="flex justify-between text-[8px] font-mono opacity-50 mt-1">
            <span>NONE</span>
            <span>SEVERE</span>
          </div>
        </div>

        <div>
          <Mono className="text-[10px] opacity-60 mb-2 block flex justify-between">
            <span>ENERGY</span>
            <span>{energy}/5</span>
          </Mono>
          <input 
            type="range" 
            min="1" max="5" 
            value={energy}
            onChange={(e) => handleRecoveryChange('energy', parseInt(e.target.value))}
            className="w-full accent-[#5B7CFF]"
          />
          <div className="flex justify-between text-[8px] font-mono opacity-50 mt-1">
            <span>DEPLETED</span>
            <span>OPTIMAL</span>
          </div>
        </div>
      </div>
    </div>
  );
}
