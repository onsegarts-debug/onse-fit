import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { habitsRepo, habitLogsRepo } from '../../db/api';
import { H3, Mono } from '../ui/Typography';
import { Button } from '../ui/Button';
import { Check, Plus, Trash2 } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Input } from '../ui/Input';

export function HabitTracker() {
  const [isAdding, setIsAdding] = useState(false);
  const [newHabitName, setNewHabitName] = useState('');
  const today = new Date().toISOString().split('T')[0];

  const habits = useLiveQuery(() => db.habits.toArray());
  const logs = useLiveQuery(() => db.habitLogs.where({ date: today }).toArray());

  const handleAddHabit = async () => {
    if (!newHabitName.trim()) return;
    await habitsRepo.create({
      id: crypto.randomUUID(),
      name: newHabitName.trim(),
      createdAt: new Date().toISOString(),
    });
    setNewHabitName('');
    setIsAdding(false);
  };

  const toggleHabit = async (habitId: string) => {
    const existingLog = logs?.find(l => l.habitId === habitId);
    if (existingLog) {
      await habitLogsRepo.update(existingLog.id, { completed: !existingLog.completed });
    } else {
      await habitLogsRepo.create({
        id: crypto.randomUUID(),
        habitId,
        date: today,
        completed: true,
      });
    }
  };

  const deleteHabit = async (habitId: string) => {
    await habitsRepo.delete(habitId);
    // Also delete logs
    const relatedLogs = await db.habitLogs.where({ habitId }).toArray();
    for (const log of relatedLogs) {
      await habitLogsRepo.delete(log.id);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-4">
        <H3>DAILY HABITS</H3>
        <Button variant="ghost" size="sm" onClick={() => setIsAdding(!isAdding)}>
          {isAdding ? 'CANCEL' : <Plus size={18} />}
        </Button>
      </div>

      {isAdding && (
        <div className="flex gap-2 mb-4">
          <Input 
            placeholder="E.g., Drink 3L Water" 
            value={newHabitName}
            onChange={(e) => setNewHabitName(e.target.value)}
            className="flex-1"
          />
          <Button variant="primary" onClick={handleAddHabit}>ADD</Button>
        </div>
      )}

      <div className="space-y-2">
        {habits?.length === 0 ? (
          <Mono className="opacity-50 text-center block py-4">NO HABITS TRACKED</Mono>
        ) : (
          habits?.map(habit => {
            const isCompleted = logs?.find(l => l.habitId === habit.id)?.completed || false;
            return (
              <div 
                key={habit.id}
                className={cn(
                  "flex items-center justify-between p-4 border-2 transition-colors",
                  isCompleted 
                    ? "border-[#5B7CFF] bg-[#5B7CFF]/10 dark:bg-[#5B7CFF]/20" 
                    : "border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]"
                )}
              >
                <div 
                  className="flex items-center gap-4 flex-1 cursor-pointer"
                  onClick={() => toggleHabit(habit.id)}
                >
                  <div className={cn(
                    "w-6 h-6 border-2 flex items-center justify-center transition-colors",
                    isCompleted 
                      ? "border-[#5B7CFF] bg-[#5B7CFF] text-white" 
                      : "border-[#111111] dark:border-[#F7F4ED] text-transparent"
                  )}>
                    <Check size={16} strokeWidth={3} />
                  </div>
                  <span className={cn(
                    "font-bold tracking-tight uppercase",
                    isCompleted ? "opacity-100" : "opacity-80"
                  )}>
                    {habit.name}
                  </span>
                </div>
                <button 
                  onClick={() => deleteHabit(habit.id)}
                  className="p-2 opacity-30 hover:opacity-100 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
