import React from 'react';
import type { RecoveryOverviewData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { HeartPulse, Moon, Zap, Activity, BedDouble, AlertCircle } from 'lucide-react';

interface RecoveryOverviewCardProps {
  recovery: RecoveryOverviewData;
}

export function RecoveryOverviewCard({ recovery }: RecoveryOverviewCardProps) {
  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <HeartPulse size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">RECOVERY & BIOMETRICS OVERVIEW</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            DETERMINISTIC SLEEP, SORENESS, ENERGY & FATIGUE CORRELATION
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs px-2.5 py-1 border-2 border-[#111111] dark:border-[#F7F4ED] bg-white/40 dark:bg-black/40 font-bold">
            READINESS: {recovery.readinessScoreCurrent !== null ? `${recovery.readinessScoreCurrent}/100` : '—'}
          </span>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Moon size={14} />
            <span>7-DAY SLEEP AVG</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {recovery.sleep7DayAvg !== null ? `${recovery.sleep7DayAvg}` : '—'} <span className="text-xs opacity-60">HRS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {recovery.sleep30DayAvg !== null ? `30-day avg: ${recovery.sleep30DayAvg}h` : 'No monthly history'}
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Activity size={14} />
            <span>SORENESS BASELINE</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {recovery.soreness7DayAvg !== null ? `${recovery.soreness7DayAvg}` : '—'} <span className="text-xs opacity-60">/5</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {recovery.energy7DayAvg !== null ? `Energy baseline: ${recovery.energy7DayAvg}/5` : 'No recovery logs'}
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <BedDouble size={14} />
            <span>REST DAYS ALLOCATION</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {recovery.restDaysLast7Days} <span className="text-xs opacity-60">/ 7 DAYS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {recovery.restDaysLast14Days} rest days in past 14 days
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Zap size={14} />
            <span>SLEEP RANGE</span>
          </div>
          <div className="text-sm font-bold font-mono">
            {recovery.sleepMinHours !== null && recovery.sleepMaxHours !== null
              ? `${recovery.sleepMinHours}h – ${recovery.sleepMaxHours}h`
              : '—'}
          </div>
          <Mono className="text-[10px] opacity-60">
            Min to max hours logged
          </Mono>
        </div>
      </div>

      {/* Training Load Fatigue Correlation Section */}
      {recovery.trainingLoadCorrelation.hasCorrelationData && (
        <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3.5 bg-white/40 dark:bg-black/40 space-y-2">
          <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block">
            FATIGUE VS TRAINING LOAD CORRELATION
          </Mono>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
            <div>
              <span className="opacity-60 text-[10px] block">NEXT-DAY SORENESS (HEAVY SESSIONS)</span>
              <span className="font-bold text-base text-amber-600 dark:text-amber-400">
                {recovery.trainingLoadCorrelation.highLoadAvgSoreness}/5
              </span>
            </div>
            <div>
              <span className="opacity-60 text-[10px] block">NEXT-DAY SORENESS (REST/LIGHT DAYS)</span>
              <span className="font-bold text-base">
                {recovery.trainingLoadCorrelation.lowLoadAvgSoreness}/5
              </span>
            </div>
            <div>
              <span className="opacity-60 text-[10px] block">POST-TRAINING FATIGUE DELTA</span>
              <span className="font-bold text-base text-[#5B7CFF]">
                {(recovery.trainingLoadCorrelation.sorenessDelta ?? 0) > 0 ? '+' : ''}
                {recovery.trainingLoadCorrelation.sorenessDelta} rating points
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 14-Day Timeline Table */}
      <div className="space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          14-DAY BIOMETRICS & TRAINING TIMELINE
        </Mono>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs border border-[#111111]/20 dark:border-[#F7F4ED]/20">
            <thead className="bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border-b border-[#111111]/20 dark:border-[#F7F4ED]/20 text-[10px]">
              <tr>
                <th className="p-2">DATE</th>
                <th className="p-2">SLEEP</th>
                <th className="p-2">SORENESS</th>
                <th className="p-2">ENERGY</th>
                <th className="p-2">READINESS</th>
                <th className="p-2 text-right">WORKOUT TONNAGE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#111111]/10 dark:divide-[#F7F4ED]/10">
              {recovery.dailyRecoveryPoints.map((pt) => (
                <tr key={pt.date} className="hover:bg-white/20 dark:hover:bg-black/20">
                  <td className="p-2 font-bold">{pt.date.slice(5)}</td>
                  <td className="p-2">{pt.sleepHours !== null ? `${pt.sleepHours}h` : '—'}</td>
                  <td className="p-2">{pt.soreness !== null ? `${pt.soreness}/5` : '—'}</td>
                  <td className="p-2">{pt.energy !== null ? `${pt.energy}/5` : '—'}</td>
                  <td className="p-2 font-bold text-[#5B7CFF]">
                    {pt.readinessScore !== null ? `${pt.readinessScore}%` : '—'}
                  </td>
                  <td className="p-2 text-right">
                    {pt.hadWorkout ? (
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {pt.workoutVolumeKg.toLocaleString()} kg
                      </span>
                    ) : (
                      <span className="opacity-40">Rest</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Factual Bullets */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL RECOVERY STATEMENTS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {recovery.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
