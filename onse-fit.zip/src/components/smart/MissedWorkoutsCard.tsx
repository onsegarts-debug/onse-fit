import React from 'react';
import type { MissedWorkoutData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { AlertTriangle, CheckCircle2, CalendarX2, Clock, CalendarDays } from 'lucide-react';

interface MissedWorkoutsCardProps {
  missedData: MissedWorkoutData;
}

export function MissedWorkoutsCard({ missedData }: MissedWorkoutsCardProps) {
  const hasMissed = missedData.totalMissedSessions > 0 || missedData.extendedTrainingGaps.length > 0;

  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <CalendarX2 size={18} className={hasMissed ? "text-amber-500" : "text-emerald-500"} />
            <H3 className="text-lg uppercase tracking-tight">SCHEDULE ADHERENCE & MISSED SESSIONS</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            DETERMINISTIC ANALYSIS OF SCHEDULE DEFICITS & TRAINING GAPS
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs px-2.5 py-1 border-2 border-[#111111] dark:border-[#F7F4ED] bg-white/40 dark:bg-black/40 font-bold">
            ADHERENCE: {missedData.overallScheduleAdherencePercent}%
          </span>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">TOTAL DEFICITS</Mono>
          <div className="text-xl font-bold font-mono">
            {missedData.totalMissedSessions} <span className="text-xs opacity-60">SESSIONS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Past uncompleted & weekly gaps
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">SCHEDULED INCOMPLETE</Mono>
          <div className="text-xl font-bold font-mono">
            {missedData.uncompletedScheduledWorkouts.length} <span className="text-xs opacity-60">LOGS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Created but not marked completed
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">WEEKLY DEFICITS</Mono>
          <div className="text-xl font-bold font-mono">
            {missedData.weeklyDeficits.length} <span className="text-xs opacity-60">WEEKS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Fell below frequency target
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">EXTENDED GAPS</Mono>
          <div className="text-xl font-bold font-mono">
            {missedData.extendedTrainingGaps.length} <span className="text-xs opacity-60">EVENTS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            &gt;3 days without training
          </Mono>
        </div>
      </div>

      {/* Missed Sessions & Deficit Logs */}
      <div className="space-y-4">
        {/* 1. Uncompleted Scheduled Sessions */}
        {missedData.uncompletedScheduledWorkouts.length > 0 && (
          <div className="space-y-2">
            <Mono className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase block tracking-wider flex items-center gap-1.5">
              <AlertTriangle size={14} /> PAST SCHEDULED SESSIONS NOT COMPLETED ({missedData.uncompletedScheduledWorkouts.length})
            </Mono>
            <div className="space-y-1.5 font-mono text-xs">
              {missedData.uncompletedScheduledWorkouts.map(w => (
                <div key={w.id} className="border border-amber-500/30 p-2.5 bg-amber-500/5 flex justify-between items-center">
                  <div>
                    <span className="font-bold">{w.name}</span>
                    <span className="text-[10px] opacity-60 block">Scheduled date: {w.scheduledDate}</span>
                  </div>
                  <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 border border-amber-500/20 uppercase">
                    INCOMPLETE
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 2. Concluded Week Target Shortfalls */}
        {missedData.weeklyDeficits.length > 0 && (
          <div className="space-y-2">
            <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider flex items-center gap-1.5">
              <CalendarDays size={14} /> CONCLUDED WEEKS WITH FREQUENCY DEFICITS ({missedData.weeklyDeficits.length})
            </Mono>
            <div className="space-y-1.5 font-mono text-xs">
              {missedData.weeklyDeficits.map((wd, idx) => (
                <div key={idx} className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-2.5 bg-white/40 dark:bg-black/40 flex justify-between items-center">
                  <div>
                    <span className="font-bold">Week of {wd.startDate} to {wd.endDate}</span>
                    <span className="text-[10px] opacity-60 block">
                      Target: {wd.targetSessions} sessions | Completed: {wd.completedSessions} sessions
                    </span>
                  </div>
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                    -{wd.missedSessionsCount} session{wd.missedSessionsCount === 1 ? '' : 's'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 3. Extended Training Gaps */}
        {missedData.extendedTrainingGaps.length > 0 && (
          <div className="space-y-2">
            <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider flex items-center gap-1.5">
              <Clock size={14} /> EXTENDED TRAINING HIATUS EVENTS (&gt;3 DAYS)
            </Mono>
            <div className="space-y-1.5 font-mono text-xs">
              {missedData.extendedTrainingGaps.map((gap, idx) => (
                <div key={idx} className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-2.5 bg-white/40 dark:bg-black/40 flex justify-between items-center">
                  <div>
                    <span className="font-bold">{gap.gapDays} consecutive days without training</span>
                    <span className="text-[10px] opacity-60 block">
                      Interval between {gap.startDate} ({gap.precedingWorkoutName}) and {gap.endDate}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 border border-current/20 opacity-70">
                    GAP: {gap.gapDays}D
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {!hasMissed && (
          <div className="border border-emerald-500/30 p-4 bg-emerald-500/5 flex items-center gap-3">
            <CheckCircle2 size={20} className="text-emerald-500 shrink-0" />
            <div className="font-mono text-xs">
              <span className="font-bold text-emerald-600 dark:text-emerald-400 block">ZERO MISSED SESSIONS</span>
              <span className="opacity-70">
                All scheduled workouts have been completed on time. No weekly target frequency deficits recorded.
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Factual Bullets */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL ADHERENCE STATEMENTS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {missedData.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
