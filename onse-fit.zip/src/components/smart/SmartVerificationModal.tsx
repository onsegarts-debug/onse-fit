import React, { useState } from 'react';
import { 
  runSmartTrackEngineVerificationSuite, 
  type SmartTrackVerificationTest 
} from '../../lib/smartTrackEngine';
import { seedBenchmarkData, clearBenchmarkData } from '../../lib/benchmarkData';
import { H2, Mono } from '../ui/Typography';
import { Button } from '../ui/Button';
import { CheckCircle2, XCircle, Play, Database, Trash2, X, ShieldCheck } from 'lucide-react';

interface SmartVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataChanged?: () => void;
}

export function SmartVerificationModal({ isOpen, onClose, onDataChanged }: SmartVerificationModalProps) {
  const [testResults, setTestResults] = useState<SmartTrackVerificationTest[]>(() => 
    runSmartTrackEngineVerificationSuite()
  );
  const [isSeeding, setIsSeeding] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const runTests = () => {
    const results = runSmartTrackEngineVerificationSuite();
    setTestResults(results);
    setFeedbackMsg('Automated calculation suite verified.');
  };

  const handleSeed = async () => {
    setIsSeeding(true);
    setFeedbackMsg(null);
    try {
      await seedBenchmarkData();
      setFeedbackMsg('4-week benchmark data successfully seeded with training, biometrics, habits, and recovery logs.');
      onDataChanged?.();
    } catch (e) {
      console.error(e);
      setFeedbackMsg('Failed to seed benchmark data.');
    } finally {
      setIsSeeding(false);
    }
  };

  const handleClear = async () => {
    setIsClearing(true);
    setFeedbackMsg(null);
    try {
      await clearBenchmarkData();
      setFeedbackMsg('All benchmark records cleared. Empty states restored.');
      onDataChanged?.();
    } catch (e) {
      console.error(e);
      setFeedbackMsg('Failed to clear benchmark data.');
    } finally {
      setIsClearing(false);
    }
  };

  const passCount = testResults.filter(t => t.passed).length;
  const failCount = testResults.length - passCount;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-[#F7F4ED] dark:bg-[#111111] border-2 border-[#111111] dark:border-[#F7F4ED] shadow-[8px_8px_0px_0px_#111111] dark:shadow-[8px_8px_0px_0px_#F7F4ED] w-full max-w-3xl max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 border-b-2 border-[#111111] dark:border-[#F7F4ED] flex justify-between items-center bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111]">
          <div className="flex items-center gap-2">
            <ShieldCheck size={20} className="text-[#5B7CFF]" />
            <span className="font-mono font-bold text-sm tracking-wider uppercase">
              SMART TRACK ENGINE CALCULATION VERIFICATION
            </span>
          </div>
          <button onClick={onClose} className="p-1 hover:opacity-70">
            <X size={20} />
          </button>
        </div>

        {/* Action Bar */}
        <div className="p-4 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 flex flex-wrap gap-2 justify-between items-center bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <CheckCircle2 size={14} /> {passCount} PASSED
            </span>
            {failCount > 0 && (
              <span className="font-bold text-red-600 flex items-center gap-1">
                <XCircle size={14} /> {failCount} FAILED
              </span>
            )}
            <span className="opacity-50">({testResults.length} assertions total)</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={runTests}
              className="text-xs font-mono flex items-center gap-1.5"
            >
              <Play size={12} /> RE-RUN FORMULA AUDIT
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSeed}
              disabled={isSeeding}
              className="text-xs font-mono flex items-center gap-1.5"
            >
              <Database size={12} /> {isSeeding ? 'SEEDING...' : 'SEED BENCHMARK DATA'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleClear}
              disabled={isClearing}
              className="text-xs font-mono flex items-center gap-1.5 text-red-500 hover:text-red-600"
            >
              <Trash2 size={12} /> {isClearing ? 'CLEARING...' : 'CLEAR DATA'}
            </Button>
          </div>
        </div>

        {feedbackMsg && (
          <div className="px-4 py-2 bg-[#5B7CFF]/10 border-b border-[#5B7CFF]/30 font-mono text-xs text-[#5B7CFF] font-bold">
            {feedbackMsg}
          </div>
        )}

        {/* Test List */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {testResults.map((t, idx) => (
            <div 
              key={idx}
              className={`border p-3 font-mono text-xs ${
                t.passed 
                  ? 'border-emerald-500/40 bg-emerald-500/5' 
                  : 'border-red-500/40 bg-red-500/5'
              }`}
            >
              <div className="flex justify-between items-start gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  {t.passed ? (
                    <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                  ) : (
                    <XCircle size={16} className="text-red-500 shrink-0" />
                  )}
                  <span className="font-bold text-sm">{t.name}</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 border border-current/20 opacity-70 uppercase shrink-0">
                  {t.category}
                </span>
              </div>

              <div className="text-[11px] opacity-80 mb-2 leading-relaxed">
                {t.explanation}
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px] bg-[#111111]/5 dark:bg-[#F7F4ED]/5 p-2 border border-[#111111]/10 dark:border-[#F7F4ED]/10">
                <div>
                  <span className="opacity-50 block">EXPECTED:</span>
                  <span className="font-bold">{JSON.stringify(t.expected)}</span>
                </div>
                <div>
                  <span className="opacity-50 block">ACTUAL:</span>
                  <span className="font-bold text-[#5B7CFF]">{JSON.stringify(t.actual)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t-2 border-[#111111] dark:border-[#F7F4ED] bg-white/40 dark:bg-black/40 flex justify-end">
          <Button variant="primary" size="sm" onClick={onClose} className="font-mono text-xs">
            CLOSE AUDIT REPORT
          </Button>
        </div>
      </div>
    </div>
  );
}
