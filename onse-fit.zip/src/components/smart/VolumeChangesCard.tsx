import React from 'react';
import type { VolumeChangeData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { Layers, TrendingUp, TrendingDown, Minus, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface VolumeChangesCardProps {
  volume: VolumeChangeData;
}

export function VolumeChangesCard({ volume }: VolumeChangesCardProps) {
  const maxVol = Math.max(...volume.weeklyProgressions.map(w => w.volumeKg), 1);

  const getStatusBadge = () => {
    switch (volume.overloadStatus) {
      case 'increasing':
        return (
          <span className="flex items-center gap-1 text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-1 border border-emerald-500/30">
            <TrendingUp size={14} /> PROGRESSIVE OVERLOAD (+{volume.overloadPercentChange}%)
          </span>
        );
      case 'deloading':
        return (
          <span className="flex items-center gap-1 text-xs font-mono font-bold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2.5 py-1 border border-amber-500/30">
            <TrendingDown size={14} /> DELOAD / REDUCED LOAD ({volume.overloadPercentChange}%)
          </span>
        );
      case 'maintaining':
        return (
          <span className="flex items-center gap-1 text-xs font-mono font-bold text-[#5B7CFF] bg-[#5B7CFF]/10 px-2.5 py-1 border border-[#5B7CFF]/30">
            <Minus size={14} /> LOAD MAINTAINING ({volume.overloadPercentChange}%)
          </span>
        );
      default:
        return (
          <span className="text-xs font-mono opacity-60 bg-black/5 dark:bg-white/5 px-2.5 py-1 border border-current/20">
            INSUFFICIENT HISTORICAL DATA
          </span>
        );
    }
  };

  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">VOLUME CHANGES & OVERLOAD</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            DETERMINISTIC WORKLOAD DELTAS (WEEK-OVER-WEEK & MONTH-OVER-MONTH)
          </Mono>
        </div>

        <div>{getStatusBadge()}</div>
      </div>

      {/* Week-over-Week Progression Chart / Columns */}
      <div className="space-y-3">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          WEEK-OVER-WEEK WORKLOAD PROGRESSION
        </Mono>

        {volume.weeklyProgressions.length === 0 ? (
          <div className="border border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 p-4 text-center">
            <Mono className="text-xs opacity-50">Requires at least 1 completed workout to display weekly progression.</Mono>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 pt-2">
            {volume.weeklyProgressions.map((w, idx) => {
              const heightPercent = (w.volumeKg / maxVol) * 100;
              const isPositive = (w.wowDeltaKg ?? 0) >= 0;

              return (
                <div key={idx} className="flex flex-col border border-[#111111]/20 dark:border-[#F7F4ED]/20 bg-white/40 dark:bg-black/40 p-2 text-xs font-mono">
                  <span className="opacity-60 text-[10px] truncate">{w.weekLabel}</span>
                  <div className="font-bold text-sm my-1">{w.volumeKg.toLocaleString()} kg</div>

                  <div className="h-16 w-full bg-[#111111]/5 dark:bg-[#F7F4ED]/5 flex items-end p-1 my-1">
                    <div
                      className="w-full bg-[#5B7CFF] transition-all"
                      style={{ height: `${Math.max(10, heightPercent)}%` }}
                    />
                  </div>

                  <div className="text-[10px] mt-auto">
                    {w.wowDeltaPercent !== null ? (
                      <span className={`flex items-center font-bold ${isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                        {isPositive ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                        {isPositive ? `+${w.wowDeltaPercent}%` : `${w.wowDeltaPercent}%`}
                      </span>
                    ) : (
                      <span className="opacity-50">Baseline</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Month-over-Month Comparison (if available) */}
      {volume.monthOverMonth && (
        <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3 bg-white/40 dark:bg-black/40 space-y-2">
          <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block">
            MONTH-OVER-MONTH TONNAGE COMPARISON
          </Mono>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
            <div>
              <span className="opacity-60 text-[10px] block">{volume.monthOverMonth.currentMonthName.toUpperCase()} VOLUME</span>
              <span className="font-bold text-base">{volume.monthOverMonth.currentMonthVolumeKg.toLocaleString()} KG</span>
            </div>
            <div>
              <span className="opacity-60 text-[10px] block">{volume.monthOverMonth.previousMonthName.toUpperCase()} VOLUME</span>
              <span className="font-bold text-base">{volume.monthOverMonth.previousMonthVolumeKg.toLocaleString()} KG</span>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <span className="opacity-60 text-[10px] block">NET DELTA</span>
              <span className={`font-bold text-base ${volume.monthOverMonth.momDeltaKg >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                {volume.monthOverMonth.momDeltaKg >= 0 ? `+${volume.monthOverMonth.momDeltaKg.toLocaleString()}` : volume.monthOverMonth.momDeltaKg.toLocaleString()} KG 
                ({volume.monthOverMonth.momDeltaKg >= 0 ? `+${volume.monthOverMonth.momDeltaPercent}%` : `${volume.monthOverMonth.momDeltaPercent}%`})
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Muscle Group Delta Breakdown */}
      {volume.muscleGroupDeltas.length > 0 && (
        <div className="space-y-2">
          <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
            MUSCLE GROUP 14-DAY VOLUME DELTAS
          </Mono>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
            {volume.muscleGroupDeltas.map(m => {
              const isGain = m.deltaKg >= 0;
              return (
                <div key={m.category} className="flex justify-between items-center border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-2 bg-white/40 dark:bg-black/40">
                  <div>
                    <span className="font-bold">{m.category.toUpperCase()}</span>
                    <span className="text-[10px] opacity-60 block">{m.recentVolumeKg.toLocaleString()} kg (vs {m.priorVolumeKg.toLocaleString()} kg)</span>
                  </div>
                  <div className="text-right">
                    <span className={`font-bold ${isGain ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                      {isGain ? `+${m.deltaKg.toLocaleString()}` : m.deltaKg.toLocaleString()} kg
                    </span>
                    <span className="text-[10px] opacity-70 block">
                      {isGain ? `+${m.deltaPercent}%` : `${m.deltaPercent}%`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Factual Audit Bullets */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL VOLUME OBSERVATIONS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {volume.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
