import React, { useState } from 'react';
import type { DailySummaryData } from '../../lib/smartTrackEngine';
import { Mono, H3, Body } from '../ui/Typography';
import { Calendar, ChevronLeft, ChevronRight, Dumbbell, Moon, Zap, Activity, CheckSquare, Clock } from 'lucide-react';
import { Button } from '../ui/Button';

interface DailySummaryCardProps {
  summary: DailySummaryData;
  selectedDate: string;
  onDateChange: (date: string) => void;
}

export function DailySummaryCard({ summary, selectedDate, onDateChange }: DailySummaryCardProps) {
  const changeDateByDays = (days: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + days);
    onDateChange(d.toISOString().split('T')[0]);
  };

  const setToday = () => {
    onDateChange(new Date().toISOString().split('T')[0]);
  };

  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header & Date Navigator */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Calendar size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">DAILY SUMMARY</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            {summary.isToday ? 'TODAY’S AUDIT & LOGBOOK' : `AUDIT FOR ${summary.date}`}
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => changeDateByDays(-1)}
            className="p-1.5 h-8 w-8 flex items-center justify-center"
            title="Previous Day"
          >
            <ChevronLeft size={16} />
          </Button>

          <input
            type="date"
            value={selectedDate}
            onChange={(e) => e.target.value && onDateChange(e.target.value)}
            className="bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-2 py-1 font-mono text-xs font-bold"
          />

          <Button
            variant="outline"
            size="sm"
            onClick={() => changeDateByDays(1)}
            className="p-1.5 h-8 w-8 flex items-center justify-center"
            title="Next Day"
          >
            <ChevronRight size={16} />
          </Button>

          {!summary.isToday && (
            <Button
              variant="primary"
              size="sm"
              onClick={setToday}
              className="text-[10px] py-1 px-2.5 h-8 font-mono"
            >
              TODAY
            </Button>
          )}
        </div>
      </div>

      {/* Primary Key Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Dumbbell size={14} />
            <span>SESSION TONNAGE</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {summary.totalDailyVolumeKg.toLocaleString()} <span className="text-xs text-opacity-70">KG</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.totalDailySets} sets / {summary.totalDailyReps} reps
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Moon size={14} />
            <span>SLEEP DURATION</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {summary.sleep ? `${summary.sleep.durationHours}` : '—'} <span className="text-xs text-opacity-70">HRS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.sleep?.quality ? `Quality: ${summary.sleep.quality}/5` : 'No sleep log'}
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Activity size={14} />
            <span>READINESS SCORE</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {summary.readinessScore !== null ? `${summary.readinessScore}` : '—'} 
            <span className="text-xs text-opacity-70">/100</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.recovery ? `Soreness ${summary.recovery.soreness}/5 | Energy ${summary.recovery.energy}/5` : 'No recovery log'}
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <CheckSquare size={14} />
            <span>HABIT ADHERENCE</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {summary.habits.totalHabits > 0 ? `${summary.habits.completionRate}%` : '—'}
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.habits.totalHabits > 0 
              ? `${summary.habits.completedCount}/${summary.habits.totalHabits} completed` 
              : 'No habits configured'}
          </Mono>
        </div>
      </div>

      {/* Workouts Detail Section */}
      <div className="space-y-3">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          WORKOUTS COMPLETED ({summary.workouts.filter(w => w.completed).length})
        </Mono>

        {summary.workouts.length === 0 ? (
          <div className="border border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 p-4 text-center">
            <Mono className="text-xs opacity-50">Zero workout sessions logged or scheduled on this date.</Mono>
          </div>
        ) : (
          summary.workouts.map((w) => (
            <div 
              key={w.id} 
              className="border-2 border-[#111111] dark:border-[#F7F4ED] p-3.5 bg-white/60 dark:bg-black/60 space-y-2.5"
            >
              <div className="flex flex-wrap justify-between items-center gap-2">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${w.completed ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                  <span className="font-bold text-sm uppercase">{w.name}</span>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono">
                  {w.durationMinutes > 0 && (
                    <span className="flex items-center gap-1 opacity-70">
                      <Clock size={12} /> {w.durationMinutes}m
                    </span>
                  )}
                  <span className="font-bold text-[#5B7CFF]">
                    {w.totalVolumeKg.toLocaleString()} KG
                  </span>
                  <span className="opacity-70">
                    {w.totalSets} sets
                  </span>
                </div>
              </div>

              {/* Exercises Performed in this Workout */}
              {w.exercises.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 text-xs font-mono">
                  {w.exercises.map((ex, idx) => (
                    <div key={idx} className="flex justify-between items-center bg-[#111111]/5 dark:bg-[#F7F4ED]/5 px-2.5 py-1.5">
                      <div className="truncate mr-2">
                        <span className="font-bold">{ex.exerciseName}</span>
                        <span className="text-[10px] opacity-60 block">{ex.setsCount} sets ({ex.category})</span>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-bold">{ex.bestSet.weight}kg × {ex.bestSet.reps}</span>
                        <span className="text-[10px] text-[#5B7CFF] block">{ex.volumeKg.toLocaleString()} kg</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Factual Bullet Points */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL AUDIT STATEMENTS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {summary.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
