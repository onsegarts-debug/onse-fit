import React from 'react';
import type { FactualInsightsData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { Cpu, Layers, CalendarCheck, HeartPulse, Trophy } from 'lucide-react';

interface FactualInsightsFeedProps {
  insights: FactualInsightsData;
}

export function FactualInsightsFeed({ insights }: FactualInsightsFeedProps) {
  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Cpu size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">FACTUAL TRAINING INSIGHTS</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            DETERMINISTIC DATA DERIVATIONS — ZERO AI SIMULATION OR MOTIVATIONAL FILLER
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs px-2.5 py-1 border-2 border-[#111111] dark:border-[#F7F4ED] bg-white/40 dark:bg-black/40 font-bold">
            {insights.totalInsightsCount} VERIFIED OBSERVATIONS
          </span>
        </div>
      </div>

      {/* 4 Categorized Insight Blocks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. Volume & Overload */}
        <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3.5 bg-white/40 dark:bg-black/40 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#5B7CFF] border-b border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 pb-1.5">
            <Layers size={14} />
            <span>VOLUME & OVERLOAD</span>
          </div>
          <ul className="space-y-2 font-mono text-xs">
            {insights.categories.volumeOverload.length === 0 ? (
              <li className="opacity-50 text-[11px]">Insufficient volume history recorded.</li>
            ) : (
              insights.categories.volumeOverload.map((text, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#5B7CFF] font-bold">→</span>
                  <span className="opacity-90 leading-relaxed">{text}</span>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* 2. Schedule & Adherence */}
        <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3.5 bg-white/40 dark:bg-black/40 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#5B7CFF] border-b border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 pb-1.5">
            <CalendarCheck size={14} />
            <span>SCHEDULE & ADHERENCE</span>
          </div>
          <ul className="space-y-2 font-mono text-xs">
            {insights.categories.scheduleAdherence.length === 0 ? (
              <li className="opacity-50 text-[11px]">No schedule adherence records available.</li>
            ) : (
              insights.categories.scheduleAdherence.map((text, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#5B7CFF] font-bold">→</span>
                  <span className="opacity-90 leading-relaxed">{text}</span>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* 3. Recovery & Sleep */}
        <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3.5 bg-white/40 dark:bg-black/40 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#5B7CFF] border-b border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 pb-1.5">
            <HeartPulse size={14} />
            <span>RECOVERY & SLEEP</span>
          </div>
          <ul className="space-y-2 font-mono text-xs">
            {insights.categories.recoverySleep.length === 0 ? (
              <li className="opacity-50 text-[11px]">No sleep or recovery records available.</li>
            ) : (
              insights.categories.recoverySleep.map((text, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#5B7CFF] font-bold">→</span>
                  <span className="opacity-90 leading-relaxed">{text}</span>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* 4. Strength & PRs */}
        <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3.5 bg-white/40 dark:bg-black/40 space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#5B7CFF] border-b border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 pb-1.5">
            <Trophy size={14} />
            <span>STRENGTH & RECORDS</span>
          </div>
          <ul className="space-y-2 font-mono text-xs">
            {insights.categories.strengthRecords.length === 0 ? (
              <li className="opacity-50 text-[11px]">No personal records established yet.</li>
            ) : (
              insights.categories.strengthRecords.map((text, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#5B7CFF] font-bold">→</span>
                  <span className="opacity-90 leading-relaxed">{text}</span>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
