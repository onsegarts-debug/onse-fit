import React from 'react';
import type { TrainingConsistencyData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { Target, Flame, CalendarCheck, BarChart3, Clock, Compass } from 'lucide-react';

interface TrainingConsistencyCardProps {
  consistency: TrainingConsistencyData;
}

export function TrainingConsistencyCard({ consistency }: TrainingConsistencyCardProps) {
  const maxDayCount = Math.max(...consistency.dayOfWeekDistribution.map(d => d.count), 1);

  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Target size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">TRAINING CONSISTENCY</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            SCHEDULE REGULARITY & HABITUAL CADENCE
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs px-2.5 py-1 border-2 border-[#111111] dark:border-[#F7F4ED] bg-white/40 dark:bg-black/40 font-bold">
            INDEX: {consistency.consistencyScore}/100
          </span>
        </div>
      </div>

      {/* Grid of Consistency Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Flame size={14} />
            <span>WEEK STREAK</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {consistency.currentWeekStreak} <span className="text-xs opacity-60">WEEKS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Consecutive active weeks
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <CalendarCheck size={14} />
            <span>28-DAY FREQUENCY</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {consistency.frequencyLast4Weeks} <span className="text-xs opacity-60">SESS/WK</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {consistency.adherenceLast4WeeksPercent}% of {consistency.targetFrequency}/wk target
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Clock size={14} />
            <span>REST CADENCE</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {consistency.averageRestIntervalDays} <span className="text-xs opacity-60">DAYS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Avg rest between sessions
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <div className="flex items-center gap-1.5 text-xs text-[#5B7CFF] font-mono font-bold mb-1">
            <Compass size={14} />
            <span>LAST WORKOUT</span>
          </div>
          <div className="text-xl font-bold font-mono">
            {consistency.daysSinceLastWorkout !== null
              ? (consistency.daysSinceLastWorkout === 0 ? 'TODAY' : `${consistency.daysSinceLastWorkout}D AGO`)
              : '—'}
          </div>
          <Mono className="text-[10px] opacity-60">
            {consistency.totalHistoricalWorkouts} lifetime workouts
          </Mono>
        </div>
      </div>

      {/* Day-of-Week Distribution Heatmap / Columns */}
      <div className="space-y-2.5">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          DAY-OF-WEEK SESSION DISTRIBUTION
        </Mono>

        <div className="grid grid-cols-7 gap-1.5 sm:gap-2 pt-2">
          {consistency.dayOfWeekDistribution.map((d) => {
            const heightPercent = maxDayCount > 0 ? (d.count / maxDayCount) * 100 : 0;
            return (
              <div key={d.dayName} className="flex flex-col items-center">
                <div className="w-full h-24 bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border border-[#111111]/20 dark:border-[#F7F4ED]/20 flex items-end p-1 relative group">
                  <div
                    className="w-full bg-[#5B7CFF] transition-all"
                    style={{ height: `${Math.max(8, heightPercent)}%` }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-[#111111]/80 text-[#F7F4ED] text-[9px] font-mono p-1 text-center transition-opacity pointer-events-none">
                    {d.count} sessions ({d.percentage}%)
                  </div>
                </div>
                <Mono className="text-[11px] font-bold mt-1.5">{d.dayName}</Mono>
                <Mono className="text-[10px] opacity-60">{d.count}</Mono>
              </div>
            );
          })}
        </div>
      </div>

      {/* Factual Audit Bullets */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL CONSISTENCY STATEMENTS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {consistency.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
