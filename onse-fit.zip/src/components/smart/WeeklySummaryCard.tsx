import React from 'react';
import type { WeeklySummaryData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { CalendarRange, ChevronLeft, ChevronRight, TrendingUp, TrendingDown, Clock, ShieldAlert } from 'lucide-react';
import { Button } from '../ui/Button';

interface WeeklySummaryCardProps {
  summary: WeeklySummaryData;
  onNavigateWeek: (offsetWeeks: number) => void;
  onResetToCurrentWeek: () => void;
}

export function WeeklySummaryCard({ summary, onNavigateWeek, onResetToCurrentWeek }: WeeklySummaryCardProps) {
  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header & Week Selector */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <CalendarRange size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">WEEKLY SUMMARY</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            {summary.isCurrentWeek ? 'CURRENT CALENDAR WEEK' : 'HISTORICAL WEEK AUDIT'} — {summary.weekKey}
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateWeek(-1)}
            className="p-1.5 h-8 w-8 flex items-center justify-center"
            title="Prior Week"
          >
            <ChevronLeft size={16} />
          </Button>

          <span className="font-mono text-xs font-bold px-2 py-1 border-2 border-[#111111] dark:border-[#F7F4ED]">
            {summary.startDate.slice(5)} – {summary.endDate.slice(5)}
          </span>

          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateWeek(1)}
            className="p-1.5 h-8 w-8 flex items-center justify-center"
            title="Next Week"
          >
            <ChevronRight size={16} />
          </Button>

          {!summary.isCurrentWeek && (
            <Button
              variant="primary"
              size="sm"
              onClick={onResetToCurrentWeek}
              className="text-[10px] py-1 px-2.5 h-8 font-mono"
            >
              CURRENT
            </Button>
          )}
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">TARGET ADHERENCE</Mono>
          <div className="text-xl font-bold font-mono">
            {summary.workoutsCompleted} <span className="text-xs opacity-60">/ {summary.workoutsPlanned}</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.adherencePercentage}% completion rate
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">WEEKLY TONNAGE</Mono>
          <div className="text-xl font-bold font-mono">
            {summary.totalVolumeKg.toLocaleString()} <span className="text-xs opacity-60">KG</span>
          </div>
          <div className="text-[10px] font-mono flex items-center gap-1">
            {summary.volumeChangePercent !== null ? (
              summary.volumeChangePercent >= 0 ? (
                <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                  <TrendingUp size={10} /> +{summary.volumeChangePercent}% WoW
                </span>
              ) : (
                <span className="text-amber-600 dark:text-amber-400 flex items-center gap-0.5">
                  <TrendingDown size={10} /> {summary.volumeChangePercent}% WoW
                </span>
              )
            ) : (
              <span className="opacity-60">Baseline week</span>
            )}
          </div>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">WORKLOAD DENSITY</Mono>
          <div className="text-xl font-bold font-mono">
            {summary.totalSets} <span className="text-xs opacity-60">SETS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.totalReps} total repetitions
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">RECOVERY CADENCE</Mono>
          <div className="text-xl font-bold font-mono">
            {summary.activeDaysCount} <span className="text-xs opacity-60">TRAIN / {summary.restDaysCount} REST</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            {summary.sleepAverages ? `${summary.sleepAverages.averageHoursPerNight}h avg sleep` : 'No sleep logs'}
          </Mono>
        </div>
      </div>

      {/* Muscle Group Allocation Distribution */}
      <div className="space-y-3">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          MUSCLE VOLUME ALLOCATION BREAKDOWN
        </Mono>

        {summary.muscleAllocation.length === 0 ? (
          <div className="border border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 p-4 text-center">
            <Mono className="text-xs opacity-50">No completed workouts recorded for this week.</Mono>
          </div>
        ) : (
          <div className="space-y-2">
            {summary.muscleAllocation.map((m) => (
              <div key={m.category} className="space-y-1">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="font-bold">{m.category.toUpperCase()}</span>
                  <span className="opacity-80">
                    {m.percentage}% ({m.volumeKg.toLocaleString()} kg / {m.setCount} sets)
                  </span>
                </div>
                <div className="h-2 w-full bg-[#111111]/10 dark:bg-[#F7F4ED]/10 border border-[#111111]/20 dark:border-[#F7F4ED]/20 overflow-hidden">
                  <div
                    className="h-full bg-[#5B7CFF]"
                    style={{ width: `${Math.min(100, m.percentage)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Factual Audit Bullets */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL TRAINING STATEMENTS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {summary.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
