import React, { useState } from 'react';
import type { PREventData } from '../../lib/smartTrackEngine';
import { Mono, H3 } from '../ui/Typography';
import { Trophy, Award, Calendar, TrendingUp } from 'lucide-react';
import { Button } from '../ui/Button';

interface PREventsFeedProps {
  prData: PREventData;
}

export function PREventsFeed({ prData }: PREventsFeedProps) {
  const [filter, setFilter] = useState<'all' | 'weight' | 'estimated1RM'>('all');

  const filteredEvents = prData.allPREvents.filter(p => {
    if (filter === 'all') return true;
    return p.metricType === filter;
  });

  return (
    <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 sm:p-5 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Trophy size={18} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase tracking-tight">PR EVENTS AUDIT LOG</H3>
          </div>
          <Mono className="text-xs opacity-60 mt-0.5">
            CHRONOLOGICAL RECORD PROGRESSION & MILESTONES
          </Mono>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-1">
          <Button
            variant={filter === 'all' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
            className="text-[10px] py-1 px-2 font-mono h-7"
          >
            ALL ({prData.totalPRsAllTime})
          </Button>
          <Button
            variant={filter === 'weight' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setFilter('weight')}
            className="text-[10px] py-1 px-2 font-mono h-7"
          >
            WEIGHT
          </Button>
          <Button
            variant={filter === 'estimated1RM' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setFilter('estimated1RM')}
            className="text-[10px] py-1 px-2 font-mono h-7"
          >
            1RM
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">ALL-TIME PRS</Mono>
          <div className="text-xl font-bold font-mono">
            {prData.totalPRsAllTime} <span className="text-xs opacity-60">RECORDS</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Across {prData.exercisePRSummary.length} exercises
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">LAST 7 DAYS</Mono>
          <div className="text-xl font-bold font-mono">
            {prData.prsLast7Days} <span className="text-xs opacity-60">NEW</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Recent milestone events
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">LAST 30 DAYS</Mono>
          <div className="text-xl font-bold font-mono">
            {prData.prsLast30Days} <span className="text-xs opacity-60">NEW</span>
          </div>
          <Mono className="text-[10px] opacity-60">
            Rolling monthly velocity
          </Mono>
        </div>

        <div className="border border-[#111111]/30 dark:border-[#F7F4ED]/30 p-3 bg-white/40 dark:bg-black/40">
          <Mono className="text-[10px] text-[#5B7CFF] font-bold block mb-1">TOP PR EXERCISE</Mono>
          <div className="text-sm font-bold font-mono truncate">
            {prData.exercisePRSummary[0]?.exerciseName || '—'}
          </div>
          <Mono className="text-[10px] opacity-60 truncate">
            {prData.exercisePRSummary[0] ? `${prData.exercisePRSummary[0].totalPRs} records logged` : 'No PRs recorded'}
          </Mono>
        </div>
      </div>

      {/* Chronological PR Feed */}
      <div className="space-y-2.5">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          CHRONOLOGICAL EVENT STREAM
        </Mono>

        {filteredEvents.length === 0 ? (
          <div className="border border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 p-6 text-center">
            <Mono className="text-xs opacity-50">Zero personal records found under the current filter.</Mono>
          </div>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {filteredEvents.map((pr) => (
              <div 
                key={pr.id}
                className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-3 bg-white/60 dark:bg-black/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2 font-mono text-xs"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm">{pr.exerciseName}</span>
                    <span className="text-[9px] px-1.5 py-0.5 font-bold uppercase bg-[#5B7CFF]/10 text-[#5B7CFF] border border-[#5B7CFF]/30">
                      {pr.metricType === 'weight' ? 'MAX WEIGHT PR' : 'ESTIMATED 1RM PR'}
                    </span>
                  </div>
                  <div className="text-[10px] opacity-60 flex items-center gap-3">
                    <span>{pr.date}</span>
                    <span>•</span>
                    <span>{pr.workoutName}</span>
                    <span>•</span>
                    <span>Executed: {pr.weight}kg × {pr.reps} reps</span>
                  </div>
                </div>

                <div className="text-right sm:shrink-0">
                  <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                    {pr.newValue} KG
                  </div>
                  <div className="text-[10px] opacity-70">
                    prior: {pr.previousValue > 0 ? `${pr.previousValue} kg` : 'baseline'} 
                    {pr.previousValue > 0 && ` (+${pr.delta} kg / +${pr.percentGain}%)`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Factual Bullets */}
      <div className="border-t-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 pt-4 space-y-2">
        <Mono className="text-xs font-bold text-[#5B7CFF] uppercase block tracking-wider">
          FACTUAL PR AUDIT STATEMENTS
        </Mono>
        <ul className="space-y-1.5 font-mono text-xs">
          {prData.factualBullets.map((bullet, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span className="text-[#5B7CFF] font-bold">→</span>
              <span className="opacity-90">{bullet}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
