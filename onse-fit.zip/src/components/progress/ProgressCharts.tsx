import React, { useState } from 'react';
import { Mono } from '../ui/Typography';

export interface ChartPoint {
  xLabel: string;
  value: number;
  secondaryValue?: number;
  date?: string;
  tooltipExtra?: string;
}

interface LineTrendChartProps {
  data: ChartPoint[];
  title?: string;
  valueUnit?: string;
  secondaryLabel?: string;
  height?: number;
  emptyMessage?: string;
}

/**
 * Clean, High-Contrast SVG Trend Chart
 * Features:
 * - Deterministic coordinates mapping
 * - Interactive hover cursor & exact value readouts
 * - Min/Max reference guidelines
 * - Zero gradient/slop decoration
 */
export function LineTrendChart({
  data,
  title,
  valueUnit = '',
  secondaryLabel,
  height = 200,
  emptyMessage = 'NO DATA AVAILABLE'
}: LineTrendChartProps) {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div 
        className="w-full border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 flex items-center justify-center p-6 text-center"
        style={{ height }}
      >
        <Mono className="opacity-50 text-xs">{emptyMessage}</Mono>
      </div>
    );
  }

  // Calculate scales
  const allValues = data.flatMap(d => [d.value, ...(d.secondaryValue !== undefined ? [d.secondaryValue] : [])]);
  const rawMin = Math.min(...allValues);
  const rawMax = Math.max(...allValues);
  const padding = (rawMax - rawMin) * 0.1 || (rawMax * 0.1) || 5;
  const minY = Math.floor(rawMin - padding);
  const maxY = Math.ceil(rawMax + padding);
  const yRange = maxY - minY || 1;

  const width = 600; // internal SVG viewBox
  const chartPadding = { top: 20, right: 24, bottom: 32, left: 46 };
  const plotWidth = width - chartPadding.left - chartPadding.right;
  const plotHeight = height - chartPadding.top - chartPadding.bottom;

  const getX = (index: number) => {
    if (data.length === 1) return chartPadding.left + plotWidth / 2;
    return chartPadding.left + (index / (data.length - 1)) * plotWidth;
  };

  const getY = (val: number) => {
    return chartPadding.top + plotHeight - ((val - minY) / yRange) * plotHeight;
  };

  // Primary path
  const primaryPoints = data.map((d, i) => `${getX(i)},${getY(d.value)}`).join(' ');
  
  // Secondary path (e.g. 7-day rolling average)
  const hasSecondary = data.some(d => d.secondaryValue !== undefined);
  const secondaryPoints = hasSecondary
    ? data.filter(d => d.secondaryValue !== undefined).map((d) => `${getX(data.indexOf(d))},${getY(d.secondaryValue!)}`).join(' ')
    : '';

  const activePoint = hoverIndex !== null ? data[hoverIndex] : data[data.length - 1];

  return (
    <div className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
      {/* Chart Top Bar with Current Value Display */}
      <div className="flex justify-between items-center mb-2 px-1 border-b border-[#111111]/10 dark:border-[#F7F4ED]/10 pb-2">
        <div>
          {title && <Mono className="text-[11px] opacity-60 font-bold uppercase">{title}</Mono>}
          {activePoint && (
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-bold font-mono tracking-tight text-[#111111] dark:text-[#F7F4ED]">
                {activePoint.value} {valueUnit}
              </span>
              {activePoint.secondaryValue !== undefined && secondaryLabel && (
                <span className="text-xs font-mono text-[#5B7CFF] opacity-90">
                  {secondaryLabel}: {activePoint.secondaryValue} {valueUnit}
                </span>
              )}
            </div>
          )}
        </div>
        {activePoint?.date && (
          <div className="text-right">
            <Mono className="text-[10px] opacity-60 uppercase">{activePoint.date}</Mono>
            {activePoint.tooltipExtra && (
              <Mono className="text-[10px] text-[#5B7CFF]">{activePoint.tooltipExtra}</Mono>
            )}
          </div>
        )}
      </div>

      {/* SVG Chart Surface */}
      <div className="relative w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible select-none"
          onMouseLeave={() => setHoverIndex(null)}
        >
          {/* Horizontal Grid Guidelines */}
          {[minY, Math.round((minY + maxY) / 2), maxY].map((val) => {
            const y = getY(val);
            return (
              <g key={val}>
                <line
                  x1={chartPadding.left}
                  y1={y}
                  x2={width - chartPadding.right}
                  y2={y}
                  stroke="currentColor"
                  strokeWidth="1"
                  strokeDasharray="3 3"
                  className="text-[#111111]/15 dark:text-[#F7F4ED]/15"
                />
                <text
                  x={chartPadding.left - 6}
                  y={y + 3}
                  textAnchor="end"
                  className="fill-[#111111]/50 dark:fill-[#F7F4ED]/50 font-mono text-[9px]"
                >
                  {val}
                </text>
              </g>
            );
          })}

          {/* Secondary Line (e.g. 7-Day Moving Avg) */}
          {hasSecondary && secondaryPoints && (
            <polyline
              fill="none"
              stroke="#5B7CFF"
              strokeWidth="2"
              strokeDasharray="4 4"
              opacity="0.8"
              points={secondaryPoints}
            />
          )}

          {/* Primary Trend Line */}
          <polyline
            fill="none"
            stroke="#111111"
            className="dark:stroke-[#F7F4ED]"
            strokeWidth="2.5"
            strokeLinejoin="round"
            strokeLinecap="round"
            points={primaryPoints}
          />

          {/* Data Points */}
          {data.map((d, i) => {
            const cx = getX(i);
            const cy = getY(d.value);
            const isHovered = hoverIndex === i;

            return (
              <g key={i}>
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 5 : 3.5}
                  className="fill-[#5B7CFF] stroke-[#111111] dark:stroke-[#F7F4ED]"
                  strokeWidth={isHovered ? 2 : 1.5}
                />
                {/* Invisible hover trigger zones */}
                <rect
                  x={cx - (plotWidth / data.length / 2 || 15)}
                  y={chartPadding.top}
                  width={plotWidth / data.length || 30}
                  height={plotHeight}
                  fill="transparent"
                  className="cursor-pointer"
                  onMouseEnter={() => setHoverIndex(i)}
                />
              </g>
            );
          })}

          {/* Active Hover Crosshair Line */}
          {hoverIndex !== null && (
            <line
              x1={getX(hoverIndex)}
              y1={chartPadding.top}
              x2={getX(hoverIndex)}
              y2={chartPadding.top + plotHeight}
              stroke="#5B7CFF"
              strokeWidth="1.5"
              strokeDasharray="2 2"
            />
          )}

          {/* X Axis Labels */}
          {data.length > 1 && (
            <>
              <text
                x={chartPadding.left}
                y={height - 8}
                textAnchor="start"
                className="fill-[#111111]/50 dark:fill-[#F7F4ED]/50 font-mono text-[9px]"
              >
                {data[0].xLabel}
              </text>
              {data.length > 2 && (
                <text
                  x={chartPadding.left + plotWidth / 2}
                  y={height - 8}
                  textAnchor="middle"
                  className="fill-[#111111]/50 dark:fill-[#F7F4ED]/50 font-mono text-[9px]"
                >
                  {data[Math.floor(data.length / 2)].xLabel}
                </text>
              )}
              <text
                x={width - chartPadding.right}
                y={height - 8}
                textAnchor="end"
                className="fill-[#111111]/50 dark:fill-[#F7F4ED]/50 font-mono text-[9px]"
              >
                {data[data.length - 1].xLabel}
              </text>
            </>
          )}
        </svg>
      </div>

      {/* Legend if secondary value is present */}
      {hasSecondary && secondaryLabel && (
        <div className="flex items-center gap-4 mt-2 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10 text-[10px] font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#111111] dark:bg-[#F7F4ED] inline-block" />
            <span className="opacity-70">RAW VALUE</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-[#5B7CFF] border-b border-dashed border-[#5B7CFF] inline-block" />
            <span className="text-[#5B7CFF]">{secondaryLabel.toUpperCase()}</span>
          </div>
        </div>
      )}
    </div>
  );
}

interface BarChartProps {
  data: Array<{ label: string; value: number; subLabel?: string }>;
  valueUnit?: string;
  height?: number;
}

/**
 * Clean Column / Bar Chart for Volume & Consistency
 */
export function BarVolumeChart({ data, valueUnit = 'kg', height = 180 }: BarChartProps) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div 
        className="w-full border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 flex items-center justify-center p-6 text-center"
        style={{ height }}
      >
        <Mono className="opacity-50 text-xs">NO VOLUME LOGGED</Mono>
      </div>
    );
  }

  const maxValue = Math.max(...data.map(d => d.value), 1);
  const active = hoverIdx !== null ? data[hoverIdx] : data[data.length - 1];

  return (
    <div className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
      <div className="flex justify-between items-baseline mb-3 border-b border-[#111111]/10 dark:border-[#F7F4ED]/10 pb-2">
        <Mono className="text-[11px] opacity-60 font-bold uppercase">TRAINING VOLUME</Mono>
        {active && (
          <div className="text-right">
            <span className="font-mono text-sm font-bold text-[#5B7CFF]">
              {active.value.toLocaleString()} {valueUnit}
            </span>
            {active.subLabel && (
              <span className="text-[10px] opacity-60 font-mono ml-2">({active.subLabel})</span>
            )}
          </div>
        )}
      </div>

      <div className="flex items-end justify-between gap-2 h-28 pt-4 px-2">
        {data.map((item, idx) => {
          const heightPercent = Math.max(6, (item.value / maxValue) * 100);
          const isSelected = hoverIdx === idx;

          return (
            <div
              key={idx}
              className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer"
              onMouseEnter={() => setHoverIdx(idx)}
              onMouseLeave={() => setHoverIdx(null)}
            >
              <div
                style={{ height: `${heightPercent}%` }}
                className={`w-full border-2 border-[#111111] dark:border-[#F7F4ED] transition-all ${
                  isSelected
                    ? 'bg-[#5B7CFF] border-[#5B7CFF]'
                    : 'bg-[#111111] dark:bg-[#F7F4ED]'
                }`}
              />
              <Mono className="text-[9px] mt-1.5 opacity-60 truncate w-full text-center">
                {item.label}
              </Mono>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface MuscleBarProps {
  distribution: Array<{ category: string; volume: number; percentage: number }>;
}

/**
 * Clean Horizontal Breakdown for Muscle Groups
 */
export function MuscleDistributionBars({ distribution }: MuscleBarProps) {
  if (!distribution || distribution.length === 0) {
    return (
      <div className="p-6 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
        <Mono className="opacity-50 text-xs">NO MUSCLE DATA LOGGED</Mono>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {distribution.map((item) => (
        <div key={item.category} className="space-y-1">
          <div className="flex justify-between text-xs font-mono">
            <span className="font-bold uppercase tracking-wider">{item.category}</span>
            <div className="flex items-center gap-2">
              <span className="opacity-60">{item.volume.toLocaleString()} KG</span>
              <span className="text-[#5B7CFF] font-bold">{item.percentage}%</span>
            </div>
          </div>
          {/* Bar track */}
          <div className="h-3 w-full border border-[#111111] dark:border-[#F7F4ED] bg-transparent p-0.5">
            <div
              style={{ width: `${Math.min(100, Math.max(3, item.percentage))}%` }}
              className="h-full bg-[#5B7CFF]"
            />
          </div>
        </div>
      ))}
    </div>
  );
}
