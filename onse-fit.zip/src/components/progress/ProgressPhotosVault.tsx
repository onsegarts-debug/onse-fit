import React, { useState, useRef } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { progressPhotosRepo } from '../../db/api';
import type { ProgressPhoto } from '../../types';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Badge } from '../ui/Badge';
import { H3, Mono } from '../ui/Typography';
import { 
  Lock, Unlock, Eye, EyeOff, Camera, Upload, Trash2, 
  Share2, ArrowLeftRight, Check, X, ShieldAlert, AlertCircle 
} from 'lucide-react';

export function ProgressPhotosVault() {
  // PRIVACY MANDATE: Progress photos must remain private unless explicitly shared.
  // Master vault blur shield is enabled by default to prevent casual over-the-shoulder viewing.
  const [isPrivacyMaskActive, setIsPrivacyMaskActive] = useState<boolean>(true);
  const [selectedPose, setSelectedPose] = useState<string>('all');
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [showCompareModal, setShowCompareModal] = useState<boolean>(false);

  // Comparison State (Before & After)
  const [comparePhoto1Id, setComparePhoto1Id] = useState<string>('');
  const [comparePhoto2Id, setComparePhoto2Id] = useState<string>('');

  // Upload Form State
  const [newDate, setNewDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [newPose, setNewPose] = useState<'front' | 'side' | 'back' | 'other'>('front');
  const [newWeight, setNewWeight] = useState<string>('');
  const [newNotes, setNewNotes] = useState<string>('');
  const [imageDataUrl, setImageDataUrl] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const rawPhotos = useLiveQuery(() => db.progressPhotos.toArray()) || [];

  // Filter by pose
  const filteredPhotos = rawPhotos.filter((p) => {
    if (selectedPose === 'all') return true;
    return p.pose === selectedPose;
  }).sort((a, b) => b.date.localeCompare(a.date));

  // Process image file to base64
  const handleFileProcess = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (JPEG, PNG, WEBP).');
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setUploadError('Image size exceeds 8MB limit.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImageDataUrl(reader.result as string);
      setUploadError(null);
    };
    reader.onerror = () => {
      setUploadError('Failed to read image file.');
    };
    reader.readAsDataURL(file);
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleSavePhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageDataUrl) {
      setUploadError('Please upload an image.');
      return;
    }

    try {
      const parsedWeight = newWeight ? parseFloat(newWeight) : undefined;
      await progressPhotosRepo.create({
        id: crypto.randomUUID(),
        date: newDate,
        pose: newPose,
        photoUrl: imageDataUrl,
        weightAtTime: parsedWeight && !isNaN(parsedWeight) ? parsedWeight : undefined,
        notes: newNotes.trim() || undefined,
        isPrivate: true, // MANDATORY DEFAULT: strictly private
        isShared: false
      });

      setShowUploadModal(false);
      setImageDataUrl('');
      setNewNotes('');
      setNewWeight('');
      setUploadError(null);
    } catch (err) {
      console.error(err);
      setUploadError('Failed to store progress photo locally.');
    }
  };

  const toggleShareStatus = async (photo: ProgressPhoto) => {
    // Explicit toggle for user sharing
    const newSharedStatus = !photo.isShared;
    await progressPhotosRepo.update(photo.id, {
      isShared: newSharedStatus,
      isPrivate: !newSharedStatus // If explicitly shared, isPrivate becomes false, else true
    });
  };

  const handleDeletePhoto = async (id: string) => {
    await progressPhotosRepo.delete(id);
    if (comparePhoto1Id === id) setComparePhoto1Id('');
    if (comparePhoto2Id === id) setComparePhoto2Id('');
  };

  // Comparison items
  const photo1 = rawPhotos.find(p => p.id === comparePhoto1Id);
  const photo2 = rawPhotos.find(p => p.id === comparePhoto2Id);

  return (
    <div className="space-y-6">
      {/* Top Banner & Controls */}
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
        <div>
          <div className="flex items-center gap-2">
            <Lock size={18} className="text-[#5B7CFF]" />
            <H3 className="text-base uppercase m-0">PROGRESS PHOTO VAULT</H3>
            <Badge variant="accent2">PRIVATE BY DEFAULT</Badge>
          </div>
          <Mono className="text-[11px] opacity-70 mt-0.5">
            Encrypted offline in local IndexedDB. Kept 100% private unless explicitly shared.
          </Mono>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Privacy Shield Toggle */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsPrivacyMaskActive(!isPrivacyMaskActive)}
            className="text-xs flex items-center gap-1.5"
            title="Toggle privacy blur shield"
          >
            {isPrivacyMaskActive ? <EyeOff size={14} /> : <Eye size={14} />}
            {isPrivacyMaskActive ? 'UNMASK VAULT' : 'PRIVACY SHIELD ON'}
          </Button>

          {/* Before & After Comparison */}
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowCompareModal(true)}
            disabled={rawPhotos.length < 2}
            className="text-xs flex items-center gap-1.5"
          >
            <ArrowLeftRight size={14} />
            COMPARE (BEFORE / AFTER)
          </Button>

          {/* Add Photo Button */}
          <Button
            variant="primary"
            size="sm"
            onClick={() => setShowUploadModal(true)}
            className="text-xs flex items-center gap-1.5"
          >
            <Upload size={14} />
            + ADD PHOTO
          </Button>
        </div>
      </div>

      {/* Pose Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex gap-2">
          {['all', 'front', 'side', 'back', 'other'].map((pose) => (
            <button
              key={pose}
              onClick={() => setSelectedPose(pose)}
              className={`px-3 py-1 text-xs font-mono font-bold uppercase border-2 border-[#111111] dark:border-[#F7F4ED] transition-colors ${
                selectedPose === pose
                  ? 'bg-[#5B7CFF] text-white border-[#5B7CFF]'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/10'
              }`}
            >
              {pose}
            </button>
          ))}
        </div>

        <Mono className="text-[10px] opacity-60">
          {filteredPhotos.length} PHOTO{filteredPhotos.length === 1 ? '' : 'S'} IN VAULT
        </Mono>
      </div>

      {/* Photos Grid */}
      {filteredPhotos.length === 0 ? (
        <div className="p-12 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center space-y-3">
          <Camera size={32} className="mx-auto opacity-40 text-[#5B7CFF]" />
          <Mono className="opacity-50 text-xs block">NO PROGRESS PHOTOS IN THIS CATEGORY</Mono>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowUploadModal(true)}
            className="text-xs mt-2"
          >
            UPLOAD FIRST CHECK-IN PHOTO
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filteredPhotos.map((photo) => {
            const isBlurry = isPrivacyMaskActive && !photo.isShared;

            return (
              <div
                key={photo.id}
                className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] flex flex-col shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] overflow-hidden"
              >
                {/* Photo Top Bar */}
                <div className="p-2.5 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15 flex justify-between items-center bg-[#111111]/5 dark:bg-[#F7F4ED]/5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-xs font-bold">{photo.date}</span>
                    <span className="font-mono text-[9px] uppercase px-1 border border-current opacity-70">
                      {photo.pose}
                    </span>
                  </div>

                  {/* Privacy Status Badge */}
                  <div>
                    {photo.isShared ? (
                      <span className="inline-flex items-center gap-1 font-mono text-[9px] font-bold text-green-600 dark:text-green-400 bg-green-500/10 px-1.5 py-0.5 border border-green-500/30">
                        <Share2 size={10} /> PUBLIC / SHARED
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 font-mono text-[9px] font-bold text-[#5B7CFF] bg-[#5B7CFF]/10 px-1.5 py-0.5 border border-[#5B7CFF]/30">
                        <Lock size={10} /> PRIVATE
                      </span>
                    )}
                  </div>
                </div>

                {/* Photo Image Container with Privacy Mask */}
                <div className="relative aspect-[3/4] bg-black/90 flex items-center justify-center overflow-hidden group">
                  <img
                    src={photo.photoUrl}
                    alt={`${photo.pose} progress on ${photo.date}`}
                    className={`w-full h-full object-cover transition-all duration-300 ${
                      isBlurry ? 'blur-2xl scale-105 opacity-40 select-none' : 'blur-none opacity-100'
                    }`}
                  />

                  {/* Privacy Blur Overlay Prompt */}
                  {isBlurry && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-black/50">
                      <Lock size={24} className="text-[#5B7CFF] mb-1.5" />
                      <Mono className="text-white text-[11px] font-bold">PRIVATE PHOTO</Mono>
                      <Mono className="text-white/60 text-[9px] mt-0.5">SHIELDED AGAINST SHOULDER-SURFING</Mono>
                      <button
                        onClick={() => setIsPrivacyMaskActive(false)}
                        className="mt-2 text-[10px] font-mono font-bold text-[#5B7CFF] underline uppercase"
                      >
                        REVEAL VAULT
                      </button>
                    </div>
                  )}

                  {/* Quick Preview Hover Action if unmasked */}
                  {!isBlurry && (
                    <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                      <button
                        onClick={() => {
                          setComparePhoto1Id(photo.id);
                          setShowCompareModal(true);
                        }}
                        className="bg-[#111111] text-white p-1.5 text-[10px] font-mono uppercase font-bold border border-white"
                        title="Set as Compare Target"
                      >
                        COMPARE
                      </button>
                    </div>
                  )}
                </div>

                {/* Photo Footer info */}
                <div className="p-3 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10 space-y-2 flex-1 flex flex-col justify-between">
                  <div>
                    {photo.weightAtTime && (
                      <div className="font-mono text-xs">
                        Weight: <strong className="text-[#5B7CFF]">{photo.weightAtTime} KG</strong>
                      </div>
                    )}
                    {photo.notes && (
                      <p className="text-xs font-mono opacity-70 mt-1 line-clamp-2">
                        {photo.notes}
                      </p>
                    )}
                  </div>

                  {/* Explicit Privacy & Share Toggle Bar */}
                  <div className="pt-2 border-t border-dashed border-[#111111]/15 dark:border-[#F7F4ED]/15 flex items-center justify-between">
                    <button
                      onClick={() => toggleShareStatus(photo)}
                      className={`text-[10px] font-mono font-bold flex items-center gap-1 transition-colors uppercase ${
                        photo.isShared ? 'text-green-600 hover:text-green-800' : 'text-[#5B7CFF] hover:text-[#5B7CFF]/80'
                      }`}
                      title="Explicitly toggle privacy status"
                    >
                      {photo.isShared ? (
                        <>
                          <Lock size={12} /> RE-LOCK (MAKE PRIVATE)
                        </>
                      ) : (
                        <>
                          <Share2 size={12} /> EXPLICITLY SHARE
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => handleDeletePhoto(photo.id)}
                      className="text-red-500 hover:text-red-700 p-1 transition-colors"
                      title="Delete photo"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* UPLOAD MODAL (Supports both Click & Drag-and-Drop) */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] max-w-lg w-full p-6 shadow-[8px_8px_0px_0px_#111111] dark:shadow-[8px_8px_0px_0px_#F7F4ED] max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-3 mb-4">
              <div>
                <H3 className="text-lg uppercase m-0">ADD CHECK-IN PHOTO</H3>
                <Mono className="text-[10px] opacity-60">
                  STORED SECURELY IN OFFLINE LOCAL VAULT
                </Mono>
              </div>
              <button
                onClick={() => setShowUploadModal(false)}
                className="p-1 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSavePhoto} className="space-y-4">
              {/* Drag and Drop Zone */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed p-6 text-center cursor-pointer transition-colors ${
                  isDragging
                    ? 'border-[#5B7CFF] bg-[#5B7CFF]/10'
                    : 'border-[#111111]/40 dark:border-[#F7F4ED]/40 hover:border-[#5B7CFF]'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleFileProcess(e.target.files[0]);
                    }
                  }}
                />

                {imageDataUrl ? (
                  <div className="space-y-2">
                    <img
                      src={imageDataUrl}
                      alt="Upload preview"
                      className="max-h-48 mx-auto object-contain border border-[#111111] dark:border-[#F7F4ED]"
                    />
                    <Mono className="text-xs text-[#5B7CFF] font-bold block">
                      CLICK OR DROP TO REPLACE IMAGE
                    </Mono>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Upload size={32} className="mx-auto text-[#5B7CFF]" />
                    <Mono className="text-xs font-bold uppercase block">
                      DRAG & DROP PROGRESS PHOTO HERE
                    </Mono>
                    <Mono className="text-[10px] opacity-60 block">
                      OR CLICK TO BROWSE LOCAL FILES (PNG, JPG, WEBP)
                    </Mono>
                  </div>
                )}
              </div>

              {uploadError && (
                <div className="text-xs font-mono text-red-500 bg-red-500/10 p-2 border border-red-500/30">
                  {uploadError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  type="date"
                  label="DATE"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  required
                />

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-mono tracking-widest uppercase opacity-80">POSE</label>
                  <select
                    value={newPose}
                    onChange={(e) => setNewPose(e.target.value as any)}
                    className="h-12 bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-3 font-mono text-sm font-bold uppercase focus:outline-none focus:border-[#5B7CFF]"
                  >
                    <option value="front" className="bg-[#F7F4ED] dark:bg-[#111111]">FRONT POSE</option>
                    <option value="side" className="bg-[#F7F4ED] dark:bg-[#111111]">SIDE POSE</option>
                    <option value="back" className="bg-[#F7F4ED] dark:bg-[#111111]">BACK POSE</option>
                    <option value="other" className="bg-[#F7F4ED] dark:bg-[#111111]">OTHER / DETAIL</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  type="number"
                  step="0.1"
                  label="BODY WEIGHT AT TIME (KG)"
                  placeholder="e.g. 82.5"
                  value={newWeight}
                  onChange={(e) => setNewWeight(e.target.value)}
                />
                <Input
                  type="text"
                  label="NOTES"
                  placeholder="e.g. Week 4 morning fasted"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                />
              </div>

              {/* Privacy Notice Reminder */}
              <div className="bg-[#5B7CFF]/10 border border-[#5B7CFF]/30 p-2.5 text-[10px] font-mono flex items-start gap-2">
                <Lock size={14} className="text-[#5B7CFF] shrink-0 mt-0.5" />
                <span>
                  <strong>AUTOMATIC PRIVACY:</strong> This photo will be marked strictly <strong>PRIVATE</strong> by default. It stays on your device and is never shared unless you explicitly choose to share it.
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowUploadModal(false)}
                >
                  CANCEL
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={!imageDataUrl}
                >
                  STORE IN PRIVATE VAULT
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BEFORE & AFTER COMPARISON MODAL */}
      {showCompareModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] max-w-4xl w-full p-6 shadow-[8px_8px_0px_0px_#111111] dark:shadow-[8px_8px_0px_0px_#F7F4ED] max-h-[95vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-3 mb-4">
              <div className="flex items-center gap-2">
                <ArrowLeftRight size={20} className="text-[#5B7CFF]" />
                <H3 className="text-lg uppercase m-0">SIDE-BY-SIDE COMPARISON</H3>
              </div>
              <button
                onClick={() => setShowCompareModal(false)}
                className="p-1 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10"
              >
                <X size={20} />
              </button>
            </div>

            {/* Selectors for Photo 1 and Photo 2 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-xs font-mono font-bold uppercase opacity-70 block mb-1">
                  BEFORE (BASELINE CHECK-IN)
                </label>
                <select
                  value={comparePhoto1Id || (rawPhotos[rawPhotos.length - 1]?.id || '')}
                  onChange={(e) => setComparePhoto1Id(e.target.value)}
                  className="w-full h-10 bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-3 font-mono text-xs font-bold"
                >
                  {rawPhotos.map((p) => (
                    <option key={p.id} value={p.id} className="bg-[#F7F4ED] dark:bg-[#111111]">
                      {p.date} — {p.pose.toUpperCase()} ({p.weightAtTime ? `${p.weightAtTime}kg` : 'No wt'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-mono font-bold uppercase opacity-70 block mb-1">
                  AFTER (LATEST CHECK-IN)
                </label>
                <select
                  value={comparePhoto2Id || (rawPhotos[0]?.id || '')}
                  onChange={(e) => setComparePhoto2Id(e.target.value)}
                  className="w-full h-10 bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-3 font-mono text-xs font-bold"
                >
                  {rawPhotos.map((p) => (
                    <option key={p.id} value={p.id} className="bg-[#F7F4ED] dark:bg-[#111111]">
                      {p.date} — {p.pose.toUpperCase()} ({p.weightAtTime ? `${p.weightAtTime}kg` : 'No wt'})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Side-by-Side Photo View */}
            {(() => {
              const p1 = rawPhotos.find(p => p.id === (comparePhoto1Id || rawPhotos[rawPhotos.length - 1]?.id));
              const p2 = rawPhotos.find(p => p.id === (comparePhoto2Id || rawPhotos[0]?.id));

              const weightDelta = p1?.weightAtTime && p2?.weightAtTime
                ? Math.round((p2.weightAtTime - p1.weightAtTime) * 10) / 10
                : null;

              return (
                <div className="space-y-4">
                  {/* Delta Banner */}
                  {weightDelta !== null && (
                    <div className="border-2 border-[#5B7CFF] bg-[#5B7CFF]/10 p-2.5 text-center font-mono text-xs">
                      WEIGHT DELTA BETWEEN DATES: <strong className="text-[#5B7CFF] font-bold text-sm">
                        {weightDelta > 0 ? `+${weightDelta}` : weightDelta} KG
                      </strong>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Before Card */}
                    {p1 && (
                      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-black/90 p-2">
                        <div className="flex justify-between items-center p-1.5 text-white font-mono text-xs mb-1">
                          <span className="font-bold">BEFORE: {p1.date}</span>
                          <span>{p1.weightAtTime ? `${p1.weightAtTime} KG` : ''}</span>
                        </div>
                        <img
                          src={p1.photoUrl}
                          alt="Before"
                          className="w-full aspect-[3/4] object-contain bg-black"
                        />
                        {p1.notes && (
                          <div className="text-white/70 font-mono text-[10px] p-1 mt-1 truncate">
                            {p1.notes}
                          </div>
                        )}
                      </div>
                    )}

                    {/* After Card */}
                    {p2 && (
                      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-black/90 p-2">
                        <div className="flex justify-between items-center p-1.5 text-white font-mono text-xs mb-1">
                          <span className="font-bold text-[#5B7CFF]">AFTER: {p2.date}</span>
                          <span>{p2.weightAtTime ? `${p2.weightAtTime} KG` : ''}</span>
                        </div>
                        <img
                          src={p2.photoUrl}
                          alt="After"
                          className="w-full aspect-[3/4] object-contain bg-black"
                        />
                        {p2.notes && (
                          <div className="text-white/70 font-mono text-[10px] p-1 mt-1 truncate">
                            {p2.notes}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
