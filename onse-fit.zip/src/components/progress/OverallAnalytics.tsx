import React, { useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { calculateOverallTrainingStats } from '../../lib/analytics';
import { BarVolumeChart, MuscleDistributionBars } from './ProgressCharts';
import { MetricDisplay } from '../ui/MetricDisplay';
import { H3, Mono } from '../ui/Typography';
import { Activity, Dumbbell, Calendar, Flame, PieChart, BarChart2 } from 'lucide-react';

export function OverallAnalytics() {
  const workouts = useLiveQuery(() => db.workouts.toArray()) || [];
  const workoutExercises = useLiveQuery(() => db.workoutExercises.toArray()) || [];
  const sets = useLiveQuery(() => db.sets.toArray()) || [];
  const exercises = useLiveQuery(() => db.exercises.toArray()) || [];

  // Compute deterministic statistics across all workouts
  const stats = useMemo(() => {
    return calculateOverallTrainingStats(workouts, workoutExercises, sets, exercises);
  }, [workouts, workoutExercises, sets, exercises]);

  // Volume chart items from weekly breakdown
  const barChartData = useMemo(() => {
    return stats.weeklyVolumeBreakdown.map((w) => ({
      label: w.weekLabel,
      value: w.totalVolume,
      subLabel: `${w.workoutCount} workouts`
    }));
  }, [stats.weeklyVolumeBreakdown]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 flex justify-between items-center shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
        <div className="flex items-center gap-2">
          <Activity size={20} className="text-[#5B7CFF]" />
          <H3 className="text-base uppercase m-0">SYSTEM TRAINING ANALYTICS</H3>
        </div>
        <Mono className="text-[10px] opacity-60">
          {stats.totalWorkoutsCompleted} SESSIONS ANALYZED
        </Mono>
      </div>

      {/* Top Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MetricDisplay
          label="ALL-TIME VOLUME"
          value={stats.totalVolumeAllTime.toLocaleString()}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
        <MetricDisplay
          label="LAST 7-DAY TONNAGE"
          value={stats.volumeLast7Days.toLocaleString()}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
        <MetricDisplay
          label="LAST 30-DAY TONNAGE"
          value={stats.volumeLast30Days.toLocaleString()}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
        <MetricDisplay
          label="WORKOUT FREQUENCY"
          value={stats.frequencyPerWeek}
          unit="/ WK"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3">
          <Mono className="text-[10px] opacity-60 uppercase block">TOTAL SETS LOGGED</Mono>
          <div className="text-2xl font-bold font-mono text-[#111111] dark:text-[#F7F4ED] mt-1">
            {stats.totalCompletedSets}
          </div>
          <span className="text-[9px] font-mono text-[#5B7CFF]">COMPLETED REPS</span>
        </div>

        <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3">
          <Mono className="text-[10px] opacity-60 uppercase block">TOTAL REPS EXECUTED</Mono>
          <div className="text-2xl font-bold font-mono text-[#111111] dark:text-[#F7F4ED] mt-1">
            {stats.totalCompletedReps.toLocaleString()}
          </div>
          <span className="text-[9px] font-mono text-[#5B7CFF]">CLEAN REPETITIONS</span>
        </div>

        <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3">
          <Mono className="text-[10px] opacity-60 uppercase block">AVG SESSION DURATION</Mono>
          <div className="text-2xl font-bold font-mono text-[#111111] dark:text-[#F7F4ED] mt-1">
            {stats.averageDurationMinutes > 0 ? `${stats.averageDurationMinutes}m` : '—'}
          </div>
          <span className="text-[9px] font-mono opacity-50">MINUTES IN GYM</span>
        </div>

        <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3">
          <Mono className="text-[10px] opacity-60 uppercase block">COMPLETED SESSIONS</Mono>
          <div className="text-2xl font-bold font-mono text-[#5B7CFF] mt-1">
            {stats.totalWorkoutsCompleted}
          </div>
          <span className="text-[9px] font-mono opacity-50">COMMITTED WORKOUTS</span>
        </div>
      </div>

      {/* Weekly Training Volume Breakdown */}
      <div className="space-y-2">
        <BarVolumeChart
          data={barChartData}
          valueUnit="KG"
          height={200}
        />
      </div>

      {/* Muscle Group Volume Distribution */}
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-4">
        <div className="flex justify-between items-center border-b border-[#111111]/10 dark:border-[#F7F4ED]/10 pb-2">
          <div className="flex items-center gap-2">
            <PieChart size={18} className="text-[#5B7CFF]" />
            <Mono className="text-xs font-bold uppercase">MUSCLE GROUP VOLUME RATIOS</Mono>
          </div>
          <Mono className="text-[10px] opacity-60">PROPORTIONAL AUDIT</Mono>
        </div>

        <MuscleDistributionBars distribution={stats.muscleDistribution} />
      </div>
    </div>
  );
}
