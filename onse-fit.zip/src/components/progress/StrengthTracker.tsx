import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { detectDeterministicPRs, type ExerciseSessionTrend } from '../../lib/analytics';
import { LineTrendChart, type ChartPoint } from './ProgressCharts';
import { H3, Mono, Body } from '../ui/Typography';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { MetricDisplay } from '../ui/MetricDisplay';
import { Trophy, TrendingUp, Dumbbell, Calendar, ChevronRight } from 'lucide-react';

export function StrengthTracker() {
  const [selectedExerciseId, setSelectedExerciseId] = useState<string>('');
  const [chartMetric, setChartMetric] = useState<'e1RM' | 'maxWeight' | 'volume'>('e1RM');

  const exercises = useLiveQuery(() => db.exercises.toArray()) || [];
  const workouts = useLiveQuery(() => db.workouts.toArray()) || [];
  const workoutExercises = useLiveQuery(() => db.workoutExercises.toArray()) || [];
  const sets = useLiveQuery(() => db.sets.toArray()) || [];

  // Default to first exercise with logged sets if available, or first exercise in db
  const effectiveExerciseId = useMemo(() => {
    if (selectedExerciseId) return selectedExerciseId;
    if (exercises.length === 0) return '';
    // Find exercise that actually has completed sets
    const weWithSets = new Set(sets.filter(s => s.completed && s.weight > 0).map(s => s.workoutExerciseId));
    const activeWE = workoutExercises.filter(we => weWithSets.has(we.id));
    const activeExId = activeWE.length > 0 ? activeWE[0].exerciseId : exercises[0].id;
    return activeExId;
  }, [selectedExerciseId, exercises, workoutExercises, sets]);

  const selectedExercise = exercises.find(e => e.id === effectiveExerciseId);

  // Run deterministic calculation engine for this exercise
  const analytics = useMemo(() => {
    if (!effectiveExerciseId || !selectedExercise) return null;
    return detectDeterministicPRs(
      effectiveExerciseId,
      selectedExercise.name,
      workouts,
      workoutExercises,
      sets
    );
  }, [effectiveExerciseId, selectedExercise, workouts, workoutExercises, sets]);

  // Build chart points based on selected metric
  const chartPoints: ChartPoint[] = useMemo(() => {
    if (!analytics || analytics.sessionTrends.length === 0) return [];
    return analytics.sessionTrends.map(trend => {
      let val = 0;
      if (chartMetric === 'e1RM') val = trend.bestEstimated1RM;
      else if (chartMetric === 'maxWeight') val = trend.maxWeight;
      else val = trend.totalVolume;

      return {
        xLabel: trend.date.slice(5), // MM-DD
        value: val,
        date: trend.date,
        tooltipExtra: `${trend.setCount} sets • Best: ${trend.bestSet.weight}kg × ${trend.bestSet.reps}`
      };
    });
  }, [analytics, chartMetric]);

  const records = analytics?.records;

  return (
    <div className="space-y-6">
      {/* Exercise Selector */}
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
        <div className="flex justify-between items-center mb-2">
          <Mono className="text-xs font-bold uppercase opacity-70">EXERCISE SELECTION</Mono>
          <span className="text-[10px] font-mono text-[#5B7CFF]">
            {analytics?.sessionTrends.length || 0} SESSIONS LOGGED
          </span>
        </div>
        <select
          value={effectiveExerciseId}
          onChange={(e) => setSelectedExerciseId(e.target.value)}
          className="w-full h-12 bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-3 font-mono text-sm font-bold uppercase focus:outline-none focus:border-[#5B7CFF] transition-colors"
        >
          {exercises.map((ex) => (
            <option key={ex.id} value={ex.id} className="bg-[#F7F4ED] dark:bg-[#111111] text-[#111111] dark:text-[#F7F4ED]">
              {ex.name} ({ex.category || ex.targetMuscle})
            </option>
          ))}
        </select>
      </div>

      {/* Key Metric Highlights */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MetricDisplay
          label="ESTIMATED 1RM"
          value={records?.bestEstimated1RM?.value || 0}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
        <MetricDisplay
          label="MAX HEAVY SET"
          value={records?.maxWeight?.value || 0}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
        <MetricDisplay
          label="BEST SET VOLUME"
          value={records?.maxSetVolume?.value || 0}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
        <MetricDisplay
          label="ALL-TIME TONNAGE"
          value={(records?.totalVolumeAllTime || 0).toLocaleString()}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />
      </div>

      {/* Trend Chart View */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <TrendingUp size={18} className="text-[#5B7CFF]" />
            <Mono className="text-xs font-bold uppercase">STRENGTH PROGRESSION CURVE</Mono>
          </div>

          {/* Metric Selector Buttons */}
          <div className="flex border-2 border-[#111111] dark:border-[#F7F4ED]">
            <button
              onClick={() => setChartMetric('e1RM')}
              className={`px-3 py-1 text-[11px] font-mono font-bold uppercase transition-colors ${
                chartMetric === 'e1RM'
                  ? 'bg-[#5B7CFF] text-white'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/10'
              }`}
            >
              1RM (EPLEY)
            </button>
            <button
              onClick={() => setChartMetric('maxWeight')}
              className={`px-3 py-1 text-[11px] font-mono font-bold uppercase border-l-2 border-[#111111] dark:border-[#F7F4ED] transition-colors ${
                chartMetric === 'maxWeight'
                  ? 'bg-[#5B7CFF] text-white'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/10'
              }`}
            >
              MAX WEIGHT
            </button>
            <button
              onClick={() => setChartMetric('volume')}
              className={`px-3 py-1 text-[11px] font-mono font-bold uppercase border-l-2 border-[#111111] dark:border-[#F7F4ED] transition-colors ${
                chartMetric === 'volume'
                  ? 'bg-[#5B7CFF] text-white'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/10'
              }`}
            >
              SESSION VOLUME
            </button>
          </div>
        </div>

        <LineTrendChart
          data={chartPoints}
          title={`${selectedExercise?.name || 'EXERCISE'} • ${
            chartMetric === 'e1RM' ? 'ESTIMATED 1RM PROGRESSION' : chartMetric === 'maxWeight' ? 'PEAK LOAD' : 'TOTAL VOLUME'
          }`}
          valueUnit={chartMetric === 'volume' ? 'KG VOL' : 'KG'}
          height={220}
          emptyMessage="NO COMPLETED SETS RECORDED FOR THIS EXERCISE YET"
        />
      </div>

      {/* Session History & PR Log */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <Mono className="text-xs font-bold uppercase opacity-70">SESSION LOG & BREAKDOWNS</Mono>
          <Mono className="text-[10px] opacity-50">CHRONOLOGICAL</Mono>
        </div>

        {!analytics || analytics.sessionTrends.length === 0 ? (
          <div className="p-8 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
            <Mono className="opacity-50 text-xs">NO SESSIONS LOGGED FOR THIS EXERCISE</Mono>
          </div>
        ) : (
          <div className="space-y-2">
            {analytics.sessionTrends.slice().reverse().map((session) => (
              <div
                key={session.workoutId}
                className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3 flex flex-col md:flex-row justify-between md:items-center gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold">{session.date}</span>
                    <span className="text-xs opacity-60">• {session.workoutName}</span>
                    {session.isPR && (
                      <span className="inline-flex items-center gap-1 bg-[#5B7CFF] text-white font-mono text-[9px] font-bold px-1.5 py-0.5">
                        <Trophy size={10} /> PR SESSION
                      </span>
                    )}
                  </div>
                  <div className="text-xs font-mono mt-1 opacity-80">
                    Best Set: <strong className="text-[#5B7CFF]">{session.bestSet.weight} KG</strong> × {session.bestSet.reps} reps 
                    (e1RM: {session.bestSet.e1RM} KG)
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono">
                  <div>
                    <span className="opacity-50 block text-[9px]">SETS</span>
                    <span className="font-bold">{session.setCount}</span>
                  </div>
                  <div>
                    <span className="opacity-50 block text-[9px]">REPS</span>
                    <span className="font-bold">{session.totalReps}</span>
                  </div>
                  <div className="text-right">
                    <span className="opacity-50 block text-[9px]">VOLUME</span>
                    <span className="font-bold text-[#5B7CFF]">{session.totalVolume.toLocaleString()} KG</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
