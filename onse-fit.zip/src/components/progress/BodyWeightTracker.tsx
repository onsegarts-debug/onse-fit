import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { bodyWeightRepo } from '../../db/api';
import { calculateBodyWeightStats } from '../../lib/analytics';
import { LineTrendChart, type ChartPoint } from './ProgressCharts';
import { MetricDisplay } from '../ui/MetricDisplay';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { H3, Mono } from '../ui/Typography';
import { Scale, Plus, Trash2, Calendar, TrendingDown, TrendingUp, Minus } from 'lucide-react';

export function BodyWeightTracker() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newWeight, setNewWeight] = useState<string>('');
  const [newDate, setNewDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [newNotes, setNewNotes] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const rawWeights = useLiveQuery(() => db.bodyWeights.toArray()) || [];

  // Compute deterministic stats
  const stats = useMemo(() => {
    return calculateBodyWeightStats(rawWeights);
  }, [rawWeights]);

  // Format chart points
  const chartPoints: ChartPoint[] = useMemo(() => {
    return stats.chartPoints.map((pt) => ({
      xLabel: pt.date.slice(5), // MM-DD
      value: pt.weight,
      secondaryValue: pt.rolling7DayAvg,
      date: pt.date
    }));
  }, [stats]);

  const handleAddWeight = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(newWeight);
    if (isNaN(parsed) || parsed <= 0 || parsed > 500) {
      setError('Enter a valid weight between 1 and 500 kg');
      return;
    }
    if (!newDate) {
      setError('Select a valid date');
      return;
    }

    try {
      await bodyWeightRepo.create({
        id: crypto.randomUUID(),
        date: newDate,
        weight: Math.round(parsed * 10) / 10,
        notes: newNotes.trim() || undefined
      });

      setNewWeight('');
      setNewNotes('');
      setError(null);
      setShowAddForm(false);
    } catch (err) {
      console.error(err);
      setError('Failed to save weigh-in');
    }
  };

  const handleDelete = async (id: string) => {
    await bodyWeightRepo.delete(id);
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Scale size={20} className="text-[#5B7CFF]" />
          <H3 className="text-base uppercase m-0">BODY WEIGHT ANALYTICS</H3>
        </div>

        <Button
          variant={showAddForm ? 'outline' : 'primary'}
          size="sm"
          onClick={() => setShowAddForm(!showAddForm)}
          className="text-xs"
        >
          {showAddForm ? 'CANCEL' : '+ LOG WEIGH-IN'}
        </Button>
      </div>

      {/* Add Weight Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddWeight}
          className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 space-y-4 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]"
        >
          <div className="flex justify-between items-center border-b border-[#111111]/10 dark:border-[#F7F4ED]/10 pb-2">
            <Mono className="text-xs font-bold uppercase">LOG NEW BODY WEIGHT</Mono>
            <Mono className="text-[10px] opacity-60">OFFLINE PERSISTENT</Mono>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              type="date"
              label="DATE"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              required
            />
            <Input
              type="number"
              step="0.1"
              label="WEIGHT (KG)"
              placeholder="e.g. 82.5"
              value={newWeight}
              onChange={(e) => {
                setNewWeight(e.target.value);
                setError(null);
              }}
              required
              autoFocus
            />
          </div>

          <Input
            type="text"
            label="NOTES (OPTIONAL)"
            placeholder="e.g. Morning fasted, post bathroom"
            value={newNotes}
            onChange={(e) => setNewNotes(e.target.value)}
          />

          {error && <span className="text-xs font-mono text-red-500 block">{error}</span>}

          <Button type="submit" variant="primary" className="w-full text-xs">
            SAVE WEIGH-IN ENTRY
          </Button>
        </form>
      )}

      {/* Statistical Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MetricDisplay
          label="CURRENT WEIGHT"
          value={stats.currentWeight !== null ? stats.currentWeight : '--'}
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />

        <div className="flex flex-col items-center justify-center p-4 border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]">
          <div className="flex items-baseline gap-1">
            <span className={`text-4xl md:text-5xl font-bold tracking-tighter leading-none font-mono ${
              stats.netChange === null ? 'text-inherit' :
              stats.netChange > 0 ? 'text-[#FFB833]' : stats.netChange < 0 ? 'text-[#5B7CFF]' : 'text-inherit'
            }`}>
              {stats.netChange !== null ? (stats.netChange > 0 ? `+${stats.netChange}` : stats.netChange) : '--'}
            </span>
            <Mono className="text-sm md:text-base font-bold text-[#5B7CFF]">KG</Mono>
          </div>
          <Mono className="mt-2 text-xs opacity-70">NET CHANGE</Mono>
        </div>

        <MetricDisplay
          label="7-DAY MOVING AVG"
          value={
            stats.chartPoints.length > 0
              ? stats.chartPoints[stats.chartPoints.length - 1].rolling7DayAvg
              : '--'
          }
          unit="KG"
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />

        <div className="flex flex-col items-center justify-center p-4 border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[#111111] dark:text-[#F7F4ED]">
              {stats.minWeight !== null ? stats.minWeight : '--'}
            </span>
            <span className="text-xs font-mono opacity-50">/</span>
            <span className="text-2xl font-bold font-mono text-[#111111] dark:text-[#F7F4ED]">
              {stats.maxWeight !== null ? stats.maxWeight : '--'}
            </span>
          </div>
          <Mono className="mt-2 text-xs opacity-70">MIN / MAX (KG)</Mono>
        </div>
      </div>

      {/* Weight Trend Chart */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <Mono className="text-xs font-bold uppercase opacity-70">TREND VISUALIZATION</Mono>
          <Mono className="text-[10px] text-[#5B7CFF]">RAW + 7-DAY ROLLING AVERAGE</Mono>
        </div>

        <LineTrendChart
          data={chartPoints}
          title="WEIGHT PROGRESSION & 7-DAY AVERAGE"
          valueUnit="KG"
          secondaryLabel="7-Day Avg"
          height={220}
          emptyMessage="NO BODY WEIGHT LOGGED YET • CLICK '+ LOG WEIGH-IN' ABOVE"
        />
      </div>

      {/* History Log Table */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <Mono className="text-xs font-bold uppercase opacity-70">
            WEIGH-IN LOGS ({rawWeights.length})
          </Mono>
          <Mono className="text-[10px] opacity-50">CHRONOLOGICAL</Mono>
        </div>

        {rawWeights.length === 0 ? (
          <div className="p-8 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
            <Mono className="opacity-50 text-xs">NO ENTRIES RECORDED</Mono>
          </div>
        ) : (
          <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]">
            <div className="grid grid-cols-[3fr_3fr_4fr_1fr] p-3 border-b-2 border-[#111111] dark:border-[#F7F4ED] text-[10px] font-mono font-bold opacity-60 uppercase">
              <span>DATE</span>
              <span>WEIGHT</span>
              <span>NOTES</span>
              <span className="text-right">ACTION</span>
            </div>

            <div className="divide-y divide-[#111111]/10 dark:divide-[#F7F4ED]/10 max-h-80 overflow-y-auto">
              {[...rawWeights]
                .sort((a, b) => b.date.localeCompare(a.date))
                .map((entry) => (
                  <div
                    key={entry.id}
                    className="grid grid-cols-[3fr_3fr_4fr_1fr] p-3 items-center text-xs font-mono"
                  >
                    <span className="font-bold">{entry.date}</span>
                    <span className="text-[#5B7CFF] font-bold text-sm">{entry.weight} KG</span>
                    <span className="opacity-70 truncate pr-2">{entry.notes || '—'}</span>
                    <div className="text-right">
                      <button
                        onClick={() => handleDelete(entry.id)}
                        className="text-red-500 hover:text-red-700 p-1 transition-colors"
                        title="Delete entry"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
