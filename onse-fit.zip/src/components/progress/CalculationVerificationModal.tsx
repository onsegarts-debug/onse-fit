import React, { useState } from 'react';
import { runCalculationTests, type CalculationTestResult } from '../../lib/analytics';
import { seedBenchmarkData, clearBenchmarkData } from '../../lib/benchmarkData';
import { Button } from '../ui/Button';
import { H3, Mono } from '../ui/Typography';
import { CheckCircle2, XCircle, Play, Database, Trash2, X, ShieldCheck } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export function CalculationVerificationModal({ isOpen, onClose }: Props) {
  const [testResults, setTestResults] = useState<CalculationTestResult[] | null>(null);
  const [seedStatus, setSeedStatus] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleRunTests = () => {
    const results = runCalculationTests();
    setTestResults(results);
  };

  const handleSeedData = async () => {
    setIsLoading(true);
    setSeedStatus('Seeding 4-week deterministic benchmark dataset...');
    try {
      await seedBenchmarkData();
      setSeedStatus('Benchmark dataset loaded! (4 weeks of workouts, weights, measurements & photos)');
      setTimeout(() => setSeedStatus(null), 4000);
    } catch (e) {
      console.error(e);
      setSeedStatus('Failed to load benchmark data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearData = async () => {
    setIsLoading(true);
    setSeedStatus('Clearing benchmark dataset...');
    try {
      await clearBenchmarkData();
      setSeedStatus('Benchmark records removed.');
      setTimeout(() => setSeedStatus(null), 3000);
    } catch (e) {
      console.error(e);
      setSeedStatus('Failed to clear benchmark data');
    } finally {
      setIsLoading(false);
    }
  };

  const allPassed = testResults?.every((r) => r.passed);

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] max-w-2xl w-full p-6 shadow-[8px_8px_0px_0px_#111111] dark:shadow-[8px_8px_0px_0px_#F7F4ED] max-h-[90vh] overflow-y-auto space-y-5">
        <div className="flex justify-between items-center border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck size={22} className="text-[#5B7CFF]" />
            <H3 className="text-lg uppercase m-0">CALCULATION VERIFICATION SUITE</H3>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10"
          >
            <X size={20} />
          </button>
        </div>

        <Mono className="text-xs opacity-70 block">
          Audits mathematical formulas against verified control test vectors (Epley 1RM, volume summation, PR sequence rules, and rolling averages).
        </Mono>

        {/* Action Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={handleRunTests}
            className="text-xs flex items-center justify-center gap-1.5"
          >
            <Play size={14} />
            RUN MATH TESTS
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleSeedData}
            disabled={isLoading}
            className="text-xs flex items-center justify-center gap-1.5"
          >
            <Database size={14} />
            LOAD 4-WK BENCHMARK
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleClearData}
            disabled={isLoading}
            className="text-xs flex items-center justify-center gap-1.5 text-red-500 hover:text-red-700"
          >
            <Trash2 size={14} />
            CLEAR BENCHMARK
          </Button>
        </div>

        {seedStatus && (
          <div className="p-2.5 bg-[#5B7CFF]/15 border border-[#5B7CFF] text-xs font-mono text-[#5B7CFF]">
            {seedStatus}
          </div>
        )}

        {/* Test Output */}
        {testResults && (
          <div className="space-y-3">
            <div className="flex justify-between items-center border-b border-[#111111]/15 dark:border-[#F7F4ED]/15 pb-1">
              <span className="text-xs font-mono font-bold uppercase">
                TEST RESULTS ({testResults.filter(r => r.passed).length}/{testResults.length} PASSED)
              </span>
              <span className={`text-xs font-mono font-bold px-2 py-0.5 ${
                allPassed ? 'bg-green-500/20 text-green-600 dark:text-green-400' : 'bg-red-500/20 text-red-600'
              }`}>
                {allPassed ? 'ALL VERIFIED OK' : 'FAILED ASSERTIONS'}
              </span>
            </div>

            <div className="space-y-2">
              {testResults.map((r, i) => (
                <div
                  key={i}
                  className={`border p-3 font-mono text-xs ${
                    r.passed
                      ? 'border-green-500/40 bg-green-500/5'
                      : 'border-red-500 bg-red-500/10'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold">
                    {r.passed ? (
                      <CheckCircle2 size={15} className="text-green-600 dark:text-green-400 shrink-0" />
                    ) : (
                      <XCircle size={15} className="text-red-600 shrink-0" />
                    )}
                    <span>{r.name}</span>
                  </div>
                  <div className="text-[10px] opacity-70 mt-1 pl-6">
                    Expected: {JSON.stringify(r.expected)} • Actual: {JSON.stringify(r.actual)}
                  </div>
                  {r.message && (
                    <div className="text-[10px] text-red-500 mt-1 pl-6">{r.message}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10 flex justify-end">
          <Button variant="outline" size="sm" onClick={onClose}>
            CLOSE
          </Button>
        </div>
      </div>
    </div>
  );
}
