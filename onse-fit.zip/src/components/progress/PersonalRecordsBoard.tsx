import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { detectDeterministicPRs, type DetectedPR, type ExerciseAllTimeRecords } from '../../lib/analytics';
import { H3, Mono } from '../ui/Typography';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Trophy, Award, ArrowUpRight, Zap, RefreshCw, CheckCircle2 } from 'lucide-react';

export function PersonalRecordsBoard() {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  const exercises = useLiveQuery(() => db.exercises.toArray()) || [];
  const workouts = useLiveQuery(() => db.workouts.toArray()) || [];
  const workoutExercises = useLiveQuery(() => db.workoutExercises.toArray()) || [];
  const sets = useLiveQuery(() => db.sets.toArray()) || [];

  // Compute deterministic PRs for every exercise
  const { allRecords, allMilestones } = useMemo(() => {
    const records: ExerciseAllTimeRecords[] = [];
    const milestones: DetectedPR[] = [];

    for (const ex of exercises) {
      const { records: r, milestoneHistory: m } = detectDeterministicPRs(
        ex.id,
        ex.name,
        workouts,
        workoutExercises,
        sets
      );
      if (r.maxWeight || r.bestEstimated1RM) {
        records.push({
          ...r,
          targetMuscle: ex.targetMuscle,
          category: ex.category || ex.targetMuscle
        });
      }
      milestones.push(...m);
    }

    // Sort milestones chronologically descending (newest first)
    milestones.sort((a, b) => b.workoutDate.localeCompare(a.workoutDate));

    return { allRecords: records, allMilestones: milestones };
  }, [exercises, workouts, workoutExercises, sets]);

  // Filter records by category
  const categories = useMemo(() => {
    const cats = new Set<string>();
    for (const r of allRecords) {
      if (r.category) cats.add(r.category.toUpperCase());
    }
    return ['ALL', ...Array.from(cats)];
  }, [allRecords]);

  const filteredRecords = useMemo(() => {
    if (selectedCategory === 'ALL') return allRecords;
    return allRecords.filter(r => r.category.toUpperCase() === selectedCategory);
  }, [allRecords, selectedCategory]);

  // Deterministically sync all detected PRs into the database personalRecords table
  const handleSyncPRs = async () => {
    setIsSyncing(true);
    setSyncStatus('Detecting deterministic PRs...');
    try {
      const recordsToStore: any[] = [];
      for (const rec of allRecords) {
        if (rec.maxWeight) {
          recordsToStore.push({
            id: `pr-weight-${rec.exerciseId}`,
            exerciseId: rec.exerciseId,
            workoutId: rec.maxWeight.workoutId,
            type: 'weight',
            value: rec.maxWeight.value,
            reps: rec.maxWeight.reps,
            date: rec.maxWeight.date,
            notes: `Deterministic heaviest single set: ${rec.maxWeight.value} kg × ${rec.maxWeight.reps}`
          });
        }
        if (rec.bestEstimated1RM) {
          recordsToStore.push({
            id: `pr-1rm-${rec.exerciseId}`,
            exerciseId: rec.exerciseId,
            workoutId: rec.bestEstimated1RM.workoutId,
            type: 'estimated1RM',
            value: rec.bestEstimated1RM.value,
            weight: rec.bestEstimated1RM.weight,
            reps: rec.bestEstimated1RM.reps,
            date: rec.bestEstimated1RM.date,
            notes: `Deterministic Epley 1RM: ${rec.bestEstimated1RM.value} kg from ${rec.bestEstimated1RM.weight} kg × ${rec.bestEstimated1RM.reps}`
          });
        }
      }

      await db.personalRecords.bulkPut(recordsToStore);
      setSyncStatus(`Synced ${recordsToStore.length} verified records to SQLite/IndexedDB`);
      setTimeout(() => setSyncStatus(null), 3500);
    } catch (e) {
      console.error(e);
      setSyncStatus('Sync failed');
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Engine Status Banner */}
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-3 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-[#5B7CFF] text-white">
            <Trophy size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <H3 className="text-base uppercase m-0">DETERMINISTIC PR ENGINE</H3>
              <Badge variant="default">STRICT RULES</Badge>
            </div>
            <Mono className="text-[11px] opacity-70 mt-0.5">
              Calculated via Epley Formula & chronologically audited set volume. Zero estimates or mocks.
            </Mono>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSyncPRs}
            disabled={isSyncing || allRecords.length === 0}
            className="w-full md:w-auto text-xs flex items-center gap-1.5"
          >
            <RefreshCw size={13} className={isSyncing ? 'animate-spin' : ''} />
            SYNC PR DATABASE
          </Button>
        </div>
      </div>

      {syncStatus && (
        <div className="border-2 border-[#5B7CFF] bg-[#5B7CFF]/10 p-3 flex items-center gap-2 font-mono text-xs text-[#5B7CFF]">
          <CheckCircle2 size={16} />
          <span>{syncStatus}</span>
        </div>
      )}

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 font-mono text-xs font-bold uppercase border-2 border-[#111111] dark:border-[#F7F4ED] transition-colors ${
              selectedCategory === cat
                ? 'bg-[#5B7CFF] text-white border-[#5B7CFF]'
                : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/10'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Exercise PR Cards Grid */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Mono className="text-xs font-bold uppercase opacity-70">
            ALL-TIME PR TROPHY BOARD ({filteredRecords.length})
          </Mono>
          <Mono className="text-[10px] opacity-50">VERIFIED RECORDS</Mono>
        </div>

        {filteredRecords.length === 0 ? (
          <div className="p-8 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
            <Mono className="opacity-50 text-xs">NO PERSONAL RECORDS LOGGED YET</Mono>
            <p className="text-xs opacity-60 mt-1">Complete a workout with weights to generate your first PRs.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredRecords.map((rec) => (
              <div
                key={rec.exerciseId}
                className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]"
              >
                <div className="flex justify-between items-start border-b border-[#111111]/10 dark:border-[#F7F4ED]/10 pb-2 mb-3">
                  <div>
                    <H3 className="text-base uppercase">{rec.exerciseName}</H3>
                    <Mono className="text-[10px] opacity-60 uppercase">{rec.category || 'EXERCISE'}</Mono>
                  </div>
                  <span className="font-mono text-[10px] bg-[#111111]/5 dark:bg-[#F7F4ED]/10 px-2 py-0.5">
                    {rec.sessionsCount} SESSIONS
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {/* Heaviest Weight */}
                  <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-2.5">
                    <span className="text-[9px] font-mono opacity-60 uppercase block">MAX LOAD LIFTED</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-2xl font-bold font-mono text-[#111111] dark:text-[#F7F4ED]">
                        {rec.maxWeight?.value || 0}
                      </span>
                      <span className="text-xs font-mono text-[#5B7CFF] font-bold">KG</span>
                    </div>
                    {rec.maxWeight && (
                      <span className="text-[10px] font-mono opacity-70 block mt-1">
                        for {rec.maxWeight.reps} reps • {rec.maxWeight.date}
                      </span>
                    )}
                  </div>

                  {/* Best Estimated 1RM */}
                  <div className="border border-[#111111]/20 dark:border-[#F7F4ED]/20 p-2.5 bg-[#5B7CFF]/5">
                    <span className="text-[9px] font-mono text-[#5B7CFF] font-bold uppercase block">ESTIMATED 1RM</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-2xl font-bold font-mono text-[#5B7CFF]">
                        {rec.bestEstimated1RM?.value || 0}
                      </span>
                      <span className="text-xs font-mono text-[#5B7CFF] font-bold">KG</span>
                    </div>
                    {rec.bestEstimated1RM && (
                      <span className="text-[10px] font-mono opacity-70 block mt-1">
                        from {rec.bestEstimated1RM.weight}kg × {rec.bestEstimated1RM.reps}
                      </span>
                    )}
                  </div>
                </div>

                {/* Additional metrics */}
                <div className="mt-2.5 pt-2 border-t border-dashed border-[#111111]/15 dark:border-[#F7F4ED]/15 flex justify-between items-center text-[10px] font-mono opacity-75">
                  <span>MAX SET TONNAGE: {rec.maxSetVolume?.value || 0} KG</span>
                  <span>TOTAL TONNAGE: {rec.totalVolumeAllTime.toLocaleString()} KG</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* PR Milestones Timeline */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <Mono className="text-xs font-bold uppercase opacity-70">
            RECENT PR MILESTONES ({allMilestones.length})
          </Mono>
          <Mono className="text-[10px] opacity-50">DETERMINISTIC EVENT LOG</Mono>
        </div>

        {allMilestones.length === 0 ? (
          <div className="p-6 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
            <Mono className="opacity-50 text-xs">NO MILESTONES RECORDED</Mono>
          </div>
        ) : (
          <div className="space-y-2">
            {allMilestones.slice(0, 15).map((m) => (
              <div
                key={m.id}
                className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3 flex flex-col sm:flex-row justify-between sm:items-center gap-2"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#111111] dark:text-[#F7F4ED]">
                      {m.exerciseName}
                    </span>
                    <span className="font-mono text-[9px] bg-[#5B7CFF] text-white px-1.5 py-0.2 font-bold uppercase">
                      {m.type === 'estimated1RM' ? '1RM RECORD' : m.type === 'weight' ? 'LOAD RECORD' : 'VOLUME RECORD'}
                    </span>
                  </div>
                  <Mono className="text-[10px] opacity-60 mt-0.5">
                    {m.workoutDate} • Set: {m.weight} kg × {m.reps} reps
                  </Mono>
                </div>

                <div className="flex items-center gap-3 font-mono text-xs self-end sm:self-auto">
                  <div className="text-right">
                    <span className="text-[10px] opacity-50 line-through mr-1.5">{m.previousValue}</span>
                    <span className="font-bold text-[#111111] dark:text-[#F7F4ED]">{m.value} KG</span>
                  </div>
                  <div className="bg-[#5B7CFF]/15 text-[#5B7CFF] px-2 py-0.5 font-bold flex items-center gap-0.5">
                    <ArrowUpRight size={12} />
                    <span>+{m.percentGain}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
