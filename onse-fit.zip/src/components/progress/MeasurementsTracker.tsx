import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { measurementsRepo } from '../../db/api';
import { calculateMeasurementStats, type MeasurementTrend } from '../../lib/analytics';
import { LineTrendChart, type ChartPoint } from './ProgressCharts';
import { MetricDisplay } from '../ui/MetricDisplay';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { H3, Mono } from '../ui/Typography';
import { Ruler, Trash2, TrendingDown, TrendingUp, Plus } from 'lucide-react';

const BODY_PARTS = [
  { id: 'waist', label: 'WAIST' },
  { id: 'chest', label: 'CHEST' },
  { id: 'arms', label: 'ARMS (BICEPS)' },
  { id: 'thighs', label: 'THIGHS' },
  { id: 'hips', label: 'HIPS' },
  { id: 'shoulders', label: 'SHOULDERS' },
  { id: 'neck', label: 'NECK' },
  { id: 'calves', label: 'CALVES' }
];

export function MeasurementsTracker() {
  const [selectedType, setSelectedType] = useState<string>('waist');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newValue, setNewValue] = useState<string>('');
  const [newType, setNewType] = useState<string>('waist');
  const [newUnit, setNewUnit] = useState<string>('cm');
  const [newDate, setNewDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [newNotes, setNewNotes] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const rawMeasurements = useLiveQuery(() => db.measurements.toArray()) || [];

  // Compute stats for all types
  const trends = useMemo(() => {
    return calculateMeasurementStats(rawMeasurements);
  }, [rawMeasurements]);

  const activeTrend = useMemo(() => {
    return trends.find((t) => t.type.toLowerCase() === selectedType.toLowerCase()) || null;
  }, [trends, selectedType]);

  // Chart data for active body part
  const chartPoints: ChartPoint[] = useMemo(() => {
    if (!activeTrend) return [];
    return activeTrend.history.map((h) => ({
      xLabel: h.date.slice(5),
      value: h.value,
      date: h.date,
      tooltipExtra: h.notes
    }));
  }, [activeTrend]);

  const handleAddMeasurement = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(newValue);
    if (isNaN(parsed) || parsed <= 0 || parsed > 300) {
      setError('Enter a valid measurement value');
      return;
    }
    if (!newDate) {
      setError('Select a date');
      return;
    }

    try {
      await measurementsRepo.create({
        id: crypto.randomUUID(),
        type: newType.toLowerCase(),
        value: Math.round(parsed * 10) / 10,
        unit: newUnit,
        date: newDate,
        notes: newNotes.trim() || undefined
      });

      setSelectedType(newType);
      setNewValue('');
      setNewNotes('');
      setError(null);
      setShowAddForm(false);
    } catch (err) {
      console.error(err);
      setError('Failed to save measurement');
    }
  };

  const handleDelete = async (id: string) => {
    await measurementsRepo.delete(id);
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Ruler size={20} className="text-[#5B7CFF]" />
          <H3 className="text-base uppercase m-0">BODY MEASUREMENTS</H3>
        </div>

        <Button
          variant={showAddForm ? 'outline' : 'primary'}
          size="sm"
          onClick={() => setShowAddForm(!showAddForm)}
          className="text-xs"
        >
          {showAddForm ? 'CANCEL' : '+ LOG MEASUREMENT'}
        </Button>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddMeasurement}
          className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4 space-y-4 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]"
        >
          <div className="flex justify-between items-center border-b border-[#111111]/10 dark:border-[#F7F4ED]/10 pb-2">
            <Mono className="text-xs font-bold uppercase">LOG NEW CIRCUMFERENCE</Mono>
            <Mono className="text-[10px] opacity-60">DETERMINISTIC LOG</Mono>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono tracking-widest uppercase opacity-80">BODY SITE</label>
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value)}
                className="h-12 bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-3 font-mono text-sm font-bold uppercase focus:outline-none focus:border-[#5B7CFF]"
              >
                {BODY_PARTS.map((bp) => (
                  <option key={bp.id} value={bp.id} className="bg-[#F7F4ED] dark:bg-[#111111]">
                    {bp.label}
                  </option>
                ))}
              </select>
            </div>

            <Input
              type="number"
              step="0.1"
              label="VALUE"
              placeholder="e.g. 84.5"
              value={newValue}
              onChange={(e) => {
                setNewValue(e.target.value);
                setError(null);
              }}
              required
            />

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono tracking-widest uppercase opacity-80">UNIT</label>
              <select
                value={newUnit}
                onChange={(e) => setNewUnit(e.target.value)}
                className="h-12 bg-transparent border-2 border-[#111111] dark:border-[#F7F4ED] px-3 font-mono text-sm font-bold uppercase focus:outline-none focus:border-[#5B7CFF]"
              >
                <option value="cm" className="bg-[#F7F4ED] dark:bg-[#111111]">CM</option>
                <option value="in" className="bg-[#F7F4ED] dark:bg-[#111111]">INCHES</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              type="date"
              label="DATE"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              required
            />
            <Input
              type="text"
              label="NOTES (OPTIONAL)"
              placeholder="e.g. Navel level relaxed"
              value={newNotes}
              onChange={(e) => setNewNotes(e.target.value)}
            />
          </div>

          {error && <span className="text-xs font-mono text-red-500 block">{error}</span>}

          <Button type="submit" variant="primary" className="w-full text-xs">
            SAVE MEASUREMENT ENTRY
          </Button>
        </form>
      )}

      {/* Body Part Selector Chips */}
      <div className="flex flex-wrap gap-2">
        {BODY_PARTS.map((bp) => {
          const hasData = trends.some((t) => t.type.toLowerCase() === bp.id.toLowerCase());
          return (
            <button
              key={bp.id}
              onClick={() => setSelectedType(bp.id)}
              className={`px-3 py-1.5 font-mono text-xs font-bold uppercase border-2 border-[#111111] dark:border-[#F7F4ED] transition-colors relative ${
                selectedType === bp.id
                  ? 'bg-[#5B7CFF] text-white border-[#5B7CFF]'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/10'
              }`}
            >
              {bp.label}
              {hasData && (
                <span className="ml-1.5 inline-block w-1.5 h-1.5 rounded-full bg-[#FFB833]" />
              )}
            </button>
          );
        })}
      </div>

      {/* Metrics for Selected Site */}
      <div className="grid grid-cols-3 gap-3">
        <MetricDisplay
          label="LATEST"
          value={activeTrend?.latestValue || '--'}
          unit={activeTrend?.unit || 'CM'}
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />

        <MetricDisplay
          label="BASELINE"
          value={activeTrend?.startingValue || '--'}
          unit={activeTrend?.unit || 'CM'}
          className="bg-[#F7F4ED] dark:bg-[#111111]"
        />

        <div className="flex flex-col items-center justify-center p-4 border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]">
          <div className="flex items-baseline gap-1">
            <span className={`text-3xl md:text-4xl font-bold tracking-tighter leading-none font-mono ${
              !activeTrend ? 'text-inherit' :
              activeTrend.netChange < 0 ? 'text-[#5B7CFF]' :
              activeTrend.netChange > 0 ? 'text-[#FFB833]' : 'text-inherit'
            }`}>
              {activeTrend ? (activeTrend.netChange > 0 ? `+${activeTrend.netChange}` : activeTrend.netChange) : '--'}
            </span>
            <Mono className="text-sm font-bold text-[#5B7CFF]">
              {activeTrend?.unit || 'CM'}
            </Mono>
          </div>
          <Mono className="mt-2 text-xs opacity-70">NET DELTA</Mono>
        </div>
      </div>

      {/* Trend Chart */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <Mono className="text-xs font-bold uppercase opacity-70">
            {selectedType.toUpperCase()} TREND CURVE
          </Mono>
          <Mono className="text-[10px] opacity-50">
            {activeTrend?.history.length || 0} POINTS
          </Mono>
        </div>

        <LineTrendChart
          data={chartPoints}
          title={`${selectedType.toUpperCase()} CIRCUMFERENCE`}
          valueUnit={activeTrend?.unit || 'CM'}
          height={200}
          emptyMessage={`NO ${selectedType.toUpperCase()} MEASUREMENTS LOGGED YET`}
        />
      </div>

      {/* History Log */}
      <div className="space-y-3">
        <Mono className="text-xs font-bold uppercase opacity-70">MEASUREMENT HISTORY</Mono>

        {!activeTrend || activeTrend.history.length === 0 ? (
          <div className="p-6 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
            <Mono className="opacity-50 text-xs">NO ENTRIES RECORDED FOR THIS SITE</Mono>
          </div>
        ) : (
          <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]">
            <div className="grid grid-cols-[3fr_3fr_4fr_1fr] p-3 border-b-2 border-[#111111] dark:border-[#F7F4ED] text-[10px] font-mono font-bold opacity-60 uppercase">
              <span>DATE</span>
              <span>VALUE</span>
              <span>NOTES</span>
              <span className="text-right">ACTION</span>
            </div>

            <div className="divide-y divide-[#111111]/10 dark:divide-[#F7F4ED]/10 max-h-60 overflow-y-auto">
              {[...activeTrend.history]
                .reverse()
                .map((item) => (
                  <div
                    key={item.id}
                    className="grid grid-cols-[3fr_3fr_4fr_1fr] p-3 items-center text-xs font-mono"
                  >
                    <span className="font-bold">{item.date}</span>
                    <span className="text-[#5B7CFF] font-bold text-sm">
                      {item.value} {item.unit}
                    </span>
                    <span className="opacity-70 truncate pr-2">{item.notes || '—'}</span>
                    <div className="text-right">
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="text-red-500 hover:text-red-700 p-1 transition-colors"
                        title="Delete entry"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
