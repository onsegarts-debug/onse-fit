import React from 'react';
import { cn } from '../../lib/utils';

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'accent1' | 'accent2' | 'outline';
}

export function Badge({ className, variant = 'default', ...props }: BadgeProps) {
  const variants = {
    default: 'bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111] border-2 border-transparent',
    accent1: 'bg-[#5B7CFF] text-white border-2 border-transparent',
    accent2: 'bg-[#FFB833] text-[#111111] border-2 border-transparent',
    outline: 'bg-transparent text-[#111111] dark:text-[#F7F4ED] border-2 border-[#111111] dark:border-[#F7F4ED]',
  };

  return (
    <div
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 text-xs font-mono font-bold tracking-widest uppercase transition-colors",
        variants[variant],
        className
      )}
      {...props}
    />
  );
}
