import React from 'react';
import { cn } from '../../lib/utils';
import { Mono } from './Typography';

interface LogbookLabelProps extends React.HTMLAttributes<HTMLDivElement> {
  label: string;
  value: React.ReactNode;
  align?: 'left' | 'right' | 'center';
}

export function LogbookLabel({ label, value, align = 'left', className, ...props }: LogbookLabelProps) {
  const alignMap = {
    left: 'items-start text-left',
    right: 'items-end text-right',
    center: 'items-center text-center',
  };

  return (
    <div className={cn("flex flex-col gap-1", alignMap[align], className)} {...props}>
      <Mono className="text-[10px] text-[#111111]/60 dark:text-[#F7F4ED]/60 leading-none">
        {label}
      </Mono>
      <div className="font-sans font-bold text-[#111111] dark:text-[#F7F4ED] uppercase leading-none">
        {value}
      </div>
    </div>
  );
}
