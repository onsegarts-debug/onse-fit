import React from 'react';
import { cn } from '../../lib/utils';
import { Mono } from './Typography';

interface PlateProps extends React.HTMLAttributes<HTMLDivElement> {
  weight: number | string;
  unit?: string;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function Plate({ weight, unit = 'KG', label, size = 'md', className, ...props }: PlateProps) {
  const sizeMap = {
    sm: 'w-16 h-16 border-4',
    md: 'w-24 h-24 border-4',
    lg: 'w-32 h-32 border-8',
  };

  const textMap = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl',
  };

  const labelMap = {
    sm: 'text-[8px]',
    md: 'text-[10px]',
    lg: 'text-xs',
  };

  return (
    <div 
      className={cn(
        "rounded-full flex flex-col items-center justify-center border-[#111111] dark:border-[#F7F4ED] relative",
        "shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]", // Neo-brutalist shadow
        sizeMap[size],
        className
      )}
      {...props}
    >
      {/* Inner concentric ring */}
      <div className="absolute inset-1 border border-[#111111]/20 dark:border-[#F7F4ED]/20 rounded-full" />
      <div className="absolute inset-2 border border-[#111111]/10 dark:border-[#F7F4ED]/10 rounded-full" />
      
      {/* Content */}
      <div className="z-10 flex flex-col items-center">
        <span className={cn("font-bold tracking-tighter leading-none text-[#111111] dark:text-[#F7F4ED]", textMap[size])}>
          {weight}
        </span>
        <Mono className={cn("font-bold text-[#5B7CFF] leading-none mt-1", labelMap[size])}>
          {unit}
        </Mono>
        {label && (
          <Mono className={cn("opacity-60 absolute bottom-3", labelMap[size])}>
            {label}
          </Mono>
        )}
      </div>
    </div>
  );
}
