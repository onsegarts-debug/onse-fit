import React from 'react';
import { cn } from '../../lib/utils';
import { Mono } from './Typography';

interface MetricDisplayProps extends React.HTMLAttributes<HTMLDivElement> {
  value: string | number;
  unit?: string;
  label: string;
}

export function MetricDisplay({ value, unit, label, className, ...props }: MetricDisplayProps) {
  return (
    <div className={cn("flex flex-col items-center justify-center p-4 border-2 border-[#111111] dark:border-[#F7F4ED]", className)} {...props}>
      <div className="flex items-baseline gap-1">
        <span className="text-4xl md:text-5xl font-bold tracking-tighter text-[#111111] dark:text-[#F7F4ED] leading-none">
          {value}
        </span>
        {unit && (
          <Mono className="text-sm md:text-base font-bold text-[#5B7CFF]">
            {unit}
          </Mono>
        )}
      </div>
      <Mono className="mt-2 text-xs opacity-70">
        {label}
      </Mono>
    </div>
  );
}
