import React from 'react';
import { cn } from '../../lib/utils';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, label, error, ...props }, ref) => {
    return (
      <div className="w-full flex flex-col gap-1.5">
        {label && (
          <label className="text-xs font-mono tracking-widest uppercase text-[#111111] dark:text-[#F7F4ED] opacity-80">
            {label}
          </label>
        )}
        <input
          type={type}
          className={cn(
            "flex h-12 w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent px-4 py-2 text-base font-medium text-[#111111] dark:text-[#F7F4ED] placeholder:text-[#111111]/40 dark:placeholder:text-[#F7F4ED]/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5B7CFF] focus-visible:border-[#5B7CFF] disabled:cursor-not-allowed disabled:opacity-50 transition-colors",
            error && "border-red-500 focus-visible:ring-red-500 focus-visible:border-red-500",
            className
          )}
          ref={ref}
          {...props}
        />
        {error && (
          <span className="text-xs font-mono text-red-500 mt-1">{error}</span>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";
