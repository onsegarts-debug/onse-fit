import React from 'react';
import { cn } from '../../lib/utils';

interface TypographyProps extends React.HTMLAttributes<HTMLHeadingElement | HTMLParagraphElement | HTMLSpanElement> {
  children: React.ReactNode;
}

export function H1({ className, ...props }: TypographyProps) {
  return (
    <h1 className={cn("text-4xl md:text-5xl font-bold tracking-tight text-[#111111] dark:text-[#F7F4ED]", className)} {...props} />
  );
}

export function H2({ className, ...props }: TypographyProps) {
  return (
    <h2 className={cn("text-3xl md:text-4xl font-bold tracking-tight text-[#111111] dark:text-[#F7F4ED]", className)} {...props} />
  );
}

export function H3({ className, ...props }: TypographyProps) {
  return (
    <h3 className={cn("text-2xl font-bold tracking-tight text-[#111111] dark:text-[#F7F4ED]", className)} {...props} />
  );
}

export function H4({ className, ...props }: TypographyProps) {
  return (
    <h4 className={cn("text-xl font-bold tracking-tight text-[#111111] dark:text-[#F7F4ED]", className)} {...props} />
  );
}

export function Body({ className, ...props }: TypographyProps) {
  return (
    <p className={cn("text-base leading-relaxed text-[#111111]/80 dark:text-[#F7F4ED]/80", className)} {...props} />
  );
}

export function Mono({ className, ...props }: TypographyProps) {
  return (
    <span className={cn("font-mono text-sm tracking-widest uppercase", className)} {...props} />
  );
}
