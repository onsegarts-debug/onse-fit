import React from 'react';
import { cn } from '../../lib/utils';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'icon';
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', ...props }, ref) => {
    const variants = {
      primary: 'bg-[#5B7CFF] text-white border-2 border-[#5B7CFF] hover:bg-[#5B7CFF]/90 active:bg-[#5B7CFF]/80',
      secondary: 'bg-[#FFB833] text-[#111111] border-2 border-[#FFB833] hover:bg-[#FFB833]/90 active:bg-[#FFB833]/80',
      outline: 'bg-transparent text-[#111111] dark:text-[#F7F4ED] border-2 border-[#111111] dark:border-[#F7F4ED] hover:bg-[#111111]/5 dark:hover:bg-[#F7F4ED]/10',
      ghost: 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/5 dark:hover:bg-[#F7F4ED]/10 border-2 border-transparent',
    };

    const sizes = {
      sm: 'h-9 px-3 text-sm',
      md: 'h-12 px-6 text-base font-semibold',
      lg: 'h-14 px-8 text-lg font-bold',
      icon: 'h-12 w-12 flex items-center justify-center p-0',
    };

    return (
      <button
        ref={ref}
        className={cn(
          'inline-flex items-center justify-center transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5B7CFF] disabled:opacity-50 disabled:pointer-events-none uppercase tracking-wide',
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      />
    );
  }
);

Button.displayName = 'Button';
