import React from 'react';
import { cn } from '../../lib/utils';
import { H3 } from './Typography';

interface SectionHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  number?: string;
  action?: React.ReactNode;
}

export function SectionHeader({ title, number, action, className, ...props }: SectionHeaderProps) {
  return (
    <div 
      className={cn(
        "flex items-center justify-between py-4 border-t-4 border-[#111111] dark:border-[#F7F4ED] mb-6", 
        className
      )} 
      {...props}
    >
      <div className="flex items-center gap-4">
        {number && (
          <span className="font-mono text-xl md:text-2xl font-bold text-[#5B7CFF]">
            {number}
          </span>
        )}
        <H3 className="uppercase m-0 leading-none">{title}</H3>
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}
