import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, WifiOff, AlertCircle, Loader2 } from 'lucide-react';
import { useOnsensei } from '../../lib/onsensei/OnsenseiContext';
import { cn } from '../../lib/utils';

export function FloatingOnsenseiButton() {
  const { isOpen, toggleOnsensei, providerStatus, isLoading } = useOnsensei();
  const location = useLocation();
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  // Detect virtual keyboard on mobile devices via visualViewport resize
  useEffect(() => {
    if (typeof window === 'undefined' || !window.visualViewport) return;

    const handleResize = () => {
      if (!window.visualViewport) return;
      // If viewport height shrank significantly (e.g. keyboard popped up)
      const heightRatio = window.visualViewport.height / window.screen.height;
      setIsKeyboardVisible(heightRatio < 0.75);
    };

    window.visualViewport.addEventListener('resize', handleResize);
    return () => {
      window.visualViewport?.removeEventListener('resize', handleResize);
    };
  }, []);

  // Exclude on OAuth callback screens or when chat modal itself is open
  const isCallback = location.pathname.includes('/callback') || location.pathname.includes('/auth/');
  const isWorkoutSession = location.pathname.startsWith('/training/workout/');

  if (isCallback || isOpen || isKeyboardVisible) {
    return null;
  }

  // Positioning:
  // - Primary screens (with 80px bottom nav): bottom-24 (96px from bottom, safely clearing nav)
  // - Workout session screen: bottom-20 (80px from bottom, clearing workout finish bar)
  const bottomClass = isWorkoutSession ? 'bottom-20' : 'bottom-24';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ scale: 0, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0, opacity: 0, y: 20 }}
        transition={{ type: 'spring', stiffness: 350, damping: 25 }}
        className={cn(
          "fixed z-40 right-4 sm:right-6 md:right-8",
          bottomClass,
          "select-none"
        )}
      >
        <motion.button
          id="floating-onsensei-btn"
          onClick={toggleOnsensei}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.94 }}
          aria-label="Open ONSENSEI training assistant"
          className={cn(
            "relative group flex items-center justify-center",
            "w-13 h-13 sm:w-14 sm:h-14 rounded-full",
            "bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111]",
            "border-2 border-[#111111] dark:border-[#F7F4ED]",
            "shadow-[3px_3px_0px_0px_#5B7CFF] active:shadow-none active:translate-x-[2px] active:translate-y-[2px]",
            "transition-all duration-150 cursor-pointer"
          )}
        >
          {/* Main Icon */}
          {isLoading ? (
            <Loader2 size={24} className="animate-spin text-[#FFB833]" />
          ) : providerStatus.code === 'offline' ? (
            <WifiOff size={22} className="text-[#FFB833]" />
          ) : providerStatus.code === 'network_error' || providerStatus.code === 'auth_error' ? (
            <AlertCircle size={22} className="text-[#E63946]" />
          ) : (
            <Brain size={24} className="group-hover:text-[#5B7CFF] transition-colors" />
          )}

          {/* Micro Status Dot */}
          <span
            className={cn(
              "absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-[#F7F4ED] dark:border-[#111111]",
              providerStatus.code === 'ready' && "bg-[#10B981]",
              providerStatus.code === 'offline' && "bg-[#F59E0B]",
              (providerStatus.code === 'network_error' || providerStatus.code === 'auth_error' || providerStatus.code === 'unconfigured') && "bg-[#EF4444]",
              isLoading && "bg-[#3B82F6] animate-ping"
            )}
            title={`ONSENSEI: ${providerStatus.message || providerStatus.code}`}
          />

          {/* Micro Badge Tag for Brand Identity */}
          <span className="sr-only">ONSENSEI Assistant</span>
        </motion.button>
      </motion.div>
    </AnimatePresence>
  );
}
