import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  Trash2, 
  WifiOff, 
  AlertCircle, 
  RefreshCw, 
  CheckCircle2, 
  Brain,
  Sparkles,
  Database
} from 'lucide-react';
import { useOnsensei } from '../../lib/onsensei/OnsenseiContext';
import { H3, H4, Mono } from '../ui/Typography';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { cn } from '../../lib/utils';
import type { OnsenseiMessage } from '../../types';

export function OnsenseiChatModal() {
  const { 
    isOpen, 
    closeOnsensei, 
    messages, 
    isLoading, 
    providerStatus, 
    contextSummary, 
    lastRouting,
    sendMessage, 
    retryMessage, 
    clearHistory 
  } = useOnsensei();

  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading, isOpen]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 250);
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;
    const text = inputText;
    setInputText('');
    await sendMessage(text);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleChipClick = (prompt: string) => {
    setInputText(prompt);
    inputRef.current?.focus();
  };

  if (!isOpen) return null;

  const isOffline = providerStatus.code === 'offline' || (typeof navigator !== 'undefined' && !navigator.onLine);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
        <motion.div
          initial={{ opacity: 0, y: '100%' }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 300 }}
          className={cn(
            "w-full sm:max-w-xl h-[92vh] sm:h-[82vh] flex flex-col",
            "bg-[#F7F4ED] dark:bg-[#111111] text-[#111111] dark:text-[#F7F4ED]",
            "border-t-2 sm:border-2 border-[#111111] dark:border-[#F7F4ED]",
            "shadow-2xl sm:shadow-[8px_8px_0px_0px_#111111] dark:sm:shadow-[8px_8px_0px_0px_#F7F4ED]",
            "rounded-t-2xl sm:rounded-none overflow-hidden"
          )}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#111111] dark:bg-[#F7F4ED] text-[#F7F4ED] dark:text-[#111111] flex items-center justify-center border border-[#111111] dark:border-[#F7F4ED]">
                <Brain size={18} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <H4 className="text-lg font-black tracking-tight leading-none uppercase">ONSENSEI</H4>
                  <Badge variant="accent1" className="text-[9px] py-0 px-1.5 uppercase font-mono">
                    ADVISOR
                  </Badge>
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className={cn(
                    "inline-block w-2 h-2 rounded-full",
                    providerStatus.code === 'ready' ? "bg-[#10B981]" :
                    isOffline ? "bg-[#F59E0B]" : "bg-[#EF4444]"
                  )} />
                  <Mono className="text-[10px] text-[#111111]/70 dark:text-[#F7F4ED]/70 uppercase">
                    {isOffline ? 'OFFLINE' : providerStatus.message || 'ONLINE'}
                  </Mono>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {messages.length > 0 && (
                <button
                  onClick={clearHistory}
                  title="Clear conversation history"
                  aria-label="Clear conversation history"
                  className="p-2 border border-transparent hover:border-[#111111] dark:hover:border-[#F7F4ED] rounded transition-colors text-[#111111]/70 dark:text-[#F7F4ED]/70 hover:text-[#111111] dark:hover:text-[#F7F4ED] cursor-pointer"
                >
                  <Trash2 size={16} />
                </button>
              )}
              <button
                onClick={closeOnsensei}
                aria-label="Close ONSENSEI"
                className="p-1.5 border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] hover:bg-[#111111] hover:text-[#F7F4ED] dark:hover:bg-[#F7F4ED] dark:hover:text-[#111111] rounded transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Context Status Bar */}
          <div className="px-4 py-1.5 bg-[#5B7CFF]/10 border-b border-[#111111]/20 dark:border-[#F7F4ED]/20 flex items-center justify-between text-[11px] font-mono shrink-0">
            <div className="flex items-center gap-1.5 text-[#5B7CFF] dark:text-[#88A2FF]">
              <Database size={13} />
              <span className="font-bold">MODE:</span>
              <span className="truncate max-w-[200px] sm:max-w-[280px]">
                {lastRouting 
                  ? (lastRouting.isFitnessRelevant ? `LOGBOOK: ${lastRouting.categoryLabel.toUpperCase()}` : 'GENERAL AI INTELLIGENCE')
                  : 'READY (GENERAL AI + ONSE FIT)'}
              </span>
            </div>
            <span className="text-[#111111]/60 dark:text-[#F7F4ED]/60 text-[10px] hidden sm:inline">
              {contextSummary?.profileName || 'Athlete'} • {contextSummary?.trainingStreak ?? 0}d STREAK
            </span>
          </div>

          {/* Offline Banner */}
          {isOffline && (
            <div className="bg-[#FFB833]/20 border-b-2 border-[#FFB833] px-4 py-2.5 flex items-start gap-2.5 text-xs shrink-0">
              <WifiOff size={16} className="text-[#B45309] shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-bold font-mono text-[#B45309] uppercase">ONSENSEI OFFLINE</p>
                <p className="text-[#111111]/80 dark:text-[#F7F4ED]/80 text-[11px] mt-0.5">
                  AI consultations are unavailable without an active internet connection. Your workout tracking, sets, and logbook entries remain completely operational offline.
                </p>
              </div>
            </div>
          )}

          {/* Unconfigured Provider Banner */}
          {providerStatus.code === 'unconfigured' && !isOffline && (
            <div className="bg-[#EF4444]/15 border-b-2 border-[#EF4444] px-4 py-2.5 flex items-start gap-2.5 text-xs shrink-0">
              <AlertCircle size={16} className="text-[#EF4444] shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-bold font-mono text-[#EF4444] uppercase">AI PROVIDER NOT CONFIGURED</p>
                <p className="text-[#111111]/80 dark:text-[#F7F4ED]/80 text-[11px] mt-0.5">
                  GEMINI_API_KEY is not configured in the server environment. Please set up your API key in AI Studio Settings to enable live consultations.
                </p>
              </div>
            </div>
          )}

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col justify-center items-center text-center px-4 py-6 max-w-md mx-auto">
                <div className="w-14 h-14 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#FFB833] flex items-center justify-center text-[#111111] mb-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
                  <Sparkles size={24} />
                </div>
                <H3 className="text-xl font-black uppercase mb-1">
                  GENERAL AI + ONSE FIT ADVISOR
                </H3>
                <p className="text-sm text-[#111111]/70 dark:text-[#F7F4ED]/70 mb-6 leading-relaxed">
                  I am ONSENSEI. A general-purpose conversational AI assistant and your disciplined personal strength coach. Ask anything across programming, science, writing, or your authentic ONSE FIT workout logs and personal records.
                </p>

                {/* Suggested Prompts */}
                <div className="w-full space-y-2 text-left">
                  <Mono className="text-[10px] uppercase font-bold text-[#111111]/60 dark:text-[#F7F4ED]/60 mb-1 block text-center">
                    SAMPLE CONSULTATIONS
                  </Mono>
                  {[
                    "Analyze today's workout volume and intensity",
                    "Explain the biological mechanism of progressive overload",
                    "What are my current personal records in ONSE FIT?",
                    "Write a clean TypeScript debounce hook with cancellation"
                  ].map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => handleChipClick(prompt)}
                      className={cn(
                        "w-full px-3 py-2 text-xs font-mono text-left",
                        "bg-[#F7F4ED] dark:bg-[#1A1A1A]",
                        "border-2 border-[#111111] dark:border-[#F7F4ED]",
                        "shadow-[2px_2px_0px_0px_#111111] dark:shadow-[2px_2px_0px_0px_#F7F4ED]",
                        "hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none",
                        "transition-all cursor-pointer truncate"
                      )}
                    >
                      → {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {messages.map((msg) => (
                  <MessageBubble 
                    key={msg.id} 
                    message={msg} 
                    onRetry={() => retryMessage(msg.id)} 
                  />
                ))}

                {/* Loading State */}
                {isLoading && (
                  <div className="flex items-start gap-2.5 max-w-[85%]">
                    <div className="w-7 h-7 rounded-full bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111] flex items-center justify-center shrink-0 border border-[#111111] dark:border-[#F7F4ED] mt-1">
                      <Brain size={14} />
                    </div>
                    <div className={cn(
                      "p-3 rounded-lg border-2 border-[#111111] dark:border-[#F7F4ED]",
                      "bg-[#F7F4ED] dark:bg-[#1A1A1A]",
                      "shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]"
                    )}>
                      <div className="flex items-center gap-2">
                        <Mono className="text-xs font-bold uppercase tracking-wider text-[#5B7CFF]">
                          ONSENSEI is thinking…
                        </Mono>
                        <span className="inline-flex gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#5B7CFF] animate-bounce [animation-delay:-0.3s]" />
                          <span className="w-1.5 h-1.5 rounded-full bg-[#5B7CFF] animate-bounce [animation-delay:-0.15s]" />
                          <span className="w-1.5 h-1.5 rounded-full bg-[#5B7CFF] animate-bounce" />
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Chat Input Bar */}
          <div className="p-3 border-t-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] shrink-0 pb-safe">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-end gap-2"
            >
              <div className="flex-1 relative">
                <textarea
                  ref={inputRef}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={isOffline ? "ONSENSEI is offline..." : "Ask ONSENSEI anything... (workout logs, PRs, coding, writing, or everyday questions)"}
                  disabled={isOffline || isLoading}
                  rows={1}
                  className={cn(
                    "w-full px-3 py-2.5 text-sm font-sans resize-none max-h-24",
                    "bg-[#F7F4ED] dark:bg-[#1A1A1A] text-[#111111] dark:text-[#F7F4ED]",
                    "border-2 border-[#111111] dark:border-[#F7F4ED]",
                    "shadow-[2px_2px_0px_0px_#111111] dark:shadow-[2px_2px_0px_0px_#F7F4ED]",
                    "focus:outline-none focus:ring-2 focus:ring-[#5B7CFF]",
                    "disabled:opacity-50 disabled:cursor-not-allowed"
                  )}
                />
              </div>

              <Button
                type="submit"
                variant="primary"
                disabled={!inputText.trim() || isLoading || isOffline}
                className={cn(
                  "h-10 px-4 shrink-0 flex items-center justify-center font-mono text-xs uppercase",
                  (!inputText.trim() || isLoading || isOffline) && "opacity-50 cursor-not-allowed"
                )}
              >
                <Send size={15} className="mr-1.5" />
                <span>SEND</span>
              </Button>
            </form>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

function MessageBubble({ 
  message, 
  onRetry 
}: { 
  message: OnsenseiMessage; 
  onRetry: () => void; 
}) {
  const isUser = message.role === 'user';
  const isError = message.status === 'error';
  const timeFormatted = new Date(message.timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  return (
    <div className={cn("flex flex-col", isUser ? "items-end" : "items-start")}>
      <div
        className={cn(
          "max-w-[88%] sm:max-w-[80%] p-3.5 rounded-lg border-2",
          isUser
            ? "bg-[#5B7CFF] text-white border-[#111111] shadow-[3px_3px_0px_0px_#111111] dark:border-[#F7F4ED] dark:shadow-[3px_3px_0px_0px_#F7F4ED]"
            : "bg-[#F7F4ED] dark:bg-[#1A1A1A] text-[#111111] dark:text-[#F7F4ED] border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]"
        )}
      >
        {/* Assistant Header Tag */}
        {!isUser && (
          <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
            <span className="font-mono text-[10px] font-black uppercase text-[#5B7CFF] dark:text-[#88A2FF]">
              ONSENSEI {message.model ? `• ${message.model}` : ''}
            </span>
            <span className="font-mono text-[9px] text-[#111111]/50 dark:text-[#F7F4ED]/50">
              {timeFormatted}
            </span>
          </div>
        )}

        {/* Message Content */}
        <div className="text-sm whitespace-pre-wrap leading-relaxed font-sans">
          {message.content}
        </div>

        {/* User Footer with time / error */}
        {isUser && (
          <div className="flex items-center justify-end gap-1.5 mt-1.5 text-[9px] font-mono text-white/80">
            {message.status === 'sending' && <span>Sending...</span>}
            {message.status === 'sent' && <CheckCircle2 size={10} />}
            <span>{timeFormatted}</span>
          </div>
        )}
      </div>

      {/* Error state & Retry button */}
      {isError && (
        <div className="mt-2 max-w-[88%] sm:max-w-[80%] p-2.5 bg-[#EF4444]/10 border-2 border-[#EF4444] text-[#111111] dark:text-[#F7F4ED] shadow-[2px_2px_0px_0px_#EF4444] rounded">
          <div className="flex items-start gap-2 text-xs font-mono text-[#DC2626] dark:text-[#EF4444]">
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold uppercase block text-[11px]">DELIVERY FAILED</span>
              <span className="text-[11px] text-[#111111]/80 dark:text-[#F7F4ED]/80 font-sans block mt-0.5">
                {message.error || 'Failed to communicate with ONSENSEI.'}
              </span>
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-[#EF4444]/20 flex justify-end">
            <button
              onClick={onRetry}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#EF4444] text-white font-mono text-[11px] font-bold uppercase tracking-wider rounded border border-[#EF4444] shadow-[1px_1px_0px_0px_#111111] hover:bg-[#DC2626] active:translate-x-[1px] active:translate-y-[1px] active:shadow-none transition-all cursor-pointer"
            >
              <RefreshCw size={12} />
              RETRY REQUEST
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
