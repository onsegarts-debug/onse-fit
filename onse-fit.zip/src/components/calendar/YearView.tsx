import React from 'react';
import { Dumbbell, Flame, Activity, ArrowRight } from 'lucide-react';
import { Mono, H3, Body } from '../ui/Typography';
import { Badge } from '../ui/Badge';
import { cn } from '../../lib/utils';
import type { MonthSummary } from '../../lib/calendarEngine';

interface YearViewProps {
  year: number;
  months: MonthSummary[];
  totalWorkouts: number;
  totalVolumeKg: number;
  totalActiveDays: number;
  onSelectMonth: (monthIndex: number) => void;
}

export function YearView({
  year,
  months,
  totalWorkouts,
  totalVolumeKg,
  totalActiveDays,
  onSelectMonth,
}: YearViewProps) {
  const currentMonthIndex = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  return (
    <div className="space-y-6">
      {/* Annual Summary Stats Banner */}
      <div className="grid grid-cols-3 gap-2 bg-white dark:bg-[#1A1A1A] p-3 border-2 border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="border-r border-[#111111]/20 dark:border-[#F7F4ED]/20 pr-2">
          <Mono className="text-[9px] uppercase opacity-60 block">WORKOUTS</Mono>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-sans font-black text-lg text-[#111111] dark:text-[#F7F4ED]">
              {totalWorkouts}
            </span>
            <Mono className="text-[10px] text-[#5B7CFF]">SESSIONS</Mono>
          </div>
        </div>

        <div className="border-r border-[#111111]/20 dark:border-[#F7F4ED]/20 px-2">
          <Mono className="text-[9px] uppercase opacity-60 block">VOLUME</Mono>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-sans font-black text-lg text-[#111111] dark:text-[#F7F4ED]">
              {totalVolumeKg > 1000 ? `${(totalVolumeKg / 1000).toFixed(1)}k` : totalVolumeKg}
            </span>
            <Mono className="text-[10px] text-[#5B7CFF]">KG</Mono>
          </div>
        </div>

        <div className="pl-2">
          <Mono className="text-[9px] uppercase opacity-60 block">ACTIVE DAYS</Mono>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-sans font-black text-lg text-[#111111] dark:text-[#F7F4ED]">
              {totalActiveDays}
            </span>
            <Mono className="text-[10px] text-[#5B7CFF]">DAYS</Mono>
          </div>
        </div>
      </div>

      {/* 12-Month Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {months.map((m) => {
          const isThisCurrentMonth = year === currentYear && m.monthIndex === currentMonthIndex;

          return (
            <div
              key={m.monthIndex}
              onClick={() => onSelectMonth(m.monthIndex)}
              className={cn(
                "group relative cursor-pointer border-2 bg-white dark:bg-[#1A1A1A] p-3 transition-all",
                "hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_#5B7CFF]",
                isThisCurrentMonth
                  ? "border-[#5B7CFF] shadow-[3px_3px_0px_0px_#5B7CFF]"
                  : "border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]"
              )}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="font-sans font-black text-sm uppercase tracking-tight text-[#111111] dark:text-[#F7F4ED]">
                    {m.shortMonthName}
                  </span>
                  {isThisCurrentMonth && (
                    <span className="text-[8px] font-mono font-bold px-1 py-0.2 bg-[#5B7CFF] text-white">
                      NOW
                    </span>
                  )}
                </div>
                <ArrowRight size={14} className="opacity-40 group-hover:opacity-100 group-hover:text-[#5B7CFF] transition-all group-hover:translate-x-0.5" />
              </div>

              {/* Quick Metrics */}
              <div className="flex items-center justify-between text-[10px] font-mono mb-2 pb-1.5 border-b border-[#111111]/10 dark:border-[#F7F4ED]/10">
                <span className="text-[#111111]/70 dark:text-[#F7F4ED]/70">
                  {m.totalWorkouts} {m.totalWorkouts === 1 ? 'workout' : 'workouts'}
                </span>
                <span className="font-bold text-[#5B7CFF]">
                  {m.totalVolumeKg > 1000 ? `${(m.totalVolumeKg / 1000).toFixed(1)}k kg` : `${m.totalVolumeKg} kg`}
                </span>
              </div>

              {/* Mini Activity Heatmap Dots */}
              <div className="grid grid-cols-7 gap-1 pt-1">
                {m.days.filter(d => d.isCurrentMonth).map((d) => {
                  let bgClass = "bg-[#111111]/10 dark:bg-[#F7F4ED]/10";
                  if (d.completedWorkouts.length > 0) {
                    bgClass = "bg-[#5B7CFF]";
                  } else if (d.hasWorkouts) {
                    bgClass = "bg-[#FFB833]";
                  } else if (d.activityScore > 0) {
                    bgClass = "bg-[#5B7CFF]/40";
                  }

                  return (
                    <div
                      key={d.date}
                      title={`${d.date}: ${d.completedWorkouts.length} workouts, activity score ${d.activityScore}`}
                      className={cn(
                        "w-full aspect-square rounded-[1px] transition-colors",
                        bgClass,
                        d.isToday && "ring-1 ring-[#111111] dark:ring-[#F7F4ED]"
                      )}
                    />
                  );
                })}
              </div>

              {/* Footer Indicator */}
              <div className="mt-2 flex items-center justify-between text-[9px] font-mono text-[#111111]/50 dark:text-[#F7F4ED]/50">
                <span>{m.activeDaysCount} active days</span>
                {m.habitsAdherencePercent !== null && (
                  <span>{m.habitsAdherencePercent}% habits</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
