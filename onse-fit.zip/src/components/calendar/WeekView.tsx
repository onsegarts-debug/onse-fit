import React from 'react';
import { Dumbbell, Moon, Activity, CheckSquare, Scale, FileText, ChevronRight, Check } from 'lucide-react';
import { Mono, H3 } from '../ui/Typography';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { cn } from '../../lib/utils';
import type { WeekSummary, CalendarDaySummary } from '../../lib/calendarEngine';
import { FULL_DAY_NAMES, MONTH_NAMES } from '../../lib/calendarEngine';

interface WeekViewProps {
  week: WeekSummary;
  onSelectDay: (dateStr: string) => void;
}

export function WeekView({ week, onSelectDay }: WeekViewProps) {
  return (
    <div className="space-y-4">
      {/* Weekly Totals Dashboard */}
      <div className="grid grid-cols-4 gap-2 bg-white dark:bg-[#1A1A1A] p-3 border-2 border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">WORKOUTS</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {week.totalWorkouts}
            <span className="text-[9px] font-mono text-[#5B7CFF] font-normal ml-0.5">done</span>
          </div>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">VOLUME</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {week.totalVolumeKg > 1000 ? `${(week.totalVolumeKg / 1000).toFixed(1)}k` : week.totalVolumeKg}
            <span className="text-[9px] font-mono text-[#5B7CFF] font-normal ml-0.5">kg</span>
          </div>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">AVG SLEEP</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {week.averageSleepHours !== null ? `${week.averageSleepHours}h` : '—'}
          </div>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">HABITS</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {week.habitCompletionRate}%
          </div>
        </div>
      </div>

      {/* 7-Day Journal Feed */}
      <div className="space-y-3">
        {week.days.map((day) => {
          const dateParts = day.date.split('-');
          const yearNum = parseInt(dateParts[0], 10);
          const monthNum = parseInt(dateParts[1], 10) - 1;
          const dayNum = parseInt(dateParts[2], 10);
          const fullDayName = FULL_DAY_NAMES[day.dayOfWeek];
          const formattedHeader = `${fullDayName.toUpperCase()}, ${MONTH_NAMES[monthNum].toUpperCase()} ${dayNum}`;

          return (
            <div
              key={day.date}
              onClick={() => onSelectDay(day.date)}
              className={cn(
                "group cursor-pointer border-2 bg-white dark:bg-[#1A1A1A] p-4 transition-all",
                "hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_#5B7CFF]",
                day.isToday
                  ? "border-[#5B7CFF] shadow-[3px_3px_0px_0px_#5B7CFF]"
                  : "border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]"
              )}
            >
              {/* Day Header */}
              <div className="flex items-center justify-between border-b border-[#111111]/15 dark:border-[#F7F4ED]/15 pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-sans font-black text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED]">
                    {formattedHeader}
                  </span>
                  {day.isToday && (
                    <Badge variant="accent1" className="text-[9px] px-1.5 py-0">
                      TODAY
                    </Badge>
                  )}
                </div>

                <div className="flex items-center gap-1 text-[10px] font-mono text-[#5B7CFF] group-hover:translate-x-0.5 transition-transform">
                  <span>JOURNAL</span>
                  <ChevronRight size={14} />
                </div>
              </div>

              {/* Day Content Summary */}
              <div className="space-y-2.5">
                {/* 1. Workouts */}
                {day.hasWorkouts ? (
                  <div className="space-y-1.5">
                    {day.workouts.map((w) => (
                      <div
                        key={w.id}
                        className={cn(
                          "flex items-center justify-between p-2 text-xs font-mono border",
                          w.completed
                            ? "bg-[#F7F4ED] dark:bg-[#111111] border-[#111111]/30 dark:border-[#F7F4ED]/30"
                            : "bg-[#FFB833]/15 border-[#FFB833]"
                        )}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Dumbbell size={14} className="shrink-0 text-[#5B7CFF]" />
                          <span className="font-bold text-[#111111] dark:text-[#F7F4ED] truncate">
                            {w.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {w.completed ? (
                            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                              <Check size={12} strokeWidth={3} /> COMPLETED
                            </span>
                          ) : (
                            <span className="text-[10px] text-[#FFB833] font-bold">
                              SCHEDULED
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                    {day.totalVolumeKg > 0 && (
                      <div className="text-[10px] font-mono text-right text-[#111111]/70 dark:text-[#F7F4ED]/70">
                        Total Volume: <span className="font-bold text-[#5B7CFF]">{day.totalVolumeKg} kg</span> ({day.totalSets} sets)
                      </div>
                    )}
                  </div>
                ) : null}

                {/* 2. Biometrics & Lifestyle strip */}
                <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
                  {/* Sleep */}
                  {day.hasSleep && (
                    <div className="flex items-center gap-1 px-2 py-1 bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border border-[#111111]/20 dark:border-[#F7F4ED]/20">
                      <Moon size={12} className="text-[#5B7CFF]" />
                      <span>{day.sleepHours}h Sleep</span>
                      {day.sleep?.quality && (
                        <span className="text-[9px] opacity-60">({day.sleep.quality}/5)</span>
                      )}
                    </div>
                  )}

                  {/* Recovery */}
                  {day.hasRecovery && day.readinessScore !== null && (
                    <div className="flex items-center gap-1 px-2 py-1 bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border border-[#111111]/20 dark:border-[#F7F4ED]/20">
                      <Activity size={12} className="text-emerald-500" />
                      <span>{day.readinessScore}% Readiness</span>
                    </div>
                  )}

                  {/* Habits */}
                  {day.hasHabits && (
                    <div className="flex items-center gap-1 px-2 py-1 bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border border-[#111111]/20 dark:border-[#F7F4ED]/20">
                      <CheckSquare size={12} className="text-[#5B7CFF]" />
                      <span>{day.habitsSummary.completed}/{day.habitsSummary.total} Habits</span>
                    </div>
                  )}

                  {/* Body weight */}
                  {day.hasBodyWeight && (
                    <div className="flex items-center gap-1 px-2 py-1 bg-[#111111]/5 dark:bg-[#F7F4ED]/5 border border-[#111111]/20 dark:border-[#F7F4ED]/20">
                      <Scale size={12} />
                      <span>{day.bodyWeight?.weight} kg</span>
                    </div>
                  )}
                </div>

                {/* 3. Notes snippet */}
                {day.hasNotes && (
                  <div className="bg-[#5B7CFF]/5 border-l-2 border-[#5B7CFF] p-2 text-xs font-mono text-[#111111]/80 dark:text-[#F7F4ED]/80 line-clamp-2">
                    <span className="font-bold text-[#5B7CFF] mr-1">[Journal]</span>
                    {day.notes[0].content}
                    {day.notes.length > 1 && (
                      <span className="ml-1 text-[10px] opacity-60 font-bold">
                        (+{day.notes.length - 1} more)
                      </span>
                    )}
                  </div>
                )}

                {/* 4. Empty State if nothing logged */}
                {!day.hasWorkouts && !day.hasSleep && !day.hasRecovery && !day.hasBodyWeight && !day.hasNotes && (
                  <div className="py-2 text-xs font-mono text-[#111111]/40 dark:text-[#F7F4ED]/40 italic">
                    Rest or unrecorded day. Tap to open journal and log activities.
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
