import React from 'react';
import { Dumbbell, Moon, Activity, CheckSquare, Scale, FileText, ChevronRight } from 'lucide-react';
import { Mono } from '../ui/Typography';
import { cn } from '../../lib/utils';
import type { MonthSummary, CalendarDaySummary } from '../../lib/calendarEngine';
import { SHORT_DAY_NAMES } from '../../lib/calendarEngine';

interface MonthViewProps {
  month: MonthSummary;
  onSelectDay: (dateStr: string) => void;
  onSelectWeek: (referenceDateStr: string) => void;
}

export function MonthView({
  month,
  onSelectDay,
  onSelectWeek
}: MonthViewProps) {
  // Group days into 7-day rows (weeks)
  const weeks: CalendarDaySummary[][] = [];
  for (let i = 0; i < month.days.length; i += 7) {
    weeks.push(month.days.slice(i, i + 7));
  }

  return (
    <div className="space-y-4">
      {/* Month Highlights Banner */}
      <div className="grid grid-cols-4 gap-2 bg-white dark:bg-[#1A1A1A] p-3 border-2 border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">WORKOUTS</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {month.completedWorkoutsCount}
            <span className="text-[10px] font-mono text-[#5B7CFF] font-normal ml-0.5">/{month.totalWorkouts}</span>
          </div>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">VOLUME</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {month.totalVolumeKg > 1000 ? `${(month.totalVolumeKg / 1000).toFixed(1)}k` : month.totalVolumeKg}
            <span className="text-[9px] font-mono text-[#5B7CFF] font-normal ml-0.5">kg</span>
          </div>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">AVG SLEEP</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {month.averageSleepHours !== null ? `${month.averageSleepHours}h` : '—'}
          </div>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">HABITS</Mono>
          <div className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
            {month.habitsAdherencePercent !== null ? `${month.habitsAdherencePercent}%` : '—'}
          </div>
        </div>
      </div>

      {/* Calendar Grid Container */}
      <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] overflow-hidden">
        {/* Weekday Names Header */}
        <div className="grid grid-cols-7 border-b-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111]">
          {SHORT_DAY_NAMES.map((dayName) => (
            <div
              key={dayName}
              className="py-2 text-center text-[10px] font-mono font-black text-[#111111] dark:text-[#F7F4ED]"
            >
              {dayName}
            </div>
          ))}
        </div>

        {/* Weeks Rows */}
        <div className="divide-y divide-[#111111]/20 dark:divide-[#F7F4ED]/20">
          {weeks.map((week, wIdx) => {
            const mondayDate = week[0].date;

            return (
              <div key={wIdx} className="relative group/week">
                {/* Week Action Tab */}
                <button
                  onClick={() => onSelectWeek(mondayDate)}
                  title="View this entire week"
                  className="absolute -left-1 top-1/2 -translate-y-1/2 z-10 hidden sm:flex items-center justify-center h-6 px-1 bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111] text-[8px] font-mono font-bold opacity-0 group-hover/week:opacity-100 transition-opacity"
                >
                  WK <ChevronRight size={10} />
                </button>

                <div className="grid grid-cols-7 divide-x divide-[#111111]/15 dark:divide-[#F7F4ED]/15">
                  {week.map((day) => {
                    return (
                      <div
                        key={day.date}
                        onClick={() => onSelectDay(day.date)}
                        className={cn(
                          "min-h-[72px] sm:min-h-[84px] p-1.5 flex flex-col justify-between cursor-pointer transition-all hover:bg-[#5B7CFF]/10",
                          !day.isCurrentMonth && "bg-[#111111]/5 dark:bg-[#F7F4ED]/5 text-opacity-40",
                          day.isToday && "ring-2 ring-inset ring-[#5B7CFF] bg-[#5B7CFF]/5"
                        )}
                      >
                        {/* Day Number Header */}
                        <div className="flex items-center justify-between">
                          <span
                            className={cn(
                              "text-xs font-mono font-bold leading-none",
                              day.isToday
                                ? "bg-[#5B7CFF] text-white px-1 py-0.5"
                                : day.isCurrentMonth
                                ? "text-[#111111] dark:text-[#F7F4ED]"
                                : "text-[#111111]/30 dark:text-[#F7F4ED]/30"
                            )}
                          >
                            {day.dayNumber}
                          </span>

                          {/* Top indicator: Notes presence */}
                          {day.hasNotes && (
                            <FileText size={10} className="text-[#5B7CFF]" />
                          )}
                        </div>

                        {/* Middle Activity Indicators */}
                        <div className="space-y-1 my-1">
                          {/* Workouts indicator */}
                          {day.hasWorkouts && (
                            <div
                              className={cn(
                                "flex items-center gap-0.5 px-1 py-0.5 text-[9px] font-mono font-bold leading-none rounded-none truncate",
                                day.completedWorkouts.length > 0
                                  ? "bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111]"
                                  : "bg-[#FFB833] text-[#111111]"
                              )}
                              title={day.workouts.map(w => w.name).join(', ')}
                            >
                              <Dumbbell size={9} strokeWidth={2.5} className="shrink-0" />
                              <span className="truncate">
                                {day.completedWorkouts.length > 0
                                  ? `${day.totalVolumeKg > 0 ? `${day.totalVolumeKg}kg` : 'Done'}`
                                  : 'Planned'}
                              </span>
                            </div>
                          )}

                          {/* Sleep & Recovery badges */}
                          {(day.hasSleep || day.hasRecovery) && (
                            <div className="flex items-center gap-1 text-[8px] font-mono text-[#111111]/80 dark:text-[#F7F4ED]/80">
                              {day.hasSleep && (
                                <span className="flex items-center gap-0.5" title={`Sleep: ${day.sleepHours}h`}>
                                  <Moon size={8} className="text-[#5B7CFF]" />
                                  <span>{day.sleepHours}h</span>
                                </span>
                              )}
                              {day.readinessScore !== null && (
                                <span className="text-[7px] font-bold text-emerald-600 dark:text-emerald-400">
                                  {day.readinessScore}%
                                </span>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Bottom Row: Habits & Weight dots */}
                        <div className="flex items-center justify-between text-[8px] font-mono text-[#111111]/50 dark:text-[#F7F4ED]/50 pt-0.5">
                          {day.hasHabits && day.habitsSummary.total > 0 ? (
                            <span
                              className={cn(
                                "text-[8px] font-bold",
                                day.habitsSummary.percentage === 100
                                  ? "text-emerald-600 dark:text-emerald-400"
                                  : day.habitsSummary.completed > 0
                                  ? "text-[#5B7CFF]"
                                  : "text-[#111111]/40 dark:text-[#F7F4ED]/40"
                              )}
                            >
                              {day.habitsSummary.completed}/{day.habitsSummary.total}
                            </span>
                          ) : (
                            <span />
                          )}

                          {day.hasBodyWeight && (
                            <span title={`Weight: ${day.bodyWeight?.weight}kg`} className="text-[#111111] dark:text-[#F7F4ED]">
                              <Scale size={9} />
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Legend & Help */}
      <div className="flex flex-wrap items-center justify-between text-[10px] font-mono text-[#111111]/60 dark:text-[#F7F4ED]/60 pt-1 px-1">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 bg-[#111111] dark:bg-[#F7F4ED] inline-block" /> Completed
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 bg-[#FFB833] inline-block" /> Scheduled
          </span>
          <span className="flex items-center gap-1">
            <Moon size={10} className="text-[#5B7CFF]" /> Sleep
          </span>
          <span className="flex items-center gap-1">
            <FileText size={10} className="text-[#5B7CFF]" /> Journal
          </span>
        </div>
        <span className="italic">Tap any day for details</span>
      </div>
    </div>
  );
}
