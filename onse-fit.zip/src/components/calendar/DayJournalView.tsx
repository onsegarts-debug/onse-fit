import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Dumbbell, Moon, Activity, CheckSquare, Scale, 
  FileText, Plus, Check, Trash2, Edit3, X, Ruler, ArrowRight, Clock,
  Disc3, ExternalLink
} from 'lucide-react';
import { Mono, H2, H3, Body } from '../ui/Typography';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { cn } from '../../lib/utils';
import type { DayJournalDetail } from '../../lib/calendarEngine';

interface DayJournalViewProps {
  dayDetail: DayJournalDetail;
  onAddNote: (content: string, type: 'general' | 'training' | 'lifestyle') => Promise<void>;
  onDeleteNote: (id: string) => Promise<void>;
  onToggleHabit: (habitId: string, currentCompleted: boolean, logId?: string) => Promise<void>;
  onSaveSleep: (durationMinutes: number, quality?: number, notes?: string) => Promise<void>;
  onSaveRecovery: (soreness: number, energy: number, stress: number, rating: number, notes?: string) => Promise<void>;
  onSaveBodyWeight: (weight: number, notes?: string) => Promise<void>;
  onAddMeasurement: (type: string, value: number, unit: string, notes?: string) => Promise<void>;
  onCreateWorkoutForDate: (date: string) => Promise<void>;
}

export function DayJournalView({
  dayDetail,
  onAddNote,
  onDeleteNote,
  onToggleHabit,
  onSaveSleep,
  onSaveRecovery,
  onSaveBodyWeight,
  onAddMeasurement,
  onCreateWorkoutForDate
}: DayJournalViewProps) {
  const navigate = useNavigate();

  // Note composer state
  const [noteContent, setNoteContent] = useState('');
  const [noteType, setNoteType] = useState<'general' | 'training' | 'lifestyle'>('training');
  const [isSubmittingNote, setIsSubmittingNote] = useState(false);

  // Sleep logger modal/form state
  const [showSleepForm, setShowSleepForm] = useState(false);
  const [sleepHoursInput, setSleepHoursInput] = useState(
    dayDetail.sleep?.durationMinutes ? (dayDetail.sleep.durationMinutes / 60).toString() : '7.5'
  );
  const [sleepQualityInput, setSleepQualityInput] = useState(dayDetail.sleep?.quality || 4);
  const [sleepNotesInput, setSleepNotesInput] = useState(dayDetail.sleep?.notes || '');

  // Recovery logger state
  const [showRecoveryForm, setShowRecoveryForm] = useState(false);
  const [recoverySoreness, setRecoverySoreness] = useState(dayDetail.recovery?.soreness || 3);
  const [recoveryEnergy, setRecoveryEnergy] = useState(dayDetail.recovery?.energy || 4);
  const [recoveryStress, setRecoveryStress] = useState(dayDetail.recovery?.stress || 2);
  const [recoveryNotes, setRecoveryNotes] = useState(dayDetail.recovery?.notes || '');

  // Body weight logger state
  const [showWeightForm, setShowWeightForm] = useState(false);
  const [weightInput, setWeightInput] = useState(dayDetail.bodyWeight?.weight ? dayDetail.bodyWeight.weight.toString() : '');
  const [weightNotes, setWeightNotes] = useState(dayDetail.bodyWeight?.notes || '');

  // Measurement logger state
  const [showMeasurementForm, setShowMeasurementForm] = useState(false);
  const [measType, setMeasType] = useState('Waist');
  const [measValue, setMeasValue] = useState('');
  const [measUnit, setMeasUnit] = useState('cm');

  // Handle note submission
  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;
    setIsSubmittingNote(true);
    try {
      await onAddNote(noteContent.trim(), noteType);
      setNoteContent('');
    } finally {
      setIsSubmittingNote(false);
    }
  };

  // Handle sleep save
  const handleSaveSleep = async (e: React.FormEvent) => {
    e.preventDefault();
    const hours = parseFloat(sleepHoursInput);
    if (isNaN(hours) || hours <= 0) return;
    await onSaveSleep(Math.round(hours * 60), sleepQualityInput, sleepNotesInput.trim());
    setShowSleepForm(false);
  };

  // Handle recovery save
  const handleSaveRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveRecovery(recoverySoreness, recoveryEnergy, recoveryStress, recoveryEnergy, recoveryNotes.trim());
    setShowRecoveryForm(false);
  };

  // Handle weight save
  const handleSaveWeight = async (e: React.FormEvent) => {
    e.preventDefault();
    const weight = parseFloat(weightInput);
    if (isNaN(weight) || weight <= 0) return;
    await onSaveBodyWeight(weight, weightNotes.trim());
    setShowWeightForm(false);
  };

  // Handle measurement save
  const handleSaveMeasurement = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(measValue);
    if (isNaN(val) || val <= 0) return;
    await onAddMeasurement(measType, val, measUnit);
    setMeasValue('');
    setShowMeasurementForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Daily Metrics Snapshot Bar */}
      <div className="grid grid-cols-4 gap-2 bg-white dark:bg-[#1A1A1A] p-3 border-2 border-[#111111] dark:border-[#F7F4ED] shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">VOLUME</Mono>
          <div className="font-sans font-black text-sm text-[#111111] dark:text-[#F7F4ED]">
            {dayDetail.stats.totalVolumeKg > 0 ? `${dayDetail.stats.totalVolumeKg} kg` : '0 kg'}
          </div>
          <Mono className="text-[9px] text-[#5B7CFF]">{dayDetail.stats.totalSets} sets</Mono>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">SLEEP</Mono>
          <div className="font-sans font-black text-sm text-[#111111] dark:text-[#F7F4ED]">
            {dayDetail.stats.sleepHours !== null ? `${dayDetail.stats.sleepHours}h` : '—'}
          </div>
          <Mono className="text-[9px] text-[#5B7CFF]">
            {dayDetail.sleep?.quality ? `Q${dayDetail.sleep.quality}/5` : 'Rest'}
          </Mono>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">HABITS</Mono>
          <div className="font-sans font-black text-sm text-[#111111] dark:text-[#F7F4ED]">
            {dayDetail.stats.habitsCompletedCount}/{dayDetail.stats.habitsTotalCount}
          </div>
          <Mono className="text-[9px] text-[#5B7CFF]">
            {dayDetail.stats.habitsTotalCount > 0 
              ? `${Math.round((dayDetail.stats.habitsCompletedCount / dayDetail.stats.habitsTotalCount) * 100)}%` 
              : 'None'}
          </Mono>
        </div>

        <div>
          <Mono className="text-[8px] uppercase opacity-60 block">READINESS</Mono>
          <div className="font-sans font-black text-sm text-[#111111] dark:text-[#F7F4ED]">
            {dayDetail.stats.readinessScore !== null ? `${dayDetail.stats.readinessScore}%` : '—'}
          </div>
          <Mono className="text-[9px] text-emerald-600 dark:text-emerald-400 font-bold">
            {dayDetail.recovery ? 'Logged' : 'Pending'}
          </Mono>
        </div>
      </div>

      {/* 1. JOURNAL NOTES & REFLECTION */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
          <div className="flex items-center gap-2">
            <FileText size={16} className="text-[#5B7CFF]" />
            <h3 className="font-sans font-bold text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED] uppercase">
              JOURNAL & NOTES
            </h3>
          </div>
          <Mono className="text-[10px] text-[#111111]/60 dark:text-[#F7F4ED]/60">
            {dayDetail.notes.length} {dayDetail.notes.length === 1 ? 'entry' : 'entries'}
          </Mono>
        </div>

        {/* Existing Notes List */}
        {dayDetail.notes.length > 0 ? (
          <div className="space-y-2 mb-4">
            {dayDetail.notes.map((note) => (
              <div
                key={note.id}
                className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border border-[#111111]/20 dark:border-[#F7F4ED]/20 relative group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <Badge
                    variant={
                      note.type === 'training'
                        ? 'accent1'
                        : note.type === 'lifestyle'
                        ? 'accent2'
                        : 'outline'
                    }
                    className="text-[8px] px-1.5 py-0"
                  >
                    {note.type.toUpperCase()}
                  </Badge>

                  <button
                    onClick={() => onDeleteNote(note.id)}
                    className="opacity-40 hover:opacity-100 hover:text-red-500 transition-opacity p-1"
                    title="Delete Note"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
                <p className="font-mono text-xs text-[#111111] dark:text-[#F7F4ED] whitespace-pre-wrap leading-relaxed">
                  {note.content}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs font-mono text-[#111111]/40 dark:text-[#F7F4ED]/40 italic mb-4">
            No journal entries for this date. Record training feedback, nutrition notes, or daily mindset below.
          </p>
        )}

        {/* Quick Note Composer */}
        <form onSubmit={handleCreateNote} className="space-y-2 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono text-[#111111]/60 dark:text-[#F7F4ED]/60 uppercase">
              Tag:
            </span>
            {(['training', 'lifestyle', 'general'] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setNoteType(t)}
                className={cn(
                  "px-2 py-0.5 text-[9px] font-mono font-bold uppercase transition-colors border",
                  noteType === t
                    ? "bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111] border-[#111111] dark:border-[#F7F4ED]"
                    : "bg-transparent text-[#111111]/60 dark:text-[#F7F4ED]/60 border-[#111111]/20 dark:border-[#F7F4ED]/20 hover:border-[#111111] dark:hover:border-[#F7F4ED]"
                )}
              >
                {t}
              </button>
            ))}
          </div>

          <textarea
            value={noteContent}
            onChange={(e) => setNoteContent(e.target.value)}
            placeholder="Write journal entry or session reflection..."
            rows={2}
            className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2.5 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] placeholder:text-[#111111]/40 dark:placeholder:text-[#F7F4ED]/40 focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
          />

          <div className="flex justify-end">
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmittingNote || !noteContent.trim()}
              className="text-xs font-mono font-bold py-1.5 px-3"
            >
              SAVE NOTE
            </Button>
          </div>
        </form>
      </section>

      {/* 2. WORKOUTS SECTION */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
          <div className="flex items-center gap-2">
            <Dumbbell size={16} className="text-[#5B7CFF]" />
            <h3 className="font-sans font-bold text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED] uppercase">
              WORKOUTS ({dayDetail.workouts.length})
            </h3>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onCreateWorkoutForDate(dayDetail.date)}
            className="h-7 text-[10px] font-mono font-bold px-2 flex items-center gap-1"
          >
            <Plus size={12} /> ADD WORKOUT
          </Button>
        </div>

        {dayDetail.workouts.length > 0 ? (
          <div className="space-y-3">
            {dayDetail.workouts.map((w) => (
              <div
                key={w.id}
                className="border-2 border-[#111111] dark:border-[#F7F4ED] p-3 bg-[#F7F4ED] dark:bg-[#111111]"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-sans font-bold text-sm text-[#111111] dark:text-[#F7F4ED]">
                      {w.name}
                    </h4>
                    {w.notes && (
                      <p className="text-[11px] font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 italic mt-0.5">
                        {w.notes}
                      </p>
                    )}
                    {w.spotifyPlaylistName && (
                      <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-[#1DB954]">
                        <Disc3 size={13} className="shrink-0" />
                        <span className="font-bold truncate uppercase">{w.spotifyPlaylistName}</span>
                      </div>
                    )}
                  </div>

                  <Badge
                    variant={w.completed ? 'default' : 'accent2'}
                    className="text-[9px] px-1.5 py-0.5"
                  >
                    {w.completed ? 'COMPLETED' : 'SCHEDULED'}
                  </Badge>
                </div>

                {/* Exercises summary breakdown */}
                {w.exercises.length > 0 ? (
                  <div className="divide-y divide-[#111111]/10 dark:divide-[#F7F4ED]/10 border-t border-b border-[#111111]/15 dark:border-[#F7F4ED]/15 my-2 py-1">
                    {w.exercises.map((ex, idx) => (
                      <div key={idx} className="py-1 flex items-center justify-between text-xs font-mono">
                        <span className="font-bold text-[#111111] dark:text-[#F7F4ED]">
                          {ex.exerciseName}
                        </span>
                        <span className="text-[#111111]/70 dark:text-[#F7F4ED]/70 text-[11px]">
                          {ex.setsCount} sets • Best: {ex.bestSet.weight}kg × {ex.bestSet.reps}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs font-mono text-[#111111]/50 dark:text-[#F7F4ED]/50 my-2 italic">
                    No exercises logged yet in this session.
                  </div>
                )}

                {/* Workout Footer */}
                <div className="flex items-center justify-between pt-1">
                  <div className="text-xs font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70">
                    Volume: <span className="font-bold text-[#5B7CFF]">{w.totalVolumeKg} kg</span> ({w.totalSets} completed sets)
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate(`/training/workout/${w.id}`)}
                    className="h-7 text-[10px] font-mono font-bold px-2 flex items-center gap-1"
                  >
                    OPEN SESSION <ArrowRight size={12} />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4 bg-[#F7F4ED]/50 dark:bg-[#111111]/50 border border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 p-4">
            <p className="text-xs font-mono text-[#111111]/60 dark:text-[#F7F4ED]/60 mb-2">
              No workout recorded on this date.
            </p>
            <Button
              variant="primary"
              size="sm"
              onClick={() => onCreateWorkoutForDate(dayDetail.date)}
              className="text-xs font-mono font-bold"
            >
              LOG WORKOUT ON {dayDetail.shortDate.toUpperCase()}
            </Button>
          </div>
        )}
      </section>

      {/* 3. HABITS CHECKLIST */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
          <div className="flex items-center gap-2">
            <CheckSquare size={16} className="text-[#5B7CFF]" />
            <h3 className="font-sans font-bold text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED] uppercase">
              HABITS ADHERENCE
            </h3>
          </div>
          <Mono className="text-[10px] font-bold text-[#5B7CFF]">
            {dayDetail.stats.habitsCompletedCount} OF {dayDetail.stats.habitsTotalCount} COMPLETED
          </Mono>
        </div>

        {dayDetail.habits.length > 0 ? (
          <div className="space-y-2">
            {dayDetail.habits.map((item) => (
              <div
                key={item.habit.id}
                onClick={() => onToggleHabit(item.habit.id, item.completed, item.logId)}
                className={cn(
                  "flex items-center justify-between p-2.5 border-2 cursor-pointer transition-all",
                  item.completed
                    ? "bg-[#5B7CFF]/10 border-[#5B7CFF]"
                    : "bg-[#F7F4ED] dark:bg-[#111111] border-[#111111]/20 dark:border-[#F7F4ED]/20 hover:border-[#111111] dark:hover:border-[#F7F4ED]"
                )}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={cn(
                      "w-5 h-5 border-2 flex items-center justify-center transition-colors",
                      item.completed
                        ? "bg-[#5B7CFF] border-[#5B7CFF] text-white"
                        : "border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#111111]"
                    )}
                  >
                    {item.completed && <Check size={14} strokeWidth={3} />}
                  </div>
                  <span
                    className={cn(
                      "text-xs font-mono font-bold",
                      item.completed
                        ? "line-through text-[#111111]/60 dark:text-[#F7F4ED]/60"
                        : "text-[#111111] dark:text-[#F7F4ED]"
                    )}
                  >
                    {item.habit.name}
                  </span>
                </div>

                <Mono className="text-[9px] text-[#111111]/50 dark:text-[#F7F4ED]/50">
                  {item.completed ? 'COMPLETED' : 'TAP TO LOG'}
                </Mono>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-xs font-mono text-[#111111]/40 dark:text-[#F7F4ED]/40 italic py-2">
            No active habits tracked yet. Create habits in the Lifestyle tab to track them here.
          </div>
        )}
      </section>

      {/* 4. SLEEP & REST */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
          <div className="flex items-center gap-2">
            <Moon size={16} className="text-[#5B7CFF]" />
            <h3 className="font-sans font-bold text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED] uppercase">
              SLEEP & RECOVERY
            </h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSleepForm(!showSleepForm)}
            className="h-7 text-[10px] font-mono font-bold px-2 flex items-center gap-1"
          >
            {dayDetail.sleep ? <Edit3 size={12} /> : <Plus size={12} />}
            {dayDetail.sleep ? 'EDIT SLEEP' : 'LOG SLEEP'}
          </Button>
        </div>

        {showSleepForm ? (
          <form onSubmit={handleSaveSleep} className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border-2 border-[#111111] dark:border-[#F7F4ED] space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Duration (Hours)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="24"
                  value={sleepHoursInput}
                  onChange={(e) => setSleepHoursInput(e.target.value)}
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Quality (1-5)</label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setSleepQualityInput(q)}
                      className={cn(
                        "flex-1 py-1.5 text-xs font-mono font-bold border-2",
                        sleepQualityInput === q
                          ? "bg-[#5B7CFF] text-white border-[#5B7CFF]"
                          : "border-[#111111]/30 dark:border-[#F7F4ED]/30"
                      )}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="text-[10px] font-mono uppercase block mb-1">Notes</label>
              <input
                type="text"
                value={sleepNotesInput}
                onChange={(e) => setSleepNotesInput(e.target.value)}
                placeholder="e.g. Woke up once, felt refreshed..."
                className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowSleepForm(false)}>
                CANCEL
              </Button>
              <Button type="submit" variant="primary" size="sm">
                SAVE SLEEP
              </Button>
            </div>
          </form>
        ) : dayDetail.sleep ? (
          <div className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border border-[#111111]/20 dark:border-[#F7F4ED]/20 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-sans font-black text-base text-[#111111] dark:text-[#F7F4ED]">
                {dayDetail.stats.sleepHours} Hours
              </span>
              <span className="text-xs font-mono font-bold text-[#5B7CFF]">
                Quality: {dayDetail.sleep.quality || '—'}/5
              </span>
            </div>
            {dayDetail.sleep.notes && (
              <p className="text-xs font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 italic pt-1">
                "{dayDetail.sleep.notes}"
              </p>
            )}
          </div>
        ) : (
          <div className="text-xs font-mono text-[#111111]/40 dark:text-[#F7F4ED]/40 italic py-2">
            No sleep entry recorded for this date.
          </div>
        )}
      </section>

      {/* 5. RECOVERY READINESS & BIOMETRICS */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
          <div className="flex items-center gap-2">
            <Activity size={16} className="text-emerald-500" />
            <h3 className="font-sans font-bold text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED] uppercase">
              RECOVERY READINESS
            </h3>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowRecoveryForm(!showRecoveryForm)}
            className="h-7 text-[10px] font-mono font-bold px-2 flex items-center gap-1"
          >
            {dayDetail.recovery ? <Edit3 size={12} /> : <Plus size={12} />}
            {dayDetail.recovery ? 'EDIT RECOVERY' : 'LOG RECOVERY'}
          </Button>
        </div>

        {showRecoveryForm ? (
          <form onSubmit={handleSaveRecovery} className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border-2 border-[#111111] dark:border-[#F7F4ED] space-y-3">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[9px] font-mono uppercase block mb-1">Soreness (1-5)</label>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setRecoverySoreness(s)}
                      className={cn(
                        "flex-1 py-1 text-xs font-mono font-bold border",
                        recoverySoreness === s ? "bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111]" : "border-[#111111]/20"
                      )}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[9px] font-mono uppercase block mb-1">Energy (1-5)</label>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((e) => (
                    <button
                      key={e}
                      type="button"
                      onClick={() => setRecoveryEnergy(e)}
                      className={cn(
                        "flex-1 py-1 text-xs font-mono font-bold border",
                        recoveryEnergy === e ? "bg-[#5B7CFF] text-white" : "border-[#111111]/20"
                      )}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[9px] font-mono uppercase block mb-1">Stress (1-5)</label>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setRecoveryStress(st)}
                      className={cn(
                        "flex-1 py-1 text-xs font-mono font-bold border",
                        recoveryStress === st ? "bg-[#FFB833] text-[#111111]" : "border-[#111111]/20"
                      )}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="text-[10px] font-mono uppercase block mb-1">Recovery Notes</label>
              <input
                type="text"
                value={recoveryNotes}
                onChange={(e) => setRecoveryNotes(e.target.value)}
                placeholder="Legs feel heavy after squats..."
                className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowRecoveryForm(false)}>
                CANCEL
              </Button>
              <Button type="submit" variant="primary" size="sm">
                SAVE RECOVERY
              </Button>
            </div>
          </form>
        ) : dayDetail.recovery ? (
          <div className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border border-[#111111]/20 dark:border-[#F7F4ED]/20">
            <div className="flex items-center justify-between mb-2">
              <span className="font-sans font-black text-lg text-emerald-600 dark:text-emerald-400">
                {dayDetail.stats.readinessScore}% Readiness
              </span>
              <Badge variant="outline" className="text-[9px]">
                RATING: {dayDetail.recovery.rating}/5
              </Badge>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono border-t border-[#111111]/10 dark:border-[#F7F4ED]/10 pt-2">
              <div>
                <span className="text-[9px] opacity-60 block">SORENESS</span>
                <span className="font-bold">{dayDetail.recovery.soreness}/5</span>
              </div>
              <div>
                <span className="text-[9px] opacity-60 block">ENERGY</span>
                <span className="font-bold text-[#5B7CFF]">{dayDetail.recovery.energy}/5</span>
              </div>
              <div>
                <span className="text-[9px] opacity-60 block">STRESS</span>
                <span className="font-bold">{dayDetail.recovery.stress}/5</span>
              </div>
            </div>

            {dayDetail.recovery.notes && (
              <p className="text-xs font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 italic mt-2 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10">
                "{dayDetail.recovery.notes}"
              </p>
            )}
          </div>
        ) : (
          <div className="text-xs font-mono text-[#111111]/40 dark:text-[#F7F4ED]/40 italic py-2">
            No recovery metrics recorded for this date.
          </div>
        )}
      </section>

      {/* 6. BODY WEIGHT & MEASUREMENTS */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED]">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#111111]/15 dark:border-[#F7F4ED]/15">
          <div className="flex items-center gap-2">
            <Scale size={16} className="text-[#5B7CFF]" />
            <h3 className="font-sans font-bold text-sm tracking-tight text-[#111111] dark:text-[#F7F4ED] uppercase">
              BODY WEIGHT & MEASUREMENTS
            </h3>
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowWeightForm(!showWeightForm)}
              className="h-7 text-[10px] font-mono font-bold px-2"
            >
              {dayDetail.bodyWeight ? 'EDIT WEIGHT' : '+ WEIGHT'}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowMeasurementForm(!showMeasurementForm)}
              className="h-7 text-[10px] font-mono font-bold px-2"
            >
              + MEASURE
            </Button>
          </div>
        </div>

        {/* Weight Form */}
        {showWeightForm && (
          <form onSubmit={handleSaveWeight} className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border-2 border-[#111111] dark:border-[#F7F4ED] mb-3 space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Weight (kg)</label>
                <input
                  type="number"
                  step="0.1"
                  value={weightInput}
                  onChange={(e) => setWeightInput(e.target.value)}
                  placeholder="e.g. 80.5"
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono font-bold"
                  required
                />
              </div>
              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Notes</label>
                <input
                  type="text"
                  value={weightNotes}
                  onChange={(e) => setWeightNotes(e.target.value)}
                  placeholder="Morning weigh-in..."
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowWeightForm(false)}>
                CANCEL
              </Button>
              <Button type="submit" variant="primary" size="sm">
                SAVE WEIGHT
              </Button>
            </div>
          </form>
        )}

        {/* Measurement Form */}
        {showMeasurementForm && (
          <form onSubmit={handleSaveMeasurement} className="p-3 bg-[#F7F4ED] dark:bg-[#111111] border-2 border-[#111111] dark:border-[#F7F4ED] mb-3 space-y-2">
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Type</label>
                <select
                  value={measType}
                  onChange={(e) => setMeasType(e.target.value)}
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono"
                >
                  <option value="Waist">Waist</option>
                  <option value="Chest">Chest</option>
                  <option value="Arms">Arms</option>
                  <option value="Thighs">Thighs</option>
                  <option value="Hips">Hips</option>
                  <option value="Shoulders">Shoulders</option>
                  <option value="Calves">Calves</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Value</label>
                <input
                  type="number"
                  step="0.1"
                  value={measValue}
                  onChange={(e) => setMeasValue(e.target.value)}
                  placeholder="e.g. 82.5"
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase block mb-1">Unit</label>
                <select
                  value={measUnit}
                  onChange={(e) => setMeasUnit(e.target.value)}
                  className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-transparent p-2 text-xs font-mono"
                >
                  <option value="cm">cm</option>
                  <option value="in">in</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowMeasurementForm(false)}>
                CANCEL
              </Button>
              <Button type="submit" variant="primary" size="sm">
                SAVE MEASUREMENT
              </Button>
            </div>
          </form>
        )}

        {/* Display Logged Weight */}
        {dayDetail.bodyWeight ? (
          <div className="p-2.5 bg-[#F7F4ED] dark:bg-[#111111] border border-[#111111]/20 dark:border-[#F7F4ED]/20 mb-2 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono opacity-60 block">BODY WEIGHT</span>
              <span className="font-sans font-black text-lg text-[#111111] dark:text-[#F7F4ED]">
                {dayDetail.bodyWeight.weight} kg
              </span>
              {dayDetail.bodyWeight.notes && (
                <span className="text-xs font-mono opacity-70 ml-2 italic">
                  ({dayDetail.bodyWeight.notes})
                </span>
              )}
            </div>
          </div>
        ) : null}

        {/* Display Logged Measurements */}
        {dayDetail.measurements.length > 0 ? (
          <div className="grid grid-cols-2 gap-2 mt-2">
            {dayDetail.measurements.map((m) => (
              <div
                key={m.id}
                className="p-2 bg-[#F7F4ED] dark:bg-[#111111] border border-[#111111]/20 dark:border-[#F7F4ED]/20"
              >
                <span className="text-[9px] font-mono opacity-60 block uppercase">{m.type}</span>
                <span className="font-sans font-bold text-sm text-[#111111] dark:text-[#F7F4ED]">
                  {m.value} {m.unit}
                </span>
              </div>
            ))}
          </div>
        ) : null}

        {!dayDetail.bodyWeight && dayDetail.measurements.length === 0 && !showWeightForm && !showMeasurementForm && (
          <div className="text-xs font-mono text-[#111111]/40 dark:text-[#F7F4ED]/40 italic py-2">
            No body weight or circumference measurements recorded for this date.
          </div>
        )}
      </section>
    </div>
  );
}
