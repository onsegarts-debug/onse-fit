import React from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { H1, Mono } from '../ui/Typography';
import { Button } from '../ui/Button';
import { cn } from '../../lib/utils';
import type { CalendarViewMode } from '../../lib/calendarEngine';
import { MONTH_NAMES } from '../../lib/calendarEngine';

interface CalendarHeaderProps {
  viewMode: CalendarViewMode;
  onViewModeChange: (mode: CalendarViewMode) => void;
  title: string;
  subtitle?: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
  breadcrumbs?: {
    year: number;
    month?: number;
    week?: number;
    day?: string;
  };
  onBreadcrumbClick?: (level: 'year' | 'month' | 'week') => void;
}

export function CalendarHeader({
  viewMode,
  onViewModeChange,
  title,
  subtitle,
  onPrev,
  onNext,
  onToday,
  breadcrumbs,
  onBreadcrumbClick
}: CalendarHeaderProps) {
  const modes: Array<{ id: CalendarViewMode; label: string }> = [
    { id: 'year', label: 'YEAR' },
    { id: 'month', label: 'MONTH' },
    { id: 'week', label: 'WEEK' },
    { id: 'day', label: 'DAY' },
  ];

  return (
    <div className="space-y-4 mb-6">
      {/* Page Title & Breadcrumb */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <H1 className="text-2xl font-black tracking-tight">CALENDAR</H1>
            <div className="bg-[#5B7CFF] text-white p-1 rounded-sm">
              <CalendarIcon size={16} strokeWidth={2.5} />
            </div>
          </div>
          <Mono className="text-xs text-[#5B7CFF] font-bold mt-0.5 block">
            FITNESS JOURNAL & TIMELINE
          </Mono>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-0.5">
          {modes.map((m) => (
            <button
              key={m.id}
              onClick={() => onViewModeChange(m.id)}
              className={cn(
                "px-2.5 py-1 text-[10px] font-mono font-bold uppercase transition-all",
                viewMode === m.id
                  ? "bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111]"
                  : "text-[#111111]/70 dark:text-[#F7F4ED]/70 hover:bg-[#111111]/10 dark:hover:bg-[#F7F4ED]/10"
              )}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Breadcrumb Hierarchy */}
      {breadcrumbs && (
        <div className="flex items-center gap-1 text-[11px] font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 overflow-x-auto pb-0.5">
          <button
            onClick={() => onBreadcrumbClick?.('year')}
            className={cn(
              "hover:text-[#5B7CFF] transition-colors underline decoration-dotted",
              viewMode === 'year' && "font-bold text-[#111111] dark:text-[#F7F4ED] no-underline"
            )}
          >
            {breadcrumbs.year}
          </button>
          {breadcrumbs.month !== undefined && (
            <>
              <span>/</span>
              <button
                onClick={() => onBreadcrumbClick?.('month')}
                className={cn(
                  "hover:text-[#5B7CFF] transition-colors underline decoration-dotted",
                  viewMode === 'month' && "font-bold text-[#111111] dark:text-[#F7F4ED] no-underline"
                )}
              >
                {MONTH_NAMES[breadcrumbs.month]}
              </button>
            </>
          )}
          {breadcrumbs.week !== undefined && (
            <>
              <span>/</span>
              <button
                onClick={() => onBreadcrumbClick?.('week')}
                className={cn(
                  "hover:text-[#5B7CFF] transition-colors underline decoration-dotted",
                  viewMode === 'week' && "font-bold text-[#111111] dark:text-[#F7F4ED] no-underline"
                )}
              >
                Wk {breadcrumbs.week}
              </button>
            </>
          )}
          {breadcrumbs.day && viewMode === 'day' && (
            <>
              <span>/</span>
              <span className="font-bold text-[#5B7CFF]">
                {breadcrumbs.day}
              </span>
            </>
          )}
        </div>
      )}

      {/* Interval Navigation Controls */}
      <div className="flex items-center justify-between bg-white dark:bg-[#1A1A1A] p-3 border-2 border-[#111111] dark:border-[#F7F4ED] shadow-[2px_2px_0px_0px_#111111] dark:shadow-[2px_2px_0px_0px_#F7F4ED]">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={onPrev}
            className="p-1.5 h-8 w-8"
            aria-label="Previous Period"
          >
            <ChevronLeft size={18} strokeWidth={2.5} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onNext}
            className="p-1.5 h-8 w-8"
            aria-label="Next Period"
          >
            <ChevronRight size={18} strokeWidth={2.5} />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onToday}
            className="h-8 px-2 text-[10px] font-mono font-bold"
          >
            TODAY
          </Button>
        </div>

        <div className="text-right">
          <div className="font-sans font-black text-sm uppercase tracking-tight text-[#111111] dark:text-[#F7F4ED]">
            {title}
          </div>
          {subtitle && (
            <Mono className="text-[10px] text-[#111111]/60 dark:text-[#F7F4ED]/60 block">
              {subtitle}
            </Mono>
          )}
        </div>
      </div>
    </div>
  );
}
