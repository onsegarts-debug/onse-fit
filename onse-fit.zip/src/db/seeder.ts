import { db } from './index';
import { exercisesRepo } from './api';

const DEFAULT_EXERCISES = [
  { id: crypto.randomUUID(), name: 'Bench Press (Barbell)', targetMuscle: 'Chest', category: 'Chest', isArchived: false },
  { id: crypto.randomUUID(), name: 'Squat (Barbell)', targetMuscle: 'Legs', category: 'Legs', isArchived: false },
  { id: crypto.randomUUID(), name: 'Deadlift (Barbell)', targetMuscle: 'Back', category: 'Back', isArchived: false },
  { id: crypto.randomUUID(), name: 'Overhead Press (Dumbbell)', targetMuscle: 'Shoulders', category: 'Shoulders', isArchived: false },
  { id: crypto.randomUUID(), name: 'Pull Up', targetMuscle: 'Back', category: 'Back', isArchived: false },
  { id: crypto.randomUUID(), name: 'Barbell Row', targetMuscle: 'Back', category: 'Back', isArchived: false },
  { id: crypto.randomUUID(), name: 'Bicep Curl (Dumbbell)', targetMuscle: 'Biceps', category: 'Arms', isArchived: false },
  { id: crypto.randomUUID(), name: 'Tricep Extension (Cable)', targetMuscle: 'Triceps', category: 'Arms', isArchived: false },
  { id: crypto.randomUUID(), name: 'Leg Press', targetMuscle: 'Legs', category: 'Legs', isArchived: false },
  { id: crypto.randomUUID(), name: 'Calf Raise', targetMuscle: 'Calves', category: 'Legs', isArchived: false },
];

export async function seedDatabase() {
  const count = await db.exercises.count();
  if (count === 0) {
    console.log('Seeding default exercises...');
    await db.exercises.bulkAdd(DEFAULT_EXERCISES);
  }
}
