import { db } from './index';

/**
 * Safe execution wrapper for database operations.
 * Provides consistent error logging and transaction handling.
 */
export async function safeDbOperation<T>(operation: () => Promise<T>): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    console.error('ONSE FIT Database Error:', error);
    // Re-throw with a user-friendly message, mimicking standard SQLite offline app behavior
    throw new Error('Local database operation failed. Ensure your device has enough storage.');
  }
}

/**
 * Generic CRUD Interface for ONSE FIT Entities
 * Abstracting Dexie methods to feel like standard Repository operations
 */
export class Repository<T extends { id: string }> {
  private table: any; // Dexie Table reference

  constructor(tableName: keyof typeof db) {
    this.table = db[tableName as any];
  }

  async get(id: string): Promise<T | undefined> {
    return safeDbOperation(() => this.table.get(id));
  }

  async getAll(): Promise<T[]> {
    return safeDbOperation(() => this.table.toArray());
  }

  async create(item: T): Promise<string> {
    return safeDbOperation(() => this.table.add(item));
  }

  async update(id: string, changes: Partial<T>): Promise<number> {
    return safeDbOperation(() => this.table.update(id, changes));
  }

  async delete(id: string): Promise<void> {
    return safeDbOperation(() => this.table.delete(id));
  }
}

// Instantiate specific repositories
export const profilesRepo = new Repository<any>('profiles');
export const programsRepo = new Repository<any>('programs');
export const workoutsRepo = new Repository<any>('workouts');
export const exercisesRepo = new Repository<any>('exercises');
export const workoutExercisesRepo = new Repository<any>('workoutExercises');
export const setsRepo = new Repository<any>('sets');
export const recordsRepo = new Repository<any>('personalRecords');
export const bodyWeightRepo = new Repository<any>('bodyWeights');
export const measurementsRepo = new Repository<any>('measurements');
export const progressPhotosRepo = new Repository<any>('progressPhotos');
export const sleepRepo = new Repository<any>('sleepEntries');
export const habitsRepo = new Repository<any>('habits');
export const habitLogsRepo = new Repository<any>('habitLogs');
export const recoveryRepo = new Repository<any>('recoveryEntries');
export const notesRepo = new Repository<any>('notes');
export const remindersRepo = new Repository<any>('reminders');
export const spotifyAssociationsRepo = new Repository<any>('spotifyAssociations');

// AppSettings has a different primary key ('key' instead of 'id')
export const settingsRepo = {
  get: async (key: string) => safeDbOperation(() => db.appSettings.get(key)),
  set: async (key: string, value: any) => safeDbOperation(() => db.appSettings.put({ key, value })),
  delete: async (key: string) => safeDbOperation(() => db.appSettings.delete(key))
};

/**
 * Complex Transactions (Example)
 * e.g., Deleting a workout should delete its exercises and sets.
 */
export async function deleteWorkoutCascade(workoutId: string) {
  return safeDbOperation(async () => {
    await db.transaction('rw', db.workouts, db.workoutExercises, db.sets, async () => {
      // 1. Get all workout exercises for this workout
      const wExercises = await db.workoutExercises.where({ workoutId }).toArray();
      const wExerciseIds = wExercises.map(e => e.id);

      // 2. Delete all sets belonging to those exercises
      await db.sets.where('workoutExerciseId').anyOf(wExerciseIds).delete();

      // 3. Delete the workout exercises
      await db.workoutExercises.where({ workoutId }).delete();

      // 4. Delete the workout itself
      await db.workouts.delete(workoutId);
    });
  });
}
