/**
 * ONSE FIT
 * Local Database Foundation (IndexedDB via Dexie)
 * This acts as the offline-first SQLite equivalent for the web.
 */
import Dexie, { type EntityTable } from 'dexie';
import type { 
  Profile, Program, Workout, Exercise, WorkoutExercise, Set, 
  PersonalRecord, BodyWeight, Measurement, ProgressPhoto, SleepEntry, Habit, 
  HabitLog, RecoveryEntry, Note, Reminder, AppSetting, SpotifyAssociation,
  OnsenseiMessage
} from '../types';

const db = new Dexie('OnseFitDatabase') as Dexie & {
  profiles: EntityTable<Profile, 'id'>;
  programs: EntityTable<Program, 'id'>;
  workouts: EntityTable<Workout, 'id'>;
  exercises: EntityTable<Exercise, 'id'>;
  workoutExercises: EntityTable<WorkoutExercise, 'id'>;
  sets: EntityTable<Set, 'id'>;
  personalRecords: EntityTable<PersonalRecord, 'id'>;
  bodyWeights: EntityTable<BodyWeight, 'id'>;
  measurements: EntityTable<Measurement, 'id'>;
  progressPhotos: EntityTable<ProgressPhoto, 'id'>;
  sleepEntries: EntityTable<SleepEntry, 'id'>;
  habits: EntityTable<Habit, 'id'>;
  habitLogs: EntityTable<HabitLog, 'id'>;
  recoveryEntries: EntityTable<RecoveryEntry, 'id'>;
  notes: EntityTable<Note, 'id'>;
  reminders: EntityTable<Reminder, 'id'>;
  appSettings: EntityTable<AppSetting, 'key'>;
  spotifyAssociations: EntityTable<SpotifyAssociation, 'id'>;
  onsenseiMessages: EntityTable<OnsenseiMessage, 'id'>;
};

// Schema declaration: Primary keys and indexed properties
db.version(3).stores({
  profiles: 'id', // only one profile expected, but keeping id as PK
  programs: 'id, name',
  workouts: 'id, programId, date',
  exercises: 'id, targetMuscle, category, isArchived',
  workoutExercises: 'id, workoutId, exerciseId',
  sets: 'id, workoutExerciseId',
  personalRecords: 'id, exerciseId, type, date',
  bodyWeights: 'id, date',
  measurements: 'id, type, date',
  progressPhotos: 'id, date, pose, isPrivate',
  sleepEntries: 'id, date',
  habits: 'id',
  habitLogs: 'id, habitId, date, [habitId+date]', // Compound index for quick lookups
  recoveryEntries: 'id, date',
  notes: 'id, date, type',
  reminders: 'id',
  appSettings: 'key'
});

db.version(4).stores({
  spotifyAssociations: 'id, type, targetId, playlistId',
  workouts: 'id, programId, date, spotifyPlaylistId',
  programs: 'id, name, spotifyPlaylistId'
});

db.version(5).stores({
  onsenseiMessages: 'id, conversationId, timestamp, role'
});

export { db };
