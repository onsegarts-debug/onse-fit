import React from 'react';
import { useNavigate as useAppNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { H1, Mono, Body, H3 } from '../components/ui/Typography';
import { SectionHeader } from '../components/ui/SectionHeader';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { db } from '../db';
import { workoutsRepo } from '../db/api';

export function Training() {
  const navigate = useAppNavigate();
  
  const recentWorkouts = useLiveQuery(
    () => db.workouts.orderBy('date').reverse().limit(5).toArray()
  );

  const startEmptyWorkout = async () => {
    const newWorkoutId = crypto.randomUUID();
    const today = new Date();
    
    await workoutsRepo.create({
      id: newWorkoutId,
      name: 'Freestyle Workout',
      date: today.toISOString().split('T')[0],
      startTime: today.toISOString(),
      completed: false,
    });
    
    navigate(`/training/workout/${newWorkoutId}`);
  };

  return (
    <div className="p-6">
      <H1 className="mb-2">TRAINING</H1>
      <Mono className="text-[#5B7CFF] mb-8 block">LOGBOOK</Mono>

      <Button onClick={startEmptyWorkout} variant="primary" className="w-full mb-8">
        START EMPTY WORKOUT
      </Button>

      <SectionHeader title="Recent Logs" number="01" />
      
      <div className="space-y-4">
        {recentWorkouts === undefined ? (
          <Mono className="opacity-50">Loading...</Mono>
        ) : recentWorkouts.length === 0 ? (
          <div className="p-8 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
            <Mono className="opacity-50">NO RECENT WORKOUTS</Mono>
          </div>
        ) : (
          recentWorkouts.map((w) => (
            <div 
              key={w.id} 
              onClick={() => navigate(`/training/workout/${w.id}`)}
              className="border-2 border-[#111111] dark:border-[#F7F4ED] p-4 flex justify-between items-center bg-[#F7F4ED] dark:bg-[#111111] shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] cursor-pointer hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_#111111] dark:hover:shadow-[2px_2px_0px_0px_#F7F4ED] transition-all"
            >
              <div>
                <H3 className="text-lg">{w.name}</H3>
                <Mono className="opacity-60">{w.date}</Mono>
              </div>
              <div>
                <Badge variant={w.completed ? 'default' : 'accent2'}>
                  {w.completed ? 'COMPLETED' : 'IN PROGRESS'}
                </Badge>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
