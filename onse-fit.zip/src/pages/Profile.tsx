import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BoardingPass } from '../components/profile/BoardingPass';
import { SectionHeader } from '../components/ui/SectionHeader';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Settings, LogOut, Disc3, ChevronRight } from 'lucide-react';
import { useSpotify } from '../lib/spotify/SpotifyContext';

export function Profile() {
  const navigate = useNavigate();
  const { status, user } = useSpotify();

  return (
    <div className="p-6 space-y-8 pb-28">
      <BoardingPass />
      
      {/* Integrations Section */}
      <section>
        <SectionHeader title="Integrations" />
        <div className="flex flex-col gap-3">
          <div
            onClick={() => navigate('/profile/integrations/spotify')}
            className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 flex items-center justify-between cursor-pointer shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED] hover:translate-x-[1px] hover:translate-y-[1px] transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#1DB954]/15 flex items-center justify-center">
                <Disc3 size={22} className="text-[#1DB954]" />
              </div>
              <div>
                <div className="font-sans font-bold text-sm uppercase text-[#111111] dark:text-[#F7F4ED]">
                  SPOTIFY
                </div>
                <div className="font-mono text-xs opacity-60">
                  {status === 'connected' 
                    ? `Connected as ${user?.displayName || 'User'}`
                    : 'Workout Music & Playlists'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {status === 'connected' && (
                <Badge variant="default" className="text-[9px] bg-[#1DB954] text-black border-[#111111]">
                  CONNECTED
                </Badge>
              )}
              {status === 'disconnected' && (
                <Badge variant="outline" className="text-[9px] opacity-60">
                  DISCONNECTED
                </Badge>
              )}
              {status === 'connecting' && (
                <Badge variant="outline" className="text-[9px] text-[#5B7CFF]">
                  CONNECTING
                </Badge>
              )}
              {status === 'auth_required' && (
                <Badge variant="outline" className="text-[9px] text-amber-500">
                  RE-AUTH
                </Badge>
              )}
              {status === 'network_unavailable' && (
                <Badge variant="accent2" className="text-[9px]">
                  OFFLINE
                </Badge>
              )}
              {status === 'permission_denied' && (
                <Badge variant="outline" className="text-[9px] text-red-500">
                  DENIED
                </Badge>
              )}
              {status === 'spotify_unavailable' && (
                <Badge variant="outline" className="text-[9px] text-amber-500">
                  UNAVAILABLE
                </Badge>
              )}
              {status === 'auth_failed' && (
                <Badge variant="outline" className="text-[9px] text-red-500">
                  ERROR
                </Badge>
              )}
              <ChevronRight size={18} className="opacity-50" />
            </div>
          </div>
        </div>
      </section>

      <section>
        <SectionHeader title="Settings" />
        <div className="flex flex-col gap-4">
          <Button variant="outline" className="justify-start gap-3">
            <Settings size={18} />
            Application Preferences
          </Button>
          <Button variant="ghost" className="justify-start gap-3 text-red-500 hover:text-red-600 dark:hover:bg-red-500/10 hover:bg-red-500/10">
            <LogOut size={18} />
            Sign Out
          </Button>
        </div>
      </section>
    </div>
  );
}
