import React from 'react';
import { BoardingPass } from '../components/profile/BoardingPass';
import { SectionHeader } from '../components/ui/SectionHeader';
import { Button } from '../components/ui/Button';
import { Settings, LogOut } from 'lucide-react';

export function Profile() {
  return (
    <div className="p-6 space-y-8">
      <BoardingPass />
      
      <section>
        <SectionHeader title="Settings" />
        <div className="flex flex-col gap-4">
          <Button variant="outline" className="justify-start gap-3">
            <Settings size={18} />
            Application Preferences
          </Button>
          <Button variant="ghost" className="justify-start gap-3 text-red-500 hover:text-red-600 dark:hover:bg-red-500/10 hover:bg-red-500/10">
            <LogOut size={18} />
            Sign Out
          </Button>
        </div>
      </section>
    </div>
  );
}
