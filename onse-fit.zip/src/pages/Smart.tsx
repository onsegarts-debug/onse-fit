import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import { H1, Mono, Body } from '../components/ui/Typography';
import { Button } from '../components/ui/Button';
import { 
  generateDailySummary,
  generateWeeklySummary,
  generateTrainingConsistency,
  generateVolumeChanges,
  generatePREvents,
  generateMissedWorkouts,
  generateRecoveryOverview,
  generateFactualInsights
} from '../lib/smartTrackEngine';
import { DailySummaryCard } from '../components/smart/DailySummaryCard';
import { WeeklySummaryCard } from '../components/smart/WeeklySummaryCard';
import { TrainingConsistencyCard } from '../components/smart/TrainingConsistencyCard';
import { VolumeChangesCard } from '../components/smart/VolumeChangesCard';
import { PREventsFeed } from '../components/smart/PREventsFeed';
import { MissedWorkoutsCard } from '../components/smart/MissedWorkoutsCard';
import { RecoveryOverviewCard } from '../components/smart/RecoveryOverviewCard';
import { FactualInsightsFeed } from '../components/smart/FactualInsightsFeed';
import { SmartVerificationModal } from '../components/smart/SmartVerificationModal';
import { seedBenchmarkData } from '../lib/benchmarkData';
import { 
  Calendar, CalendarRange, Target, Layers, Trophy, 
  CalendarX2, HeartPulse, Cpu, ShieldCheck, Database, LayoutGrid
} from 'lucide-react';

type SmartTab = 
  | 'overview' 
  | 'daily' 
  | 'weekly' 
  | 'consistency' 
  | 'volume' 
  | 'prs' 
  | 'missed' 
  | 'recovery' 
  | 'insights';

export function Smart() {
  const [activeTab, setActiveTab] = useState<SmartTab>('overview');
  const [selectedDate, setSelectedDate] = useState<string>(() => 
    new Date().toISOString().split('T')[0]
  );
  const [weeklyOffsetWeeks, setWeeklyOffsetWeeks] = useState<number>(0);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  // Reactive DB queries using Dexie LiveQuery
  const workouts = useLiveQuery(() => db.workouts.toArray()) || [];
  const workoutExercises = useLiveQuery(() => db.workoutExercises.toArray()) || [];
  const sets = useLiveQuery(() => db.sets.toArray()) || [];
  const exercises = useLiveQuery(() => db.exercises.toArray()) || [];
  const sleepEntries = useLiveQuery(() => db.sleepEntries.toArray()) || [];
  const recoveryEntries = useLiveQuery(() => db.recoveryEntries.toArray()) || [];
  const habits = useLiveQuery(() => db.habits.toArray()) || [];
  const habitLogs = useLiveQuery(() => db.habitLogs.toArray()) || [];
  const bodyWeights = useLiveQuery(() => db.bodyWeights.toArray()) || [];
  const profiles = useLiveQuery(() => db.profiles.toArray()) || [];

  const targetWorkoutsPerWeek = 4; // Default standard frequency target

  // Calculate weekly reference date from offset
  const weeklyTargetDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + weeklyOffsetWeeks * 7);
    return d.toISOString().split('T')[0];
  }, [weeklyOffsetWeeks]);

  // Deterministic computations from local database
  const dailySummary = useMemo(() => {
    return generateDailySummary(
      selectedDate,
      workouts,
      workoutExercises,
      sets,
      exercises,
      sleepEntries,
      recoveryEntries,
      habits,
      habitLogs,
      bodyWeights
    );
  }, [selectedDate, workouts, workoutExercises, sets, exercises, sleepEntries, recoveryEntries, habits, habitLogs, bodyWeights]);

  const weeklySummary = useMemo(() => {
    return generateWeeklySummary(
      weeklyTargetDate,
      targetWorkoutsPerWeek,
      workouts,
      workoutExercises,
      sets,
      exercises,
      sleepEntries,
      recoveryEntries
    );
  }, [weeklyTargetDate, workouts, workoutExercises, sets, exercises, sleepEntries, recoveryEntries]);

  const trainingConsistency = useMemo(() => {
    return generateTrainingConsistency(workouts, targetWorkoutsPerWeek);
  }, [workouts]);

  const volumeChanges = useMemo(() => {
    return generateVolumeChanges(workouts, workoutExercises, sets, exercises);
  }, [workouts, workoutExercises, sets, exercises]);

  const prEvents = useMemo(() => {
    return generatePREvents(workouts, workoutExercises, sets, exercises);
  }, [workouts, workoutExercises, sets, exercises]);

  const missedWorkouts = useMemo(() => {
    return generateMissedWorkouts(workouts, targetWorkoutsPerWeek);
  }, [workouts]);

  const recoveryOverview = useMemo(() => {
    return generateRecoveryOverview(workouts, workoutExercises, sets, sleepEntries, recoveryEntries);
  }, [workouts, workoutExercises, sets, sleepEntries, recoveryEntries]);

  const factualInsights = useMemo(() => {
    return generateFactualInsights(
      dailySummary,
      weeklySummary,
      trainingConsistency,
      volumeChanges,
      prEvents,
      missedWorkouts,
      recoveryOverview
    );
  }, [dailySummary, weeklySummary, trainingConsistency, volumeChanges, prEvents, missedWorkouts, recoveryOverview]);

  const totalCompletedWorkouts = useMemo(() => {
    return workouts.filter(w => w.completed).length;
  }, [workouts]);

  const hasAnyData = totalCompletedWorkouts > 0 || sleepEntries.length > 0 || recoveryEntries.length > 0;

  const handleSeedBenchmark = async () => {
    setIsSeeding(true);
    try {
      await seedBenchmarkData();
    } catch (e) {
      console.error(e);
    } finally {
      setIsSeeding(false);
    }
  };

  const tabs = [
    { id: 'overview' as SmartTab, label: 'OVERVIEW', icon: LayoutGrid },
    { id: 'daily' as SmartTab, label: 'DAILY', icon: Calendar },
    { id: 'weekly' as SmartTab, label: 'WEEKLY', icon: CalendarRange },
    { id: 'consistency' as SmartTab, label: 'CONSISTENCY', icon: Target },
    { id: 'volume' as SmartTab, label: 'VOLUME', icon: Layers },
    { id: 'prs' as SmartTab, label: 'PR EVENTS', icon: Trophy },
    { id: 'missed' as SmartTab, label: 'MISSED', icon: CalendarX2 },
    { id: 'recovery' as SmartTab, label: 'RECOVERY', icon: HeartPulse },
    { id: 'insights' as SmartTab, label: 'INSIGHTS', icon: Cpu },
  ];

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-4">
        <div>
          <H1 className="tracking-tight text-3xl sm:text-4xl">SMART TRACK</H1>
          <Mono className="text-[#5B7CFF] text-xs font-bold uppercase tracking-widest mt-1 block">
            LOCAL INTELLIGENCE ENGINE — ZERO SIMULATION / FACTUAL SQLite ANALYTICS
          </Mono>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsTestModalOpen(true)}
            className="text-xs flex items-center gap-1.5 shrink-0"
          >
            <ShieldCheck size={14} className="text-[#5B7CFF]" />
            VERIFY ENGINE FORMULAS
          </Button>
        </div>
      </div>

      {/* Global Empty State Banner when database is completely bare */}
      {!hasAnyData && (
        <div className="border-2 border-dashed border-[#111111]/40 dark:border-[#F7F4ED]/40 p-6 sm:p-8 bg-white/20 dark:bg-black/20 text-center space-y-4">
          <div className="max-w-xl mx-auto space-y-2">
            <Mono className="text-xs font-bold text-[#5B7CFF] uppercase">
              LOCAL DATABASE AWAITING TRAINING DATA
            </Mono>
            <H1 className="text-xl sm:text-2xl font-bold tracking-tight">
              NO LOCAL LOGS FOUND
            </H1>
            <Body className="text-xs opacity-75 leading-relaxed font-mono">
              The Smart Track Engine operates deterministically on actual stored SQLite/IndexedDB records. 
              Complete workouts in Training and log sleep in Lifestyle, or seed the 4-week benchmark dataset to explore and test all engine analytics.
            </Body>
          </div>

          <div className="flex justify-center gap-3">
            <Button
              variant="primary"
              size="sm"
              onClick={handleSeedBenchmark}
              disabled={isSeeding}
              className="font-mono text-xs flex items-center gap-2"
            >
              <Database size={14} />
              {isSeeding ? 'SEEDING LOCAL DATABASE...' : 'SEED 4-WEEK BENCHMARK DATA'}
            </Button>
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex flex-wrap border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-1 gap-1 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 min-w-[105px] py-2 px-2.5 flex items-center justify-center gap-1.5 font-mono text-xs font-bold uppercase transition-colors ${
                isActive
                  ? 'bg-[#5B7CFF] text-white'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/5 dark:hover:bg-[#F7F4ED]/5'
              }`}
            >
              <Icon size={14} className={isActive ? 'text-white' : 'text-[#5B7CFF]'} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div className="space-y-6 pt-1">
        {/* OVERVIEW (Unified View) */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <FactualInsightsFeed insights={factualInsights} />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DailySummaryCard
                summary={dailySummary}
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
              />
              <WeeklySummaryCard
                summary={weeklySummary}
                onNavigateWeek={(delta) => setWeeklyOffsetWeeks(prev => prev + delta)}
                onResetToCurrentWeek={() => setWeeklyOffsetWeeks(0)}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <TrainingConsistencyCard consistency={trainingConsistency} />
              <VolumeChangesCard volume={volumeChanges} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <MissedWorkoutsCard missedData={missedWorkouts} />
              <RecoveryOverviewCard recovery={recoveryOverview} />
            </div>

            <PREventsFeed prData={prEvents} />
          </div>
        )}

        {/* DAILY SUMMARY */}
        {activeTab === 'daily' && (
          <DailySummaryCard
            summary={dailySummary}
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
          />
        )}

        {/* WEEKLY SUMMARY */}
        {activeTab === 'weekly' && (
          <WeeklySummaryCard
            summary={weeklySummary}
            onNavigateWeek={(delta) => setWeeklyOffsetWeeks(prev => prev + delta)}
            onResetToCurrentWeek={() => setWeeklyOffsetWeeks(0)}
          />
        )}

        {/* TRAINING CONSISTENCY */}
        {activeTab === 'consistency' && (
          <TrainingConsistencyCard consistency={trainingConsistency} />
        )}

        {/* VOLUME CHANGES */}
        {activeTab === 'volume' && (
          <VolumeChangesCard volume={volumeChanges} />
        )}

        {/* PR EVENTS */}
        {activeTab === 'prs' && (
          <PREventsFeed prData={prEvents} />
        )}

        {/* MISSED WORKOUTS */}
        {activeTab === 'missed' && (
          <MissedWorkoutsCard missedData={missedWorkouts} />
        )}

        {/* RECOVERY OVERVIEW */}
        {activeTab === 'recovery' && (
          <RecoveryOverviewCard recovery={recoveryOverview} />
        )}

        {/* FACTUAL INSIGHTS */}
        {activeTab === 'insights' && (
          <FactualInsightsFeed insights={factualInsights} />
        )}
      </div>

      {/* Verification Suite Modal */}
      <SmartVerificationModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
      />
    </div>
  );
}
