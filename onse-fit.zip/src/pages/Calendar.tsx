import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db';
import { 
  notesRepo, habitLogsRepo, sleepRepo, 
  recoveryRepo, bodyWeightRepo, measurementsRepo, workoutsRepo 
} from '../db/api';
import { 
  CalendarViewMode,
  buildDatabaseDateIndexes,
  getYearData,
  getMonthData,
  getWeekData,
  getDayJournalData,
  toDateString,
  parseDateString,
  MONTH_NAMES,
  getIsoWeekNumber,
  getMondayOfWeek
} from '../lib/calendarEngine';
import { CalendarHeader } from '../components/calendar/CalendarHeader';
import { YearView } from '../components/calendar/YearView';
import { MonthView } from '../components/calendar/MonthView';
import { WeekView } from '../components/calendar/WeekView';
import { DayJournalView } from '../components/calendar/DayJournalView';

export function Calendar() {
  const navigate = useNavigate();

  // Navigation states
  const today = new Date();
  const todayStr = toDateString(today);

  const [viewMode, setViewMode] = useState<CalendarViewMode>('month');
  const [currentYear, setCurrentYear] = useState<number>(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState<number>(today.getMonth());
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [referenceWeekDate, setReferenceWeekDate] = useState<string>(todayStr);

  // Live queries from SQLite / Dexie
  const workouts = useLiveQuery(() => db.workouts.toArray()) || [];
  const workoutExercises = useLiveQuery(() => db.workoutExercises.toArray()) || [];
  const sets = useLiveQuery(() => db.sets.toArray()) || [];
  const exercises = useLiveQuery(() => db.exercises.toArray()) || [];
  const sleepEntries = useLiveQuery(() => db.sleepEntries.toArray()) || [];
  const habits = useLiveQuery(() => db.habits.toArray()) || [];
  const habitLogs = useLiveQuery(() => db.habitLogs.toArray()) || [];
  const recoveryEntries = useLiveQuery(() => db.recoveryEntries.toArray()) || [];
  const bodyWeights = useLiveQuery(() => db.bodyWeights.toArray()) || [];
  const measurements = useLiveQuery(() => db.measurements.toArray()) || [];
  const notes = useLiveQuery(() => db.notes.toArray()) || [];

  // 1. Build pre-indexed date maps for rapid O(1) lookups
  const dateIndexes = useMemo(() => {
    return buildDatabaseDateIndexes(
      workouts,
      workoutExercises,
      sets,
      sleepEntries,
      habits,
      habitLogs,
      recoveryEntries,
      bodyWeights,
      measurements,
      notes
    );
  }, [
    workouts, workoutExercises, sets, sleepEntries, 
    habits, habitLogs, recoveryEntries, bodyWeights, measurements, notes
  ]);

  // 2. Computed View Models
  const yearData = useMemo(() => {
    return getYearData(currentYear, dateIndexes);
  }, [currentYear, dateIndexes]);

  const monthData = useMemo(() => {
    return getMonthData(currentYear, currentMonth, dateIndexes);
  }, [currentYear, currentMonth, dateIndexes]);

  const weekData = useMemo(() => {
    return getWeekData(referenceWeekDate, dateIndexes);
  }, [referenceWeekDate, dateIndexes]);

  const dayJournalDetail = useMemo(() => {
    return getDayJournalData(
      selectedDate,
      workouts,
      workoutExercises,
      sets,
      exercises,
      sleepEntries,
      habits,
      habitLogs,
      recoveryEntries,
      bodyWeights,
      measurements,
      notes
    );
  }, [
    selectedDate, workouts, workoutExercises, sets, exercises, 
    sleepEntries, habits, habitLogs, recoveryEntries, bodyWeights, measurements, notes
  ]);

  // Navigation handlers
  const handlePrev = () => {
    if (viewMode === 'year') {
      setCurrentYear(prev => prev - 1);
    } else if (viewMode === 'month') {
      if (currentMonth === 0) {
        setCurrentMonth(11);
        setCurrentYear(prev => prev - 1);
      } else {
        setCurrentMonth(prev => prev - 1);
      }
    } else if (viewMode === 'week') {
      const cur = parseDateString(referenceWeekDate);
      cur.setDate(cur.getDate() - 7);
      const newRef = toDateString(cur);
      setReferenceWeekDate(newRef);
      setSelectedDate(newRef);
    } else if (viewMode === 'day') {
      const cur = parseDateString(selectedDate);
      cur.setDate(cur.getDate() - 1);
      const newDate = toDateString(cur);
      setSelectedDate(newDate);
      setReferenceWeekDate(newDate);
      setCurrentMonth(cur.getMonth());
      setCurrentYear(cur.getFullYear());
    }
  };

  const handleNext = () => {
    if (viewMode === 'year') {
      setCurrentYear(prev => prev + 1);
    } else if (viewMode === 'month') {
      if (currentMonth === 11) {
        setCurrentMonth(0);
        setCurrentYear(prev => prev + 1);
      } else {
        setCurrentMonth(prev => prev + 1);
      }
    } else if (viewMode === 'week') {
      const cur = parseDateString(referenceWeekDate);
      cur.setDate(cur.getDate() + 7);
      const newRef = toDateString(cur);
      setReferenceWeekDate(newRef);
      setSelectedDate(newRef);
    } else if (viewMode === 'day') {
      const cur = parseDateString(selectedDate);
      cur.setDate(cur.getDate() + 1);
      const newDate = toDateString(cur);
      setSelectedDate(newDate);
      setReferenceWeekDate(newDate);
      setCurrentMonth(cur.getMonth());
      setCurrentYear(cur.getFullYear());
    }
  };

  const handleToday = () => {
    const now = new Date();
    const nowStr = toDateString(now);
    setCurrentYear(now.getFullYear());
    setCurrentMonth(now.getMonth());
    setReferenceWeekDate(nowStr);
    setSelectedDate(nowStr);
  };

  // Jump handlers
  const handleSelectMonth = (monthIndex: number) => {
    setCurrentMonth(monthIndex);
    setViewMode('month');
  };

  const handleSelectWeek = (mondayDateStr: string) => {
    setReferenceWeekDate(mondayDateStr);
    setSelectedDate(mondayDateStr);
    const d = parseDateString(mondayDateStr);
    setCurrentMonth(d.getMonth());
    setCurrentYear(d.getFullYear());
    setViewMode('week');
  };

  const handleSelectDay = (dateStr: string) => {
    setSelectedDate(dateStr);
    setReferenceWeekDate(dateStr);
    const d = parseDateString(dateStr);
    setCurrentMonth(d.getMonth());
    setCurrentYear(d.getFullYear());
    setViewMode('day');
  };

  // Breadcrumb click handler
  const handleBreadcrumbClick = (level: 'year' | 'month' | 'week') => {
    if (level === 'year') setViewMode('year');
    else if (level === 'month') setViewMode('month');
    else if (level === 'week') setViewMode('week');
  };

  // Database operations
  const handleAddNote = async (content: string, type: 'general' | 'training' | 'lifestyle') => {
    await notesRepo.create({
      id: crypto.randomUUID(),
      date: selectedDate,
      content,
      type
    });
  };

  const handleDeleteNote = async (id: string) => {
    await notesRepo.delete(id);
  };

  const handleToggleHabit = async (habitId: string, currentCompleted: boolean, logId?: string) => {
    if (logId) {
      await habitLogsRepo.update(logId, { completed: !currentCompleted });
    } else {
      await habitLogsRepo.create({
        id: crypto.randomUUID(),
        habitId,
        date: selectedDate,
        completed: true
      });
    }
  };

  const handleSaveSleep = async (durationMinutes: number, quality?: number, sleepNotes?: string) => {
    const existing = sleepEntries.find(s => s.date === selectedDate);
    if (existing) {
      await sleepRepo.update(existing.id, {
        durationMinutes,
        quality,
        notes: sleepNotes
      });
    } else {
      await sleepRepo.create({
        id: crypto.randomUUID(),
        date: selectedDate,
        durationMinutes,
        quality,
        notes: sleepNotes
      });
    }
  };

  const handleSaveRecovery = async (
    soreness: number, 
    energy: number, 
    stress: number, 
    rating: number, 
    recoveryNotes?: string
  ) => {
    const existing = recoveryEntries.find(r => r.date === selectedDate);
    if (existing) {
      await recoveryRepo.update(existing.id, {
        soreness,
        energy,
        stress,
        rating,
        notes: recoveryNotes
      });
    } else {
      await recoveryRepo.create({
        id: crypto.randomUUID(),
        date: selectedDate,
        soreness,
        energy,
        stress,
        rating,
        notes: recoveryNotes
      });
    }
  };

  const handleSaveBodyWeight = async (weight: number, weightNotes?: string) => {
    const existing = bodyWeights.find(b => b.date === selectedDate);
    if (existing) {
      await bodyWeightRepo.update(existing.id, {
        weight,
        notes: weightNotes
      });
    } else {
      await bodyWeightRepo.create({
        id: crypto.randomUUID(),
        date: selectedDate,
        weight,
        notes: weightNotes
      });
    }
  };

  const handleAddMeasurement = async (type: string, value: number, unit: string) => {
    await measurementsRepo.create({
      id: crypto.randomUUID(),
      type,
      value,
      unit,
      date: selectedDate
    });
  };

  const handleCreateWorkoutForDate = async (date: string) => {
    const newWorkoutId = crypto.randomUUID();
    await workoutsRepo.create({
      id: newWorkoutId,
      name: 'Freestyle Session',
      date,
      startTime: `${date}T09:00:00.000Z`,
      completed: false
    });
    navigate(`/training/workout/${newWorkoutId}`);
  };

  // Current title & subtitle for the header
  const headerInfo = useMemo(() => {
    if (viewMode === 'year') {
      return {
        title: `${currentYear}`,
        subtitle: '12-Month Calendar'
      };
    }
    if (viewMode === 'month') {
      return {
        title: `${MONTH_NAMES[currentMonth]} ${currentYear}`,
        subtitle: `${monthData.totalDays} Days • ${monthData.totalWorkouts} Workouts`
      };
    }
    if (viewMode === 'week') {
      return {
        title: `Week ${weekData.weekNumber}`,
        subtitle: weekData.label
      };
    }
    return {
      title: dayJournalDetail.formattedDate,
      subtitle: dayJournalDetail.isToday ? 'Today\'s Fitness Journal' : 'Historical Journal'
    };
  }, [viewMode, currentYear, currentMonth, monthData, weekData, dayJournalDetail]);

  // Breadcrumbs calculation
  const selectedDateObj = parseDateString(selectedDate);
  const breadcrumbs = {
    year: currentYear,
    month: currentMonth,
    week: getIsoWeekNumber(getMondayOfWeek(selectedDateObj)),
    day: dayJournalDetail.shortDate
  };

  return (
    <div className="p-4 sm:p-6 pb-24">
      {/* Calendar Header Navigation */}
      <CalendarHeader
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        title={headerInfo.title}
        subtitle={headerInfo.subtitle}
        onPrev={handlePrev}
        onNext={handleNext}
        onToday={handleToday}
        breadcrumbs={breadcrumbs}
        onBreadcrumbClick={handleBreadcrumbClick}
      />

      {/* Calendar View Modes */}
      {viewMode === 'year' && (
        <YearView
          year={yearData.year}
          months={yearData.months}
          totalWorkouts={yearData.totalWorkouts}
          totalVolumeKg={yearData.totalVolumeKg}
          totalActiveDays={yearData.totalActiveDays}
          onSelectMonth={handleSelectMonth}
        />
      )}

      {viewMode === 'month' && (
        <MonthView
          month={monthData}
          onSelectDay={handleSelectDay}
          onSelectWeek={handleSelectWeek}
        />
      )}

      {viewMode === 'week' && (
        <WeekView
          week={weekData}
          onSelectDay={handleSelectDay}
        />
      )}

      {viewMode === 'day' && (
        <DayJournalView
          dayDetail={dayJournalDetail}
          onAddNote={handleAddNote}
          onDeleteNote={handleDeleteNote}
          onToggleHabit={handleToggleHabit}
          onSaveSleep={handleSaveSleep}
          onSaveRecovery={handleSaveRecovery}
          onSaveBodyWeight={handleSaveBodyWeight}
          onAddMeasurement={handleAddMeasurement}
          onCreateWorkoutForDate={handleCreateWorkoutForDate}
        />
      )}
    </div>
  );
}
