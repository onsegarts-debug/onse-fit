import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { workoutsRepo, workoutExercisesRepo, setsRepo } from '../../db/api';
import { H3, Mono } from '../../components/ui/Typography';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { SectionHeader } from '../../components/ui/SectionHeader';
import { Check, Plus, X, Play, Square } from 'lucide-react';
import { ExercisePicker } from '../../components/training/ExercisePicker';
import { RestTimer } from '../../components/training/RestTimer';
import { SetRow } from '../../components/training/SetRow';
import { WorkoutMusicSection } from '../../components/spotify/WorkoutMusicSection';

export function WorkoutSession() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [showExercisePicker, setShowExercisePicker] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const workout = useLiveQuery(() => id ? db.workouts.get(id) : undefined, [id]);
  
  // Get workout exercises with their joined exercise data and sets
  const exercises = useLiveQuery(async () => {
    if (!id) return [];
    const wExercises = await db.workoutExercises.where({ workoutId: id }).sortBy('order');
    
    // Join with sets and actual exercise data
    return Promise.all(wExercises.map(async (we) => {
      const exercise = await db.exercises.get(we.exerciseId);
      const sets = await db.sets.where({ workoutExerciseId: we.id }).sortBy('order');
      return { ...we, exercise, sets };
    }));
  }, [id]);

  useEffect(() => {
    if (!workout?.startTime || workout.completed) return;
    
    const start = new Date(workout.startTime).getTime();
    const interval = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - start) / 1000));
    }, 1000);
    
    return () => clearInterval(interval);
  }, [workout]);

  const formatTime = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    if (hrs > 0) return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAddExercise = async (exerciseId: string) => {
    if (!id) return;
    const order = exercises ? exercises.length : 0;
    
    const wExerciseId = crypto.randomUUID();
    await workoutExercisesRepo.create({
      id: wExerciseId,
      workoutId: id,
      exerciseId,
      order,
    });
    
    // Add first empty set
    await setsRepo.create({
      id: crypto.randomUUID(),
      workoutExerciseId: wExerciseId,
      weight: 0,
      reps: 0,
      completed: false,
      order: 0,
    });
    
    setShowExercisePicker(false);
  };

  const handleFinishWorkout = async () => {
    if (!id) return;
    await workoutsRepo.update(id, { 
      completed: true, 
      endTime: new Date().toISOString() 
    });
    navigate(-1);
  };

  if (workout === undefined) return <div className="p-6"><Mono>Loading...</Mono></div>;
  if (workout === null) return <div className="p-6"><Mono>Workout not found.</Mono></div>;

  return (
    <div className="bg-[#F7F4ED] dark:bg-[#111111] min-h-screen text-[#111111] dark:text-[#F7F4ED] pb-32">
      {/* Sticky Header */}
      <div className="sticky top-0 z-40 bg-[#F7F4ED] dark:bg-[#111111] border-b-2 border-[#111111] dark:border-[#F7F4ED] p-4 flex justify-between items-center">
        <div>
          <Mono className="text-[10px] opacity-60">WORKOUT</Mono>
          <H3 className="uppercase text-lg">{workout.name}</H3>
        </div>
        <div className="flex items-center gap-4">
          <Mono className="font-bold text-[#5B7CFF]">{formatTime(elapsedSeconds)}</Mono>
          <Button variant={workout.completed ? 'outline' : 'primary'} size="sm" onClick={handleFinishWorkout}>
            {workout.completed ? 'CLOSED' : 'FINISH'}
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-6 mt-4">
        {/* Compact Workout Music Section */}
        <WorkoutMusicSection
          workoutId={workout.id}
          associatedPlaylistId={workout.spotifyPlaylistId}
          associatedPlaylistName={workout.spotifyPlaylistName}
          associatedPlaylistUri={workout.spotifyPlaylistUri}
        />

        {exercises?.map((we, index) => (
          <div key={we.id} className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-4">
            <div className="flex justify-between items-start border-b-2 border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 pb-2 mb-4">
              <H3 className="text-lg">{we.exercise?.name || 'Unknown Exercise'}</H3>
            </div>
            
            {/* Sets Header */}
            <div className="grid grid-cols-[3fr_3fr_3fr_1fr] gap-2 mb-2 px-2">
              <Mono className="text-[10px] text-center opacity-60">KG</Mono>
              <Mono className="text-[10px] text-center opacity-60">REPS</Mono>
              <Mono className="text-[10px] text-center opacity-60">RPE</Mono>
              <Mono className="text-[10px] text-center opacity-60">DONE</Mono>
            </div>
            
            <div className="space-y-2">
              {we.sets.map((set, setIndex) => (
                <SetRow key={set.id} set={set} index={setIndex} />
              ))}
            </div>
            
            <Button 
              variant="ghost" 
              className="w-full mt-4 text-xs h-8 border-dashed"
              onClick={async () => {
                await setsRepo.create({
                  id: crypto.randomUUID(),
                  workoutExerciseId: we.id,
                  weight: 0,
                  reps: 0,
                  completed: false,
                  order: we.sets.length,
                });
              }}
            >
              + ADD SET
            </Button>
          </div>
        ))}

        {!workout.completed && (
          <Button variant="outline" className="w-full border-dashed" onClick={() => setShowExercisePicker(true)}>
            + ADD EXERCISE
          </Button>
        )}
      </div>

      {showExercisePicker && (
        <ExercisePicker 
          onClose={() => setShowExercisePicker(false)} 
          onSelect={handleAddExercise} 
        />
      )}

      {/* Global Rest Timer (Fixed Bottom) */}
      <RestTimer />
    </div>
  );
}
