import React, { useState } from 'react';
import { H1, Mono } from '../components/ui/Typography';
import { Button } from '../components/ui/Button';
import { StrengthTracker } from '../components/progress/StrengthTracker';
import { PersonalRecordsBoard } from '../components/progress/PersonalRecordsBoard';
import { BodyWeightTracker } from '../components/progress/BodyWeightTracker';
import { MeasurementsTracker } from '../components/progress/MeasurementsTracker';
import { ProgressPhotosVault } from '../components/progress/ProgressPhotosVault';
import { OverallAnalytics } from '../components/progress/OverallAnalytics';
import { CalculationVerificationModal } from '../components/progress/CalculationVerificationModal';
import { 
  TrendingUp, Trophy, Scale, Ruler, Camera, BarChart2, ShieldCheck 
} from 'lucide-react';

type ProgressTab = 'strength' | 'records' | 'bodyweight' | 'measurements' | 'photos' | 'analytics';

export function Progress() {
  const [activeTab, setActiveTab] = useState<ProgressTab>('strength');
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);

  const tabs = [
    { id: 'strength' as ProgressTab, label: 'STRENGTH', icon: TrendingUp },
    { id: 'records' as ProgressTab, label: 'PR TROPHIES', icon: Trophy },
    { id: 'bodyweight' as ProgressTab, label: 'BODY WEIGHT', icon: Scale },
    { id: 'measurements' as ProgressTab, label: 'MEASUREMENTS', icon: Ruler },
    { id: 'photos' as ProgressTab, label: 'PHOTOS (VAULT)', icon: Camera },
    { id: 'analytics' as ProgressTab, label: 'ANALYTICS', icon: BarChart2 }
  ];

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-4">
        <div>
          <H1 className="tracking-tight text-3xl sm:text-4xl">PROGRESS</H1>
          <Mono className="text-[#5B7CFF] text-xs font-bold uppercase tracking-widest mt-1 block">
            DETERMINISTIC STRENGTH & BIOMETRIC ANALYTICS
          </Mono>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsTestModalOpen(true)}
          className="text-xs flex items-center gap-1.5 shrink-0"
        >
          <ShieldCheck size={14} className="text-[#5B7CFF]" />
          VERIFY FORMULAS & BENCHMARK
        </Button>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex flex-wrap border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-1 gap-1 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 min-w-[120px] py-2.5 px-3 flex items-center justify-center gap-2 font-mono text-xs font-bold uppercase transition-colors ${
                isActive
                  ? 'bg-[#5B7CFF] text-white'
                  : 'bg-transparent text-[#111111] dark:text-[#F7F4ED] hover:bg-[#111111]/5 dark:hover:bg-[#F7F4ED]/5'
              }`}
            >
              <Icon size={14} className={isActive ? 'text-white' : 'text-[#5B7CFF]'} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div className="pt-2">
        {activeTab === 'strength' && <StrengthTracker />}
        {activeTab === 'records' && <PersonalRecordsBoard />}
        {activeTab === 'bodyweight' && <BodyWeightTracker />}
        {activeTab === 'measurements' && <MeasurementsTracker />}
        {activeTab === 'photos' && <ProgressPhotosVault />}
        {activeTab === 'analytics' && <OverallAnalytics />}
      </div>

      {/* Calculation Verification & Benchmark Modal */}
      <CalculationVerificationModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
      />
    </div>
  );
}
export default Progress;
