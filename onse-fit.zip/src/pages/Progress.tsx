import React from 'react';
import { H1, Mono } from '../components/ui/Typography';
import { SectionHeader } from '../components/ui/SectionHeader';

export function Progress() {
  return (
    <div className="p-6">
      <H1 className="mb-2">PROGRESS</H1>
      <Mono className="text-[#5B7CFF] mb-8 block">ANALYTICS & RECORDS</Mono>

      <SectionHeader title="Metrics" number="01" />
      <div className="p-8 border-2 border-dashed border-[#111111]/30 dark:border-[#F7F4ED]/30 text-center">
        <Mono className="opacity-50">PROGRESS MODULE PLACEHOLDER</Mono>
      </div>
    </div>
  );
}
