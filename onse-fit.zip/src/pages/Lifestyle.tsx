import React from 'react';
import { H1, Mono } from '../components/ui/Typography';
import { SectionHeader } from '../components/ui/SectionHeader';
import { HabitTracker } from '../components/lifestyle/HabitTracker';
import { RecoveryLog } from '../components/lifestyle/RecoveryLog';

export function Lifestyle() {
  return (
    <div className="p-6 space-y-12">
      <div>
        <H1 className="mb-2">LIFESTYLE</H1>
        <Mono className="text-[#5B7CFF] block">HABITS & RECOVERY</Mono>
      </div>

      <section>
        <SectionHeader title="Today" number="01" />
        <HabitTracker />
      </section>

      <section>
        <SectionHeader title="Biometrics" number="02" />
        <RecoveryLog />
      </section>
      
      {/* Spacer for bottom nav */}
      <div className="h-4" />
    </div>
  );
}
