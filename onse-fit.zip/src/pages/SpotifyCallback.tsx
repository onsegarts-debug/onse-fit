/**
 * ONSE FIT
 * Spotify OAuth 2.0 Callback Handler
 * Handles redirect authentication, PKCE token exchange, and popup/redirect handoffs.
 */

import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { exchangeCodeForTokens } from '../lib/spotify/spotifyAuth';
import { Mono, H2 } from '../components/ui/Typography';
import { Button } from '../components/ui/Button';
import { Disc3, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

export function SpotifyCallback() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [status, setStatus] = useState<'exchanging' | 'success' | 'error'>('exchanging');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    const handleAuthCallback = async () => {
      const code = searchParams.get('code');
      const state = searchParams.get('state') || '';
      const errorParam = searchParams.get('error');

      // Check if user denied permission on Spotify's consent screen
      if (errorParam === 'access_denied') {
        setStatus('error');
        setErrorMessage('Access denied. Spotify authorization was canceled or permissions were denied.');
        if (window.opener) {
          window.opener.postMessage(
            { 
              type: 'ONSE_SPOTIFY_AUTH_ERROR', 
              code: 'permission_denied', 
              message: 'Spotify authorization denied.' 
            }, 
            '*'
          );
          setTimeout(() => window.close(), 1200);
        }
        return;
      }

      if (errorParam) {
        setStatus('error');
        setErrorMessage(`Spotify error: ${errorParam}`);
        if (window.opener) {
          window.opener.postMessage(
            { 
              type: 'ONSE_SPOTIFY_AUTH_ERROR', 
              code: 'auth_failed', 
              message: errorParam 
            }, 
            '*'
          );
          setTimeout(() => window.close(), 1500);
        }
        return;
      }

      if (!code) {
        setStatus('error');
        setErrorMessage('Authorization code not found in URL parameters.');
        return;
      }

      try {
        await exchangeCodeForTokens(code, state);
        setStatus('success');

        if (window.opener) {
          // Send notification to the opener tab/window
          window.opener.postMessage({ type: 'ONSE_SPOTIFY_AUTH_SUCCESS' }, '*');
          setTimeout(() => {
            window.close();
          }, 800);
        } else {
          // If navigated directly in main window, redirect back to Spotify Integrations
          setTimeout(() => {
            navigate('/profile/integrations/spotify', { replace: true });
          }, 1000);
        }
      } catch (err: any) {
        console.error('Spotify token exchange failed:', err);
        setStatus('error');
        setErrorMessage(err.message || 'Token exchange failed.');
        if (window.opener) {
          window.opener.postMessage(
            { 
              type: 'ONSE_SPOTIFY_AUTH_ERROR', 
              code: 'auth_failed', 
              message: err.message 
            }, 
            '*'
          );
        }
      }
    };

    handleAuthCallback();
  }, [searchParams, navigate]);

  return (
    <div className="min-h-screen bg-[#F7F4ED] dark:bg-[#111111] text-[#111111] dark:text-[#F7F4ED] flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-sm border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-6 shadow-[6px_6px_0px_0px_#111111] dark:shadow-[6px_6px_0px_0px_#F7F4ED] text-center space-y-6">
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] flex items-center justify-center bg-[#1DB954]/10">
            <Disc3 
              size={32} 
              className={status === 'exchanging' ? "animate-spin text-[#1DB954]" : "text-[#1DB954]"} 
            />
          </div>
        </div>

        <div>
          <Mono className="text-[10px] tracking-widest text-[#1DB954] font-bold uppercase block mb-1">
            ONSE FIT • SPOTIFY INTEGRATION
          </Mono>
          <H2 className="text-xl uppercase font-black">
            {status === 'exchanging' && 'AUTHENTICATING...'}
            {status === 'success' && 'CONNECTED'}
            {status === 'error' && 'AUTH ERROR'}
          </H2>
        </div>

        {status === 'exchanging' && (
          <p className="text-xs font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 leading-relaxed">
            Exchanging PKCE cryptographic tokens with Spotify services. Please wait...
          </p>
        )}

        {status === 'success' && (
          <div className="space-y-3">
            <div className="flex items-center justify-center gap-2 text-xs font-mono font-bold text-[#1DB954]">
              <CheckCircle2 size={16} /> Spotify Connected Successfully
            </div>
            <p className="text-xs font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70">
              Returning to ONSE FIT...
            </p>
          </div>
        )}

        {status === 'error' && (
          <div className="space-y-4">
            <div className="p-3 bg-red-500/10 border border-red-500 text-left flex items-start gap-2">
              <AlertTriangle size={16} className="text-red-500 shrink-0 mt-0.5" />
              <p className="text-xs font-mono text-red-500 leading-tight">
                {errorMessage}
              </p>
            </div>
            <Button 
              variant="primary" 
              className="w-full text-xs font-mono font-bold"
              onClick={() => navigate('/profile/integrations/spotify')}
            >
              RETURN TO ONSE FIT <ArrowRight size={14} />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
