/**
 * ONSE FIT
 * Profile > Integrations > Spotify View
 * Main management location for Spotify connection, authentication, account details,
 * playlist selection, associations, and connection diagnostics.
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../db';
import { useSpotify } from '../../lib/spotify/SpotifyContext';
import { type SpotifyConnectionStatus } from '../../types';
import { H1, H2, H3, Mono } from '../../components/ui/Typography';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { SectionHeader } from '../../components/ui/SectionHeader';
import { parseSpotifyPlaylistInput } from '../../lib/spotify/spotifyApi';
import { 
  ArrowLeft, Disc3, CheckCircle2, AlertTriangle, WifiOff, 
  ExternalLink, Copy, Check, RefreshCw, LogOut, Plus, Trash2,
  Lock, Music2, ShieldCheck, HelpCircle
} from 'lucide-react';

export function SpotifyIntegration() {
  const navigate = useNavigate();
  const { 
    status, 
    user, 
    playlists, 
    isLoading, 
    errorMessage, 
    clientId, 
    setClientId, 
    redirectUri, 
    connect, 
    disconnect, 
    refreshPlaylists, 
    openPlaylist,
    setManualTestStatus,
    isTestMode,
    associatePlaylistWithProgram,
    removeProgramPlaylist
  } = useSpotify();

  const programs = useLiveQuery(() => db.programs.toArray()) || [];
  const workouts = useLiveQuery(() => db.workouts.orderBy('date').reverse().limit(10).toArray()) || [];

  const [customClientIdInput, setCustomClientIdInput] = useState(clientId);
  const [copiedUri, setCopiedUri] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Manual Playlist Addition State
  const [manualLink, setManualLink] = useState('');
  const [manualTitle, setManualTitle] = useState('');
  const [manualTargetType, setManualTargetType] = useState<'program' | 'workout'>('program');
  const [manualTargetId, setManualTargetId] = useState<string>('');
  const [manualError, setManualError] = useState<string | null>(null);

  const handleCopyUri = () => {
    navigator.clipboard.writeText(redirectUri);
    setCopiedUri(true);
    setTimeout(() => setCopiedUri(false), 2000);
  };

  const handleSaveClientId = (e: React.FormEvent) => {
    e.preventDefault();
    setClientId(customClientIdInput);
    setShowConfig(false);
  };

  const handleManualAssociate = async (e: React.FormEvent) => {
    e.preventDefault();
    setManualError(null);
    const parsed = parseSpotifyPlaylistInput(manualLink);
    if (!parsed) {
      setManualError('Invalid Spotify URL or URI format. Expected format: open.spotify.com/playlist/... or spotify:playlist:...');
      return;
    }

    const name = manualTitle.trim() || 'Gym Playlist';

    if (manualTargetType === 'program' && manualTargetId) {
      await associatePlaylistWithProgram(manualTargetId, {
        id: parsed.id,
        name,
        uri: parsed.uri
      });
    }

    setManualLink('');
    setManualTitle('');
    setManualTargetId('');
  };

  // Filtered playlists
  const filteredPlaylists = playlists.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.ownerName && p.ownerName.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="p-4 sm:p-6 space-y-6 pb-28">
      {/* Top Breadcrumb Header */}
      <div className="flex items-center justify-between border-b-2 border-[#111111] dark:border-[#F7F4ED] pb-3">
        <button
          onClick={() => navigate('/profile')}
          className="flex items-center gap-1 text-xs font-mono font-bold uppercase hover:text-[#5B7CFF] transition-colors"
        >
          <ArrowLeft size={16} /> PROFILE / INTEGRATIONS
        </button>
        <Mono className="text-[10px] tracking-widest text-[#1DB954] font-bold uppercase">
          SPOTIFY API
        </Mono>
      </div>

      <div>
        <H1 className="mb-1 flex items-center gap-3">
          <Disc3 size={28} className="text-[#1DB954]" /> SPOTIFY
        </H1>
        <Mono className="text-xs opacity-60">WORKOUT AUDIO COMPANION</Mono>
      </div>

      {/* 1. CONNECTION STATUS BANNER */}
      <div 
        id="spotify-status-banner"
        className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[4px_4px_0px_0px_#111111] dark:shadow-[4px_4px_0px_0px_#F7F4ED] space-y-3"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#111111]/70 dark:text-[#F7F4ED]/70">
              STATUS:
            </span>
            {status === 'connected' && (
              <Badge variant="default" className="bg-[#1DB954] text-black border-[#111111]">
                CONNECTED
              </Badge>
            )}
            {status === 'disconnected' && (
              <Badge variant="outline" className="opacity-70">
                DISCONNECTED
              </Badge>
            )}
            {status === 'connecting' && (
              <Badge variant="outline" className="text-[#5B7CFF] animate-pulse">
                CONNECTING...
              </Badge>
            )}
            {status === 'auth_required' && (
              <Badge variant="outline" className="text-amber-500 border-amber-500">
                AUTH REQUIRED
              </Badge>
            )}
            {status === 'permission_denied' && (
              <Badge variant="outline" className="text-red-500 border-red-500">
                PERMISSION DENIED
              </Badge>
            )}
            {status === 'network_unavailable' && (
              <Badge variant="accent2">
                NETWORK OFFLINE
              </Badge>
            )}
            {status === 'spotify_unavailable' && (
              <Badge variant="outline" className="text-amber-500 border-amber-500">
                SPOTIFY UNAVAILABLE
              </Badge>
            )}
            {status === 'auth_failed' && (
              <Badge variant="outline" className="text-red-500 border-red-500">
                AUTH FAILED
              </Badge>
            )}
          </div>

          {isTestMode && (
            <span className="text-[9px] font-mono px-1.5 py-0.5 bg-purple-500/20 text-purple-600 dark:text-purple-400 border border-purple-500/30">
              TEST MODE
            </span>
          )}
        </div>

        {/* Status Context Descriptions */}
        {status === 'connected' && (
          <div className="space-y-3 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10">
            <div className="flex items-center gap-3">
              {user?.imageUrl ? (
                <img 
                  src={user.imageUrl} 
                  alt={user.displayName} 
                  className="w-12 h-12 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#1DB954]/20 flex items-center justify-center">
                  <Disc3 size={24} className="text-[#1DB954]" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="font-sans font-black text-sm uppercase truncate text-[#111111] dark:text-[#F7F4ED]">
                  {user?.displayName || 'Spotify User'}
                </div>
                <Mono className="text-[11px] opacity-70 block">
                  {user?.product ? `${user.product.toUpperCase()} ACCOUNT` : 'SPOTIFY ACCOUNT'}
                  {user?.email && ` • ${user.email}`}
                </Mono>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <Button
                variant="outline"
                size="sm"
                onClick={refreshPlaylists}
                disabled={isLoading}
                className="text-xs font-mono font-bold flex items-center gap-1.5"
              >
                <RefreshCw size={12} className={isLoading ? "animate-spin" : ""} />
                {isLoading ? 'SYNCING...' : 'SYNC PLAYLISTS'}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={disconnect}
                className="text-xs font-mono text-red-500 hover:text-red-600 hover:bg-red-500/10 flex items-center gap-1"
              >
                <LogOut size={12} /> DISCONNECT
              </Button>
            </div>
          </div>
        )}

        {status === 'disconnected' && (
          <div className="space-y-3 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10">
            <p className="text-xs font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 leading-relaxed">
              Connect Spotify to access your personal playlists, heavy lifting mixes, and assign soundtrack profiles directly to workout routines.
            </p>
            <Button
              variant="primary"
              onClick={() => connect()}
              className="w-full text-xs font-mono font-bold bg-[#1DB954] text-black border-[#111111] hover:bg-[#1DB954]/90 flex items-center justify-center gap-2"
            >
              <Disc3 size={16} /> CONNECT SPOTIFY ACCOUNT
            </Button>
          </div>
        )}

        {status === 'connecting' && (
          <div className="py-2 text-center space-y-2">
            <Mono className="text-xs text-[#5B7CFF]">
              Awaiting authorization from Spotify popup window...
            </Mono>
          </div>
        )}

        {status === 'auth_required' && (
          <div className="space-y-2 pt-2 border-t border-amber-500/20">
            <div className="flex items-start gap-2 text-amber-600 dark:text-amber-400">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              <p className="text-xs font-mono">
                Your Spotify security session has expired or was revoked. Re-authenticate to refresh workout playlists.
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              onClick={() => connect()}
              className="w-full text-xs font-mono font-bold"
            >
              RE-AUTHENTICATE SPOTIFY
            </Button>
          </div>
        )}

        {status === 'permission_denied' && (
          <div className="space-y-2 pt-2 border-t border-red-500/20">
            <div className="flex items-start gap-2 text-red-500">
              <Lock size={16} className="shrink-0 mt-0.5" />
              <p className="text-xs font-mono">
                Permission denied. Spotify requires permission to read your public and private playlists.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => connect()}
              className="w-full text-xs font-mono font-bold border-red-500 text-red-500 hover:bg-red-500/10"
            >
              RETRY WITH REQUIRED PERMISSIONS
            </Button>
          </div>
        )}

        {status === 'network_unavailable' && (
          <div className="space-y-2 pt-2 border-t border-[#111111]/10 dark:border-[#F7F4ED]/10">
            <div className="flex items-start gap-2 text-[#5B7CFF]">
              <WifiOff size={16} className="shrink-0 mt-0.5" />
              <div className="text-xs font-mono leading-relaxed">
                <span className="font-bold block">OFFLINE LOGBOOK MODE ACTIVE</span>
                Network connection unreachable. ONSE FIT workout and exercise tracking operates 100% offline. Previously cached playlists remain accessible.
              </div>
            </div>
          </div>
        )}

        {status === 'spotify_unavailable' && (
          <div className="space-y-2 pt-2 border-t border-amber-500/20">
            <div className="flex items-start gap-2 text-amber-600 dark:text-amber-400">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              <p className="text-xs font-mono">
                Spotify API services are temporarily returning 500/502/503 service errors. Your local workout data and logbook are completely unaffected.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshPlaylists}
              className="text-xs font-mono font-bold"
            >
              CHECK SPOTIFY AVAILABILITY
            </Button>
          </div>
        )}

        {status === 'auth_failed' && (
          <div className="space-y-2 pt-2 border-t border-red-500/20">
            <div className="flex items-start gap-2 text-red-500">
              <AlertTriangle size={16} className="shrink-0 mt-0.5" />
              <p className="text-xs font-mono">
                {errorMessage || 'Authentication failed. Please verify your Spotify Client ID and network connection.'}
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              onClick={() => connect()}
              className="w-full text-xs font-mono font-bold"
            >
              RETRY CONNECTION
            </Button>
          </div>
        )}
      </div>

      {/* 2. PLAYLIST SELECTION & MANAGEMENT */}
      <section className="space-y-4">
        <SectionHeader title="Playlists" />

        {status === 'connected' && (
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Search your Spotify playlists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-2.5 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
            />

            {filteredPlaylists.length > 0 ? (
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {filteredPlaylists.map((pl) => (
                  <div
                    key={pl.id}
                    className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-3 flex items-center justify-between gap-3 shadow-[2px_2px_0px_0px_#111111] dark:shadow-[2px_2px_0px_0px_#F7F4ED]"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      {pl.imageUrl ? (
                        <img
                          src={pl.imageUrl}
                          alt={pl.name}
                          className="w-10 h-10 border border-[#111111] dark:border-[#F7F4ED] object-cover shrink-0"
                        />
                      ) : (
                        <div className="w-10 h-10 border border-[#111111] dark:border-[#F7F4ED] bg-[#111111]/5 dark:bg-[#F7F4ED]/5 flex items-center justify-center shrink-0">
                          <Music2 size={18} className="opacity-50" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-bold text-xs uppercase truncate text-[#111111] dark:text-[#F7F4ED]">
                          {pl.name}
                        </div>
                        <Mono className="text-[10px] opacity-60 truncate">
                          {pl.tracksTotal} tracks • by {pl.ownerName || 'Spotify'}
                        </Mono>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openPlaylist(pl.uri || pl.externalUrl)}
                        className="h-7 text-[10px] font-mono font-bold px-2 py-0 flex items-center gap-1"
                        title="Open in Spotify App"
                      >
                        OPEN <ExternalLink size={10} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 border-2 border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 text-center">
                <Mono className="text-xs opacity-60">
                  {playlists.length === 0 ? 'No playlists found in your Spotify account.' : 'No playlists match your search.'}
                </Mono>
              </div>
            )}
          </div>
        )}

        {status !== 'connected' && (
          <div className="p-6 border-2 border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 text-center space-y-2">
            <Disc3 size={24} className="mx-auto opacity-40" />
            <Mono className="text-xs opacity-70 block">
              {status === 'network_unavailable' 
                ? 'Spotify is offline. Workout logging continues without interruption.'
                : 'Connect your Spotify account above to view and assign playlists.'}
            </Mono>
          </div>
        )}

        {/* Manual Playlist Link Attachment */}
        <div className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-3 space-y-3">
          <div className="flex items-center justify-between">
            <Mono className="text-[10px] font-bold uppercase tracking-wider text-[#111111] dark:text-[#F7F4ED]">
              LINK PLAYLIST TO PROGRAM
            </Mono>
            <ShieldCheck size={14} className="text-[#5B7CFF]" />
          </div>

          <form onSubmit={handleManualAssociate} className="space-y-2">
            <input
              type="text"
              placeholder="Spotify Playlist URL or URI (e.g. open.spotify.com/playlist/...)"
              value={manualLink}
              onChange={(e) => setManualLink(e.target.value)}
              className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-2 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Playlist Name (e.g. Heavy Pull Mix)"
                value={manualTitle}
                onChange={(e) => setManualTitle(e.target.value)}
                className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-2 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
              />
              <select
                value={manualTargetId}
                onChange={(e) => setManualTargetId(e.target.value)}
                className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-2 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
              >
                <option value="">Select Program...</option>
                {programs.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            {manualError && (
              <p className="text-[10px] font-mono text-red-500">{manualError}</p>
            )}

            <Button
              type="submit"
              variant="outline"
              size="sm"
              disabled={!manualLink.trim() || !manualTargetId}
              className="w-full text-xs font-mono font-bold"
            >
              <Plus size={12} /> ASSOCIATE PLAYLIST WITH PROGRAM
            </Button>
          </form>
        </div>
      </section>

      {/* 3. PROGRAM PLAYLIST ASSOCIATIONS LIST */}
      <section className="space-y-3">
        <SectionHeader title="Active Program Associations" />
        {programs.some(p => p.spotifyPlaylistName) ? (
          <div className="space-y-2">
            {programs.filter(p => p.spotifyPlaylistName).map(p => (
              <div
                key={p.id}
                className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-3 flex items-center justify-between"
              >
                <div>
                  <Mono className="text-[9px] text-[#5B7CFF] uppercase font-bold">PROGRAM: {p.name}</Mono>
                  <div className="font-sans font-bold text-xs uppercase text-[#111111] dark:text-[#F7F4ED]">
                    {p.spotifyPlaylistName}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openPlaylist(p.spotifyPlaylistUri || `spotify:playlist:${p.spotifyPlaylistId}`)}
                    className="h-7 text-[10px] font-mono font-bold px-2 py-0"
                  >
                    OPEN
                  </Button>
                  <button
                    onClick={() => removeProgramPlaylist(p.id)}
                    className="p-1 hover:text-red-500 transition-colors opacity-50 hover:opacity-100"
                    title="Remove Association"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 border border-dashed border-[#111111]/20 dark:border-[#F7F4ED]/20 text-center">
            <Mono className="text-xs opacity-60">No programs have associated Spotify playlists yet.</Mono>
          </div>
        )}
      </section>

      {/* 4. OAUTH & CREDENTIAL CONFIGURATION */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock size={16} className="text-[#5B7CFF]" />
            <span className="font-sans font-bold text-xs uppercase tracking-tight text-[#111111] dark:text-[#F7F4ED]">
              OAUTH & REDIRECT URI CONFIGURATION
            </span>
          </div>
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="text-xs font-mono text-[#5B7CFF] hover:underline"
          >
            {showConfig ? 'HIDE' : 'VIEW DETAILS'}
          </button>
        </div>

        {showConfig && (
          <div className="space-y-3 pt-3 border-t border-[#111111]/15 dark:border-[#F7F4ED]/15">
            {/* Redirect URI Display with Copy Action */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <Mono className="text-[10px] uppercase opacity-70">
                  SPOTIFY REDIRECT URI:
                </Mono>
                <button
                  onClick={handleCopyUri}
                  className="flex items-center gap-1 text-[10px] font-mono text-[#5B7CFF] hover:underline"
                >
                  {copiedUri ? <Check size={12} className="text-[#1DB954]" /> : <Copy size={12} />}
                  {copiedUri ? 'COPIED' : 'COPY'}
                </button>
              </div>
              <div className="p-2 bg-[#F7F4ED] dark:bg-[#111111] border border-[#111111]/20 dark:border-[#F7F4ED]/20 font-mono text-[11px] break-all select-all">
                {redirectUri}
              </div>
              <p className="text-[10px] font-mono opacity-60 leading-tight">
                Add this exact URI to your Spotify Developer Dashboard under "Redirect URIs".
              </p>
            </div>

            {/* Custom Client ID Form */}
            <form onSubmit={handleSaveClientId} className="space-y-2 pt-2">
              <Mono className="text-[10px] uppercase opacity-70">
                SPOTIFY CLIENT ID:
              </Mono>
              <input
                type="text"
                value={customClientIdInput}
                onChange={(e) => setCustomClientIdInput(e.target.value)}
                placeholder="Spotify App Client ID"
                className="w-full border-2 border-[#111111] dark:border-[#F7F4ED] bg-[#F7F4ED] dark:bg-[#111111] p-2 text-xs font-mono text-[#111111] dark:text-[#F7F4ED] focus:outline-none focus:ring-1 focus:ring-[#5B7CFF]"
              />
              <div className="flex justify-end gap-2">
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  className="text-xs font-mono font-bold"
                >
                  SAVE CLIENT ID
                </Button>
              </div>
            </form>
          </div>
        )}
      </section>

      {/* 5. CONNECTION STATE TESTER (VERIFICATION SUITE) */}
      <section className="border-2 border-[#111111] dark:border-[#F7F4ED] bg-white dark:bg-[#1A1A1A] p-4 shadow-[3px_3px_0px_0px_#111111] dark:shadow-[3px_3px_0px_0px_#F7F4ED] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HelpCircle size={16} className="text-purple-500" />
            <span className="font-sans font-bold text-xs uppercase tracking-tight text-[#111111] dark:text-[#F7F4ED]">
              CONNECTION STATE VERIFICATION SUITE
            </span>
          </div>
          <button
            onClick={() => setShowDiagnostics(!showDiagnostics)}
            className="text-xs font-mono text-purple-600 dark:text-purple-400 hover:underline"
          >
            {showDiagnostics ? 'HIDE TESTER' : 'OPEN TESTER'}
          </button>
        </div>

        {showDiagnostics && (
          <div className="space-y-3 pt-3 border-t border-[#111111]/15 dark:border-[#F7F4ED]/15">
            <p className="text-[11px] font-mono text-[#111111]/70 dark:text-[#F7F4ED]/70 leading-normal">
              Test and verify all 8 required connection states in light/dark modes and mobile dimensions without breaking local offline workout tracking:
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {[
                { label: 'Connected', val: 'connected' as SpotifyConnectionStatus },
                { label: 'Disconnected', val: 'disconnected' as SpotifyConnectionStatus },
                { label: 'Connecting', val: 'connecting' as SpotifyConnectionStatus },
                { label: 'Auth Required', val: 'auth_required' as SpotifyConnectionStatus },
                { label: 'Permission Denied', val: 'permission_denied' as SpotifyConnectionStatus },
                { label: 'Network Offline', val: 'network_unavailable' as SpotifyConnectionStatus },
                { label: 'Spotify 503', val: 'spotify_unavailable' as SpotifyConnectionStatus },
                { label: 'Auth Failed', val: 'auth_failed' as SpotifyConnectionStatus }
              ].map((item) => (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => setManualTestStatus(item.val)}
                  className={`p-2 text-[10px] font-mono font-bold uppercase border transition-colors ${
                    status === item.val
                      ? 'bg-[#111111] text-[#F7F4ED] dark:bg-[#F7F4ED] dark:text-[#111111] border-[#111111] dark:border-[#F7F4ED]'
                      : 'bg-[#F7F4ED] dark:bg-[#111111] text-[#111111] dark:text-[#F7F4ED] border-[#111111]/30 dark:border-[#F7F4ED]/30 hover:border-[#111111] dark:hover:border-[#F7F4ED]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {isTestMode && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setManualTestStatus(null)}
                className="w-full text-xs font-mono font-bold mt-2"
              >
                RESET TO LIVE SPOTIFY STATUS
              </Button>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
