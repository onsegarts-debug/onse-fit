/**
 * ONSE FIT — Calendar Engine
 * Deterministic mapping of local SQLite/Dexie entities to calendar hierarchical views:
 * Year → Month → Week → Day
 */

import type { 
  Workout, WorkoutExercise, Set as DbSet, Exercise,
  SleepEntry, Habit, HabitLog, RecoveryEntry, 
  BodyWeight, Measurement, Note 
} from '../types';

export type CalendarViewMode = 'year' | 'month' | 'week' | 'day';

export interface CalendarDaySummary {
  date: string; // YYYY-MM-DD
  dayNumber: number;
  dayOfWeek: number; // 0 = Mon, 6 = Sun
  isCurrentMonth: boolean;
  isToday: boolean;
  
  // Workouts
  workouts: Workout[];
  completedWorkouts: Workout[];
  hasWorkouts: boolean;
  totalVolumeKg: number;
  totalSets: number;

  // Sleep
  sleep?: SleepEntry;
  hasSleep: boolean;
  sleepHours: number | null;

  // Habits
  habitsSummary: {
    total: number;
    completed: number;
    percentage: number;
  };
  hasHabits: boolean;

  // Recovery
  recovery?: RecoveryEntry;
  hasRecovery: boolean;
  readinessScore: number | null;

  // Body Weight
  bodyWeight?: BodyWeight;
  hasBodyWeight: boolean;

  // Measurements
  measurements: Measurement[];
  hasMeasurements: boolean;

  // Notes
  notes: Note[];
  hasNotes: boolean;

  // Activity density score (0 to 4) for heatmap rendering
  activityScore: number;
}

export interface MonthSummary {
  year: number;
  monthIndex: number; // 0 to 11
  monthName: string; // e.g. "September"
  shortMonthName: string; // e.g. "SEP"
  totalDays: number;
  activeDaysCount: number;
  totalWorkouts: number;
  totalVolumeKg: number;
  completedWorkoutsCount: number;
  averageSleepHours: number | null;
  habitsAdherencePercent: number | null;
  days: CalendarDaySummary[];
}

export interface WeekSummary {
  weekNumber: number;
  year: number;
  startDate: string; // YYYY-MM-DD (Monday)
  endDate: string; // YYYY-MM-DD (Sunday)
  label: string; // e.g. "Sep 1 – Sep 7, 2026"
  days: CalendarDaySummary[];
  totalWorkouts: number;
  totalVolumeKg: number;
  totalSets: number;
  activeDaysCount: number;
  averageSleepHours: number | null;
  habitCompletionRate: number;
}

export interface DayJournalDetail {
  date: string;
  formattedDate: string; // e.g. "Saturday, September 5, 2026"
  shortDate: string; // e.g. "Sat, Sep 5"
  dayOfWeekName: string; // "Saturday"
  isToday: boolean;
  
  workouts: Array<Workout & {
    exercises: Array<{
      exerciseName: string;
      category: string;
      setsCount: number;
      bestSet: { weight: number; reps: number };
      volumeKg: number;
    }>;
    totalVolumeKg: number;
    totalSets: number;
  }>;
  
  sleep?: SleepEntry;
  habits: Array<{
    habit: Habit;
    completed: boolean;
    logId?: string;
  }>;
  recovery?: RecoveryEntry;
  bodyWeight?: BodyWeight;
  measurements: Measurement[];
  notes: Note[];

  stats: {
    totalVolumeKg: number;
    totalSets: number;
    sleepHours: number | null;
    readinessScore: number | null;
    habitsCompletedCount: number;
    habitsTotalCount: number;
  };
}

export const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const SHORT_MONTH_NAMES = [
  'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
  'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
];

export const SHORT_DAY_NAMES = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

export const FULL_DAY_NAMES = [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
];

// Helper: Format Date to YYYY-MM-DD
export function toDateString(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Helper: Parse YYYY-MM-DD safely
export function parseDateString(str: string): Date {
  const parts = str.split('-');
  return new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
}

// Helper: Get Monday of the week for any date
export function getMondayOfWeek(d: Date): Date {
  const date = new Date(d);
  const day = date.getDay();
  // Sunday is 0, Mon is 1, ..., Sat is 6
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  date.setDate(diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

// Helper: ISO Week Number
export function getIsoWeekNumber(d: Date): number {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

/**
 * Maps single date record indices into a complete CalendarDaySummary
 */
export function buildDaySummary(
  dateStr: string,
  isCurrentMonth: boolean,
  workoutsMap: Map<string, Workout[]>,
  workoutVolumeMap: Map<string, { volume: number; sets: number }>,
  sleepMap: Map<string, SleepEntry>,
  habitsList: Habit[],
  habitLogsMap: Map<string, Set<string>>, // date -> set of completed habitIds
  recoveryMap: Map<string, RecoveryEntry>,
  bodyWeightMap: Map<string, BodyWeight>,
  measurementsMap: Map<string, Measurement[]>,
  notesMap: Map<string, Note[]>
): CalendarDaySummary {
  const dateObj = parseDateString(dateStr);
  const todayStr = toDateString(new Date());
  const isToday = dateStr === todayStr;

  // Day of week: 0 = Mon, 6 = Sun
  const jsDay = dateObj.getDay();
  const dayOfWeek = jsDay === 0 ? 6 : jsDay - 1;

  const dayWorkouts = workoutsMap.get(dateStr) || [];
  const completedWorkouts = dayWorkouts.filter(w => w.completed);
  const volSets = workoutVolumeMap.get(dateStr) || { volume: 0, sets: 0 };

  const sleep = sleepMap.get(dateStr);
  const sleepHours = sleep?.durationMinutes ? Math.round((sleep.durationMinutes / 60) * 10) / 10 : null;

  const completedHabitIds = habitLogsMap.get(dateStr) || new Set();
  const habitsTotal = habitsList.length;
  let habitsCompleted = 0;
  for (const h of habitsList) {
    if (completedHabitIds.has(h.id)) habitsCompleted++;
  }
  const habitsPercentage = habitsTotal > 0 ? Math.round((habitsCompleted / habitsTotal) * 100) : 0;

  const recovery = recoveryMap.get(dateStr);
  let readinessScore: number | null = null;
  if (recovery) {
    // Standard formula: ((6 - soreness) * 20 + energy * 20 + (6 - stress) * 10) / 50 * 100
    const score = ((6 - recovery.soreness) * 20 + recovery.energy * 20 + (6 - recovery.stress) * 10);
    readinessScore = Math.min(100, Math.max(0, Math.round((score / 250) * 100)));
  }

  const bodyWeight = bodyWeightMap.get(dateStr);
  const measurements = measurementsMap.get(dateStr) || [];
  const notes = notesMap.get(dateStr) || [];

  // Calculate activity score (0 to 4)
  let score = 0;
  if (completedWorkouts.length > 0) score += 2;
  else if (dayWorkouts.length > 0) score += 1;
  if (sleep) score += 1;
  if (habitsCompleted > 0) score += 1;
  if (recovery || bodyWeight || notes.length > 0) score += 1;
  const activityScore = Math.min(4, score);

  return {
    date: dateStr,
    dayNumber: dateObj.getDate(),
    dayOfWeek,
    isCurrentMonth,
    isToday,
    workouts: dayWorkouts,
    completedWorkouts,
    hasWorkouts: dayWorkouts.length > 0,
    totalVolumeKg: volSets.volume,
    totalSets: volSets.sets,
    sleep,
    hasSleep: !!sleep,
    sleepHours,
    habitsSummary: {
      total: habitsTotal,
      completed: habitsCompleted,
      percentage: habitsPercentage
    },
    hasHabits: habitsTotal > 0,
    recovery,
    hasRecovery: !!recovery,
    readinessScore,
    bodyWeight,
    hasBodyWeight: !!bodyWeight,
    measurements,
    hasMeasurements: measurements.length > 0,
    notes,
    hasNotes: notes.length > 0,
    activityScore
  };
}

/**
 * Pre-indexes raw SQLite database tables by date (YYYY-MM-DD) for fast retrieval
 */
export function buildDatabaseDateIndexes(
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: DbSet[],
  sleepEntries: SleepEntry[],
  habits: Habit[],
  habitLogs: HabitLog[],
  recoveryEntries: RecoveryEntry[],
  bodyWeights: BodyWeight[],
  measurements: Measurement[],
  notes: Note[]
) {
  // Index workouts by date
  const workoutsMap = new Map<string, Workout[]>();
  for (const w of workouts) {
    const list = workoutsMap.get(w.date) || [];
    list.push(w);
    workoutsMap.set(w.date, list);
  }

  // Calculate volume & sets per workout
  const setVolumeByWE = new Map<string, { volume: number; sets: number }>();
  for (const s of sets) {
    if (s.completed) {
      const current = setVolumeByWE.get(s.workoutExerciseId) || { volume: 0, sets: 0 };
      current.volume += s.weight * s.reps;
      current.sets += 1;
      setVolumeByWE.set(s.workoutExerciseId, current);
    }
  }

  const weToWorkoutMap = new Map<string, string>();
  for (const we of workoutExercises) {
    weToWorkoutMap.set(we.id, we.workoutId);
  }

  const workoutTotals = new Map<string, { volume: number; sets: number }>();
  for (const [weId, data] of setVolumeByWE.entries()) {
    const wId = weToWorkoutMap.get(weId);
    if (wId) {
      const current = workoutTotals.get(wId) || { volume: 0, sets: 0 };
      current.volume += data.volume;
      current.sets += data.sets;
      workoutTotals.set(wId, current);
    }
  }

  // Volume & sets per date
  const workoutVolumeMap = new Map<string, { volume: number; sets: number }>();
  for (const w of workouts) {
    if (w.completed) {
      const totals = workoutTotals.get(w.id) || { volume: 0, sets: 0 };
      const current = workoutVolumeMap.get(w.date) || { volume: 0, sets: 0 };
      current.volume += totals.volume;
      current.sets += totals.sets;
      workoutVolumeMap.set(w.date, current);
    }
  }

  // Index sleep
  const sleepMap = new Map<string, SleepEntry>();
  for (const s of sleepEntries) {
    sleepMap.set(s.date, s);
  }

  // Index habit logs: date -> set of completed habitIds
  const habitLogsMap = new Map<string, Set<string>>();
  for (const hl of habitLogs) {
    if (hl.completed) {
      const set = habitLogsMap.get(hl.date) || new Set<string>();
      set.add(hl.habitId);
      habitLogsMap.set(hl.date, set);
    }
  }

  // Index recovery
  const recoveryMap = new Map<string, RecoveryEntry>();
  for (const r of recoveryEntries) {
    recoveryMap.set(r.date, r);
  }

  // Index body weights
  const bodyWeightMap = new Map<string, BodyWeight>();
  for (const bw of bodyWeights) {
    bodyWeightMap.set(bw.date, bw);
  }

  // Index measurements
  const measurementsMap = new Map<string, Measurement[]>();
  for (const m of measurements) {
    const list = measurementsMap.get(m.date) || [];
    list.push(m);
    measurementsMap.set(m.date, list);
  }

  // Index notes
  const notesMap = new Map<string, Note[]>();
  for (const n of notes) {
    const list = notesMap.get(n.date) || [];
    list.push(n);
    notesMap.set(n.date, list);
  }

  return {
    workoutsMap,
    workoutVolumeMap,
    sleepMap,
    habits,
    habitLogsMap,
    recoveryMap,
    bodyWeightMap,
    measurementsMap,
    notesMap
  };
}

/**
 * Builds the 12 Month summaries for a Year View
 */
export function getYearData(
  year: number,
  indexes: ReturnType<typeof buildDatabaseDateIndexes>
): {
  year: number;
  totalWorkouts: number;
  totalVolumeKg: number;
  totalActiveDays: number;
  months: MonthSummary[];
} {
  const months: MonthSummary[] = [];
  let totalWorkouts = 0;
  let totalVolumeKg = 0;
  let totalActiveDays = 0;

  for (let m = 0; m < 12; m++) {
    const monthSummary = getMonthData(year, m, indexes);
    months.push(monthSummary);
    totalWorkouts += monthSummary.totalWorkouts;
    totalVolumeKg += monthSummary.totalVolumeKg;
    totalActiveDays += monthSummary.activeDaysCount;
  }

  return {
    year,
    totalWorkouts,
    totalVolumeKg,
    totalActiveDays,
    months
  };
}

/**
 * Builds Month calendar grid with full padding days (Mon-Sun)
 */
export function getMonthData(
  year: number,
  monthIndex: number,
  indexes: ReturnType<typeof buildDatabaseDateIndexes>
): MonthSummary {
  const firstDayOfMonth = new Date(year, monthIndex, 1);
  const lastDayOfMonth = new Date(year, monthIndex + 1, 0);
  const totalDays = lastDayOfMonth.getDate();

  // Find the Monday on or before the 1st of this month
  const gridStart = getMondayOfWeek(firstDayOfMonth);

  // Find Sunday on or after last day of month
  const gridEnd = new Date(lastDayOfMonth);
  const lastDayOfWeek = gridEnd.getDay();
  const daysToAdd = lastDayOfWeek === 0 ? 0 : 7 - lastDayOfWeek;
  gridEnd.setDate(gridEnd.getDate() + daysToAdd);

  const days: CalendarDaySummary[] = [];
  let activeDaysCount = 0;
  let totalWorkouts = 0;
  let completedWorkoutsCount = 0;
  let totalVolumeKg = 0;
  let sleepDurationMinutesSum = 0;
  let sleepLoggedDays = 0;
  let habitAdherenceSum = 0;
  let habitLoggedDays = 0;

  const cur = new Date(gridStart);
  while (cur <= gridEnd) {
    const dateStr = toDateString(cur);
    const isCurrentMonth = cur.getMonth() === monthIndex;

    const daySummary = buildDaySummary(
      dateStr,
      isCurrentMonth,
      indexes.workoutsMap,
      indexes.workoutVolumeMap,
      indexes.sleepMap,
      indexes.habits,
      indexes.habitLogsMap,
      indexes.recoveryMap,
      indexes.bodyWeightMap,
      indexes.measurementsMap,
      indexes.notesMap
    );

    days.push(daySummary);

    if (isCurrentMonth) {
      if (daySummary.activityScore > 0) activeDaysCount++;
      totalWorkouts += daySummary.workouts.length;
      completedWorkoutsCount += daySummary.completedWorkouts.length;
      totalVolumeKg += daySummary.totalVolumeKg;

      if (daySummary.sleep?.durationMinutes) {
        sleepDurationMinutesSum += daySummary.sleep.durationMinutes;
        sleepLoggedDays++;
      }
      if (daySummary.hasHabits) {
        habitAdherenceSum += daySummary.habitsSummary.percentage;
        habitLoggedDays++;
      }
    }

    cur.setDate(cur.getDate() + 1);
  }

  const averageSleepHours = sleepLoggedDays > 0 
    ? Math.round((sleepDurationMinutesSum / sleepLoggedDays / 60) * 10) / 10 
    : null;

  const habitsAdherencePercent = habitLoggedDays > 0
    ? Math.round(habitAdherenceSum / habitLoggedDays)
    : null;

  return {
    year,
    monthIndex,
    monthName: MONTH_NAMES[monthIndex],
    shortMonthName: SHORT_MONTH_NAMES[monthIndex],
    totalDays,
    activeDaysCount,
    totalWorkouts,
    totalVolumeKg,
    completedWorkoutsCount,
    averageSleepHours,
    habitsAdherencePercent,
    days
  };
}

/**
 * Builds 7-day Week Summary around a reference date
 */
export function getWeekData(
  referenceDateStr: string,
  indexes: ReturnType<typeof buildDatabaseDateIndexes>
): WeekSummary {
  const refDate = parseDateString(referenceDateStr);
  const monday = getMondayOfWeek(refDate);
  const weekNumber = getIsoWeekNumber(monday);

  const days: CalendarDaySummary[] = [];
  let totalWorkouts = 0;
  let totalVolumeKg = 0;
  let totalSets = 0;
  let activeDaysCount = 0;
  let sleepDurationMinutesSum = 0;
  let sleepLoggedDays = 0;
  let habitAdherenceSum = 0;

  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const dateStr = toDateString(d);

    const daySummary = buildDaySummary(
      dateStr,
      true,
      indexes.workoutsMap,
      indexes.workoutVolumeMap,
      indexes.sleepMap,
      indexes.habits,
      indexes.habitLogsMap,
      indexes.recoveryMap,
      indexes.bodyWeightMap,
      indexes.measurementsMap,
      indexes.notesMap
    );

    days.push(daySummary);

    if (daySummary.activityScore > 0) activeDaysCount++;
    totalWorkouts += daySummary.completedWorkouts.length;
    totalVolumeKg += daySummary.totalVolumeKg;
    totalSets += daySummary.totalSets;

    if (daySummary.sleep?.durationMinutes) {
      sleepDurationMinutesSum += daySummary.sleep.durationMinutes;
      sleepLoggedDays++;
    }
    habitAdherenceSum += daySummary.habitsSummary.percentage;
  }

  const startDate = days[0].date;
  const endDate = days[6].date;
  const startMonthShort = SHORT_MONTH_NAMES[parseInt(startDate.split('-')[1], 10) - 1];
  const endMonthShort = SHORT_MONTH_NAMES[parseInt(endDate.split('-')[1], 10) - 1];
  const startDay = parseInt(startDate.split('-')[2], 10);
  const endDay = parseInt(endDate.split('-')[2], 10);

  const label = startMonthShort === endMonthShort
    ? `${startMonthShort} ${startDay} – ${endDay}, ${monday.getFullYear()}`
    : `${startMonthShort} ${startDay} – ${endMonthShort} ${endDay}, ${monday.getFullYear()}`;

  const averageSleepHours = sleepLoggedDays > 0
    ? Math.round((sleepDurationMinutesSum / sleepLoggedDays / 60) * 10) / 10
    : null;

  const habitCompletionRate = Math.round(habitAdherenceSum / 7);

  return {
    weekNumber,
    year: monday.getFullYear(),
    startDate,
    endDate,
    label,
    days,
    totalWorkouts,
    totalVolumeKg,
    totalSets,
    activeDaysCount,
    averageSleepHours,
    habitCompletionRate
  };
}

/**
 * Builds full Day Journal Detail for a specific date
 */
export function getDayJournalData(
  dateStr: string,
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: DbSet[],
  exercises: Exercise[],
  sleepEntries: SleepEntry[],
  habits: Habit[],
  habitLogs: HabitLog[],
  recoveryEntries: RecoveryEntry[],
  bodyWeights: BodyWeight[],
  measurements: Measurement[],
  notes: Note[]
): DayJournalDetail {
  const dateObj = parseDateString(dateStr);
  const todayStr = toDateString(new Date());
  const isToday = dateStr === todayStr;

  const jsDay = dateObj.getDay();
  const dayOfWeekIndex = jsDay === 0 ? 6 : jsDay - 1;
  const dayOfWeekName = FULL_DAY_NAMES[dayOfWeekIndex];
  const monthName = MONTH_NAMES[dateObj.getMonth()];
  const formattedDate = `${dayOfWeekName}, ${monthName} ${dateObj.getDate()}, ${dateObj.getFullYear()}`;
  const shortDate = `${SHORT_DAY_NAMES[dayOfWeekIndex]}, ${SHORT_MONTH_NAMES[dateObj.getMonth()]} ${dateObj.getDate()}`;

  // Workouts on this date
  const dayWorkouts = workouts.filter(w => w.date === dateStr);
  const exerciseMap = new Map(exercises.map(e => [e.id, e]));

  let dayTotalVolume = 0;
  let dayTotalSets = 0;

  const detailedWorkouts = dayWorkouts.map(w => {
    const wExercises = workoutExercises.filter(we => we.workoutId === w.id);
    let workoutVol = 0;
    let workoutSetsCount = 0;

    const exerciseDetails = wExercises.map(we => {
      const ex = exerciseMap.get(we.exerciseId);
      const exSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);

      let exVol = 0;
      let bestSet = { weight: 0, reps: 0 };

      for (const s of exSets) {
        exVol += s.weight * s.reps;
        workoutSetsCount++;
        if (s.weight > bestSet.weight || (s.weight === bestSet.weight && s.reps > bestSet.reps)) {
          bestSet = { weight: s.weight, reps: s.reps };
        }
      }

      workoutVol += exVol;

      return {
        exerciseName: ex ? ex.name : 'Unknown Exercise',
        category: ex ? ex.category : 'general',
        setsCount: exSets.length,
        bestSet,
        volumeKg: exVol
      };
    });

    dayTotalVolume += workoutVol;
    dayTotalSets += workoutSetsCount;

    return {
      ...w,
      exercises: exerciseDetails,
      totalVolumeKg: workoutVol,
      totalSets: workoutSetsCount
    };
  });

  // Sleep
  const sleep = sleepEntries.find(s => s.date === dateStr);
  const sleepHours = sleep?.durationMinutes ? Math.round((sleep.durationMinutes / 60) * 10) / 10 : null;

  // Habits
  const completedHabitLogMap = new Map(
    habitLogs.filter(hl => hl.date === dateStr && hl.completed).map(hl => [hl.habitId, hl.id])
  );

  const habitsList = habits.map(h => ({
    habit: h,
    completed: completedHabitLogMap.has(h.id),
    logId: completedHabitLogMap.get(h.id)
  }));

  const habitsCompletedCount = habitsList.filter(h => h.completed).length;

  // Recovery
  const recovery = recoveryEntries.find(r => r.date === dateStr);
  let readinessScore: number | null = null;
  if (recovery) {
    const score = ((6 - recovery.soreness) * 20 + recovery.energy * 20 + (6 - recovery.stress) * 10);
    readinessScore = Math.min(100, Math.max(0, Math.round((score / 250) * 100)));
  }

  // Body weight
  const bodyWeight = bodyWeights.find(bw => bw.date === dateStr);

  // Measurements
  const dayMeasurements = measurements.filter(m => m.date === dateStr);

  // Notes
  const dayNotes = notes.filter(n => n.date === dateStr);

  return {
    date: dateStr,
    formattedDate,
    shortDate,
    dayOfWeekName,
    isToday,
    workouts: detailedWorkouts,
    sleep,
    habits: habitsList,
    recovery,
    bodyWeight,
    measurements: dayMeasurements,
    notes: dayNotes,
    stats: {
      totalVolumeKg: dayTotalVolume,
      totalSets: dayTotalSets,
      sleepHours,
      readinessScore,
      habitsCompletedCount,
      habitsTotalCount: habits.length
    }
  };
}
