import type { Workout, WorkoutExercise, Set, Exercise, BodyWeight, Measurement, PersonalRecord, ProgressPhoto } from '../types';

/**
 * ONSE FIT Analytics & Statistical Engine
 * 
 * All metrics, PR detection, and trend computations are strictly deterministic.
 * Zero fabricated data: statistics reflect exact local database records.
 */

export interface ExerciseSessionTrend {
  workoutId: string;
  workoutName: string;
  date: string;
  maxWeight: number;
  bestEstimated1RM: number;
  totalVolume: number;
  totalReps: number;
  setCount: number;
  isPR: boolean;
  bestSet: { weight: number; reps: number; e1RM: number };
}

export interface DetectedPR {
  id: string;
  exerciseId: string;
  exerciseName: string;
  workoutId: string;
  workoutDate: string;
  type: 'weight' | 'estimated1RM' | 'volume';
  value: number;
  previousValue: number;
  delta: number;
  percentGain: number;
  reps: number;
  weight: number;
}

export interface ExerciseAllTimeRecords {
  exerciseId: string;
  exerciseName: string;
  targetMuscle: string;
  category: string;
  maxWeight: { value: number; reps: number; date: string; workoutId: string } | null;
  bestEstimated1RM: { value: number; weight: number; reps: number; date: string; workoutId: string } | null;
  maxSetVolume: { value: number; weight: number; reps: number; date: string; workoutId: string } | null;
  maxSessionVolume: { value: number; date: string; workoutId: string } | null;
  totalVolumeAllTime: number;
  totalSetsCompleted: number;
  totalRepsCompleted: number;
  sessionsCount: number;
}

export interface WeightStats {
  currentWeight: number | null;
  startingWeight: number | null;
  netChange: number | null;
  minWeight: number | null;
  maxWeight: number | null;
  sevenDayChange: number | null;
  thirtyDayChange: number | null;
  latestDate: string | null;
  entriesCount: number;
  chartPoints: Array<{ date: string; weight: number; rolling7DayAvg: number }>;
}

export interface MeasurementTrend {
  type: string;
  latestValue: number;
  startingValue: number;
  netChange: number;
  unit: string;
  latestDate: string;
  history: Array<{ id: string; date: string; value: number; unit: string; notes?: string }>;
}

export interface OverallTrainingStats {
  totalWorkoutsCompleted: number;
  totalVolumeKg: number;
  totalVolumeAllTime: number;
  volumeLast7Days: number;
  volumeLast30Days: number;
  workoutsPerWeek: number;
  frequencyPerWeek: number;
  totalCompletedSets: number;
  totalCompletedReps: number;
  averageDurationMinutes: number;
  muscleDistribution: Array<{ category: string; volume: number; percentage: number }>;
  weeklyVolumeTrends: Array<{ weekLabel: string; volume: number; workoutsCount: number }>;
  weeklyVolumeBreakdown: Array<{ weekLabel: string; totalVolume: number; workoutCount: number }>;
  recentPRsCount: number;
}

/**
 * Deterministic Epley Formula for 1RM:
 * 1RM = Weight * (1 + Reps / 30)
 * Validated standard in exercise physiology for 1-12 reps.
 */
export function calculateEstimated1RM(weight: number, reps: number): number {
  if (!weight || weight <= 0 || !reps || reps <= 0) return 0;
  if (reps === 1) return Math.round(weight * 10) / 10;
  const e1rm = weight * (1 + reps / 30);
  return Math.round(e1rm * 10) / 10;
}

/**
 * Deterministic Set Volume:
 * Volume = Weight * Reps
 */
export function calculateSetVolume(weight: number, reps: number): number {
  if (!weight || weight <= 0 || !reps || reps <= 0) return 0;
  return Math.round(weight * reps * 10) / 10;
}

/**
 * Deterministic PR Detection Engine
 * Evaluates chronological completed sets for an exercise.
 * Flags every point in time where an athlete breaks their prior personal best.
 */
export function detectDeterministicPRs(
  exerciseId: string,
  exerciseName: string,
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[]
): { records: ExerciseAllTimeRecords; milestoneHistory: DetectedPR[]; sessionTrends: ExerciseSessionTrend[] } {
  // 1. Filter workout exercises for this exercise
  const weList = workoutExercises.filter(we => we.exerciseId === exerciseId);
  const weMap = new Map(weList.map(we => [we.id, we]));

  // 2. Filter sets belonging to these workout exercises and completed
  const completedSets = sets.filter(s => weMap.has(s.workoutExerciseId) && s.completed && s.reps > 0 && s.weight > 0);

  // 3. Map sets to their workout and date
  const workoutMap = new Map(workouts.map(w => [w.id, w]));

  interface EnrichedSet {
    set: Set;
    workout: Workout;
    date: string;
    e1RM: number;
    volume: number;
  }

  const enrichedSets: EnrichedSet[] = [];
  for (const s of completedSets) {
    const we = weMap.get(s.workoutExerciseId);
    if (!we) continue;
    const w = workoutMap.get(we.workoutId);
    if (!w) continue;
    enrichedSets.push({
      set: s,
      workout: w,
      date: w.date,
      e1RM: calculateEstimated1RM(s.weight, s.reps),
      volume: calculateSetVolume(s.weight, s.reps)
    });
  }

  // 4. Sort chronologically: Date asc, then workout startTime/id, then set order
  enrichedSets.sort((a, b) => {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    const startA = a.workout.startTime || '';
    const startB = b.workout.startTime || '';
    if (startA !== startB) return startA.localeCompare(startB);
    return a.set.order - b.set.order;
  });

  // 5. Walk through chronological sets with deterministic tracking
  let maxWeightRecord = 0;
  let maxE1RMRecord = 0;
  let maxVolumeSetRecord = 0;

  const milestoneHistory: DetectedPR[] = [];

  // Group by workout to compute session trends
  const sessionGroups = new Map<string, { workout: Workout; sets: EnrichedSet[] }>();
  for (const es of enrichedSets) {
    if (!sessionGroups.has(es.workout.id)) {
      sessionGroups.set(es.workout.id, { workout: es.workout, sets: [] });
    }
    sessionGroups.get(es.workout.id)!.sets.push(es);
  }

  // Evaluate PRs in order
  for (const es of enrichedSets) {
    const { weight, reps } = es.set;
    const { e1RM, volume, date, workout } = es;

    // A. Weight PR (Must be higher than prior best)
    if (weight > maxWeightRecord) {
      if (maxWeightRecord > 0) {
        const delta = Math.round((weight - maxWeightRecord) * 10) / 10;
        const percentGain = Math.round((delta / maxWeightRecord) * 1000) / 10;
        milestoneHistory.push({
          id: `pr-weight-${workout.id}-${es.set.id}`,
          exerciseId,
          exerciseName,
          workoutId: workout.id,
          workoutDate: date,
          type: 'weight',
          value: weight,
          previousValue: maxWeightRecord,
          delta,
          percentGain,
          reps,
          weight
        });
      }
      maxWeightRecord = weight;
    }

    // B. Estimated 1RM PR (Must be higher than prior best)
    if (e1RM > maxE1RMRecord) {
      if (maxE1RMRecord > 0) {
        const delta = Math.round((e1RM - maxE1RMRecord) * 10) / 10;
        const percentGain = Math.round((delta / maxE1RMRecord) * 1000) / 10;
        milestoneHistory.push({
          id: `pr-1rm-${workout.id}-${es.set.id}`,
          exerciseId,
          exerciseName,
          workoutId: workout.id,
          workoutDate: date,
          type: 'estimated1RM',
          value: e1RM,
          previousValue: maxE1RMRecord,
          delta,
          percentGain,
          reps,
          weight
        });
      }
      maxE1RMRecord = e1RM;
    }

    // C. Single-Set Volume PR
    if (volume > maxVolumeSetRecord) {
      if (maxVolumeSetRecord > 0) {
        const delta = Math.round((volume - maxVolumeSetRecord) * 10) / 10;
        const percentGain = Math.round((delta / maxVolumeSetRecord) * 1000) / 10;
        milestoneHistory.push({
          id: `pr-vol-${workout.id}-${es.set.id}`,
          exerciseId,
          exerciseName,
          workoutId: workout.id,
          workoutDate: date,
          type: 'volume',
          value: volume,
          previousValue: maxVolumeSetRecord,
          delta,
          percentGain,
          reps,
          weight
        });
      }
      maxVolumeSetRecord = volume;
    }
  }

  // 6. Build Session Trends
  const sessionTrends: ExerciseSessionTrend[] = [];
  let highestSessionVol = 0;
  let bestSessionVolData: { value: number; date: string; workoutId: string } | null = null;
  let totalExerciseVol = 0;
  let totalSetsCount = 0;
  let totalRepsCount = 0;

  // Sort sessions chronologically
  const sortedSessions = Array.from(sessionGroups.values()).sort((a, b) => a.workout.date.localeCompare(b.workout.date));

  for (const session of sortedSessions) {
    const sSets = session.sets;
    let sMaxWeight = 0;
    let sBest1RM = 0;
    let sVol = 0;
    let sReps = 0;
    let sBestSet = { weight: 0, reps: 0, e1RM: 0 };

    for (const es of sSets) {
      if (es.set.weight > sMaxWeight) sMaxWeight = es.set.weight;
      if (es.e1RM > sBest1RM) {
        sBest1RM = es.e1RM;
        sBestSet = { weight: es.set.weight, reps: es.set.reps, e1RM: es.e1RM };
      }
      sVol += es.volume;
      sReps += es.set.reps;
      totalExerciseVol += es.volume;
      totalSetsCount++;
      totalRepsCount += es.set.reps;
    }

    sVol = Math.round(sVol * 10) / 10;

    if (sVol > highestSessionVol) {
      highestSessionVol = sVol;
      bestSessionVolData = { value: sVol, date: session.workout.date, workoutId: session.workout.id };
    }

    const hadPR = milestoneHistory.some(m => m.workoutId === session.workout.id);

    sessionTrends.push({
      workoutId: session.workout.id,
      workoutName: session.workout.name,
      date: session.workout.date,
      maxWeight: sMaxWeight,
      bestEstimated1RM: sBest1RM,
      totalVolume: sVol,
      totalReps: sReps,
      setCount: sSets.length,
      isPR: hadPR,
      bestSet: sBestSet
    });
  }

  // 7. Find peak record set pointers
  let maxWeightPointer: { value: number; reps: number; date: string; workoutId: string } | null = null;
  let best1RMPointer: { value: number; weight: number; reps: number; date: string; workoutId: string } | null = null;
  let maxSetVolPointer: { value: number; weight: number; reps: number; date: string; workoutId: string } | null = null;

  for (const es of enrichedSets) {
    if (!maxWeightPointer || es.set.weight > maxWeightPointer.value) {
      maxWeightPointer = { value: es.set.weight, reps: es.set.reps, date: es.date, workoutId: es.workout.id };
    }
    if (!best1RMPointer || es.e1RM > best1RMPointer.value) {
      best1RMPointer = { value: es.e1RM, weight: es.set.weight, reps: es.set.reps, date: es.date, workoutId: es.workout.id };
    }
    if (!maxSetVolPointer || es.volume > maxSetVolPointer.value) {
      maxSetVolPointer = { value: es.volume, weight: es.set.weight, reps: es.set.reps, date: es.date, workoutId: es.workout.id };
    }
  }

  const records: ExerciseAllTimeRecords = {
    exerciseId,
    exerciseName,
    targetMuscle: '',
    category: '',
    maxWeight: maxWeightPointer,
    bestEstimated1RM: best1RMPointer,
    maxSetVolume: maxSetVolPointer,
    maxSessionVolume: bestSessionVolData,
    totalVolumeAllTime: Math.round(totalExerciseVol * 10) / 10,
    totalSetsCompleted: totalSetsCount,
    totalRepsCompleted: totalRepsCount,
    sessionsCount: sortedSessions.length
  };

  return {
    records,
    milestoneHistory: milestoneHistory.reverse(), // Most recent milestones first
    sessionTrends
  };
}

/**
 * Body Weight Analytics with 7-day Rolling Average
 */
export function calculateBodyWeightStats(bodyWeights: BodyWeight[]): WeightStats {
  if (!bodyWeights || bodyWeights.length === 0) {
    return {
      currentWeight: null,
      startingWeight: null,
      netChange: null,
      minWeight: null,
      maxWeight: null,
      sevenDayChange: null,
      thirtyDayChange: null,
      latestDate: null,
      entriesCount: 0,
      chartPoints: []
    };
  }

  // Sort chronologically ascending
  const sorted = [...bodyWeights].sort((a, b) => a.date.localeCompare(b.date));

  const startingWeight = sorted[0].weight;
  const latestEntry = sorted[sorted.length - 1];
  const currentWeight = latestEntry.weight;
  const netChange = Math.round((currentWeight - startingWeight) * 10) / 10;

  let minWeight = sorted[0].weight;
  let maxWeight = sorted[0].weight;

  for (const entry of sorted) {
    if (entry.weight < minWeight) minWeight = entry.weight;
    if (entry.weight > maxWeight) maxWeight = entry.weight;
  }

  // Compute 7-day rolling average for each point
  const chartPoints: Array<{ date: string; weight: number; rolling7DayAvg: number }> = [];

  for (let i = 0; i < sorted.length; i++) {
    const current = sorted[i];
    const currentDate = new Date(current.date).getTime();
    const sevenDaysAgo = currentDate - 7 * 24 * 60 * 60 * 1000;

    // Collect all points in window [sevenDaysAgo, currentDate]
    const windowPoints = sorted.filter(p => {
      const pTime = new Date(p.date).getTime();
      return pTime >= sevenDaysAgo && pTime <= currentDate;
    });

    const sum = windowPoints.reduce((acc, p) => acc + p.weight, 0);
    const rollingAvg = Math.round((sum / windowPoints.length) * 10) / 10;

    chartPoints.push({
      date: current.date,
      weight: current.weight,
      rolling7DayAvg: rollingAvg
    });
  }

  // 7-day and 30-day delta from latest entry
  const latestTime = new Date(latestEntry.date).getTime();
  const sevenDaysAgoTime = latestTime - 7 * 24 * 60 * 60 * 1000;
  const thirtyDaysAgoTime = latestTime - 30 * 24 * 60 * 60 * 1000;

  const entryAround7DaysAgo = sorted.find(p => new Date(p.date).getTime() >= sevenDaysAgoTime);
  const entryAround30DaysAgo = sorted.find(p => new Date(p.date).getTime() >= thirtyDaysAgoTime);

  const sevenDayChange = entryAround7DaysAgo && entryAround7DaysAgo !== latestEntry
    ? Math.round((currentWeight - entryAround7DaysAgo.weight) * 10) / 10
    : null;

  const thirtyDayChange = entryAround30DaysAgo && entryAround30DaysAgo !== latestEntry
    ? Math.round((currentWeight - entryAround30DaysAgo.weight) * 10) / 10
    : null;

  return {
    currentWeight,
    startingWeight,
    netChange,
    minWeight,
    maxWeight,
    sevenDayChange,
    thirtyDayChange,
    latestDate: latestEntry.date,
    entriesCount: sorted.length,
    chartPoints
  };
}

/**
 * Body Measurements Analytics
 */
export function calculateMeasurementStats(measurements: Measurement[]): MeasurementTrend[] {
  if (!measurements || measurements.length === 0) return [];

  // Group by type (waist, chest, arms, thighs, etc.)
  const groups = new Map<string, Measurement[]>();
  for (const m of measurements) {
    const key = m.type.toLowerCase().trim();
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(m);
  }

  const trends: MeasurementTrend[] = [];

  for (const [type, mList] of groups.entries()) {
    const sorted = [...mList].sort((a, b) => a.date.localeCompare(b.date));
    const starting = sorted[0];
    const latest = sorted[sorted.length - 1];
    const netChange = Math.round((latest.value - starting.value) * 10) / 10;

    trends.push({
      type,
      latestValue: latest.value,
      startingValue: starting.value,
      netChange,
      unit: latest.unit || 'cm',
      latestDate: latest.date,
      history: sorted.map(s => ({
        id: s.id,
        date: s.date,
        value: s.value,
        unit: s.unit,
        notes: s.notes
      }))
    });
  }

  // Sort alphabetically by type
  return trends.sort((a, b) => a.type.localeCompare(b.type));
}

/**
 * Overall Training Analytics
 * Volume, Frequency, Muscle Distribution
 */
export function calculateOverallTrainingStats(
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  exercises: Exercise[]
): OverallTrainingStats {
  const completedWorkouts = workouts.filter(w => w.completed);
  const exerciseMap = new Map(exercises.map(e => [e.id, e]));
  const weMap = new Map(workoutExercises.map(we => [we.id, we]));
  const workoutMap = new Map(workouts.map(w => [w.id, w]));

  const now = Date.now();
  const sevenDaysAgo = now - 7 * 24 * 60 * 60 * 1000;
  const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000;

  let totalVol = 0;
  let vol7d = 0;
  let vol30d = 0;

  const categoryVolumes = new Map<string, number>();

  for (const s of sets) {
    if (!s.completed || s.weight <= 0 || s.reps <= 0) continue;
    const we = weMap.get(s.workoutExerciseId);
    if (!we) continue;
    const w = workoutMap.get(we.workoutId);
    if (!w || !w.completed) continue;

    const setVol = s.weight * s.reps;
    totalVol += setVol;

    const wTime = new Date(w.date).getTime();
    if (wTime >= sevenDaysAgo) vol7d += setVol;
    if (wTime >= thirtyDaysAgo) vol30d += setVol;

    const ex = exerciseMap.get(we.exerciseId);
    const cat = ex ? (ex.category || ex.targetMuscle || 'Other') : 'Other';
    categoryVolumes.set(cat, (categoryVolumes.get(cat) || 0) + setVol);
  }

  totalVol = Math.round(totalVol);
  vol7d = Math.round(vol7d);
  vol30d = Math.round(vol30d);

  // Muscle distribution percentage
  const muscleDistribution: Array<{ category: string; volume: number; percentage: number }> = [];
  if (totalVol > 0) {
    for (const [category, vol] of categoryVolumes.entries()) {
      muscleDistribution.push({
        category,
        volume: Math.round(vol),
        percentage: Math.round((vol / totalVol) * 1000) / 10
      });
    }
  }
  muscleDistribution.sort((a, b) => b.volume - a.volume);

  // Workout frequency calculation (workouts per week)
  let workoutsPerWeek = 0;
  if (completedWorkouts.length > 0) {
    const dates = completedWorkouts.map(w => new Date(w.date).getTime()).sort((a, b) => a - b);
    const spanDays = Math.max(7, Math.ceil((dates[dates.length - 1] - dates[0]) / (24 * 60 * 60 * 1000)) + 1);
    const weeks = spanDays / 7;
    workoutsPerWeek = Math.round((completedWorkouts.length / weeks) * 10) / 10;
  }

  // Weekly volume breakdown (last 6 weeks)
  const weeklyVolumeTrends: Array<{ weekLabel: string; volume: number; workoutsCount: number }> = [];
  for (let i = 5; i >= 0; i--) {
    const weekStart = now - (i + 1) * 7 * 24 * 60 * 60 * 1000;
    const weekEnd = now - i * 7 * 24 * 60 * 60 * 1000;

    const wksInWindow = completedWorkouts.filter(w => {
      const t = new Date(w.date).getTime();
      return t >= weekStart && t < weekEnd;
    });

    const wIds = new Set(wksInWindow.map(w => w.id));
    const targetWEs = workoutExercises.filter(we => wIds.has(we.workoutId));
    const targetWEIds = new Set(targetWEs.map(we => we.id));

    const wSets = sets.filter(s => targetWEIds.has(s.workoutExerciseId) && s.completed && s.weight > 0 && s.reps > 0);
    const wVol = wSets.reduce((acc, s) => acc + s.weight * s.reps, 0);

    const labelDate = new Date(weekStart);
    const label = `${labelDate.getMonth() + 1}/${labelDate.getDate()}`;

    weeklyVolumeTrends.push({
      weekLabel: `Wk ${label}`,
      volume: Math.round(wVol),
      workoutsCount: wksInWindow.length
    });
  }

  // Total completed sets, reps, and durations
  const completedSets = sets.filter(s => s.completed && s.weight > 0 && s.reps > 0);
  const totalCompletedSets = completedSets.length;
  const totalCompletedReps = completedSets.reduce((acc, s) => acc + s.reps, 0);

  let totalDurationMinutes = 0;
  let workoutsWithDuration = 0;
  for (const w of completedWorkouts) {
    if (w.startTime && w.endTime) {
      const diffMs = new Date(w.endTime).getTime() - new Date(w.startTime).getTime();
      if (diffMs > 0 && diffMs < 24 * 60 * 60 * 1000) {
        totalDurationMinutes += Math.round(diffMs / 60000);
        workoutsWithDuration++;
      }
    }
  }
  const averageDurationMinutes = workoutsWithDuration > 0
    ? Math.round(totalDurationMinutes / workoutsWithDuration)
    : 0;

  const weeklyVolumeBreakdown = weeklyVolumeTrends.map(t => ({
    weekLabel: t.weekLabel,
    totalVolume: t.volume,
    workoutCount: t.workoutsCount
  }));

  return {
    totalWorkoutsCompleted: completedWorkouts.length,
    totalVolumeKg: totalVol,
    totalVolumeAllTime: totalVol,
    volumeLast7Days: vol7d,
    volumeLast30Days: vol30d,
    workoutsPerWeek,
    frequencyPerWeek: workoutsPerWeek,
    totalCompletedSets,
    totalCompletedReps,
    averageDurationMinutes,
    muscleDistribution,
    weeklyVolumeTrends,
    weeklyVolumeBreakdown,
    recentPRsCount: 0
  };
}

/**
 * DETERMINISTIC TEST RUNNER
 * "Test calculations against known sample data."
 * Runs comprehensive assertions against predetermined mathematical benchmark cases.
 */
export interface CalculationTestResult {
  name: string;
  category: '1RM Formula' | 'Volume Formula' | 'PR Detection' | 'Rolling Average' | 'Measurement Delta';
  passed: boolean;
  expected: any;
  actual: any;
  explanation: string;
  message?: string;
}

export function runCalculationTests(): CalculationTestResult[] {
  const tests: CalculationTestResult[] = [];

  // 1. Epley 1RM with 1 rep: (100kg, 1 rep) => 100 kg
  const e1rm1 = calculateEstimated1RM(100, 1);
  tests.push({
    name: 'Epley 1RM Single Rep Boundary',
    category: '1RM Formula',
    passed: e1rm1 === 100,
    expected: 100,
    actual: e1rm1,
    explanation: 'Single rep set directly equals the lifted weight without formula multiplier.'
  });

  // 2. Epley 1RM with 5 reps: 100 * (1 + 5/30) = 116.666... => 116.7 kg
  const e1rm5 = calculateEstimated1RM(100, 5);
  tests.push({
    name: 'Epley 1RM Standard Multi-Rep (100kg x 5)',
    category: '1RM Formula',
    passed: e1rm5 === 116.7,
    expected: 116.7,
    actual: e1rm5,
    explanation: 'Epley formula 100 * (1 + 5/30) rounded to 1 decimal place equals 116.7 kg.'
  });

  // 3. Epley 1RM with 10 reps: 80 * (1 + 10/30) = 106.666... => 106.7 kg
  const e1rm10 = calculateEstimated1RM(80, 10);
  tests.push({
    name: 'Epley 1RM High-Rep Hypertrophy (80kg x 10)',
    category: '1RM Formula',
    passed: e1rm10 === 106.7,
    expected: 106.7,
    actual: e1rm10,
    explanation: 'Epley formula 80 * (1 + 10/30) rounded to 1 decimal place equals 106.7 kg.'
  });

  // 4. Set Volume Calculation: 92.5kg x 8 reps = 740 kg
  const vol1 = calculateSetVolume(92.5, 8);
  tests.push({
    name: 'Set Tonnage Volume (92.5kg x 8 reps)',
    category: 'Volume Formula',
    passed: vol1 === 740,
    expected: 740,
    actual: vol1,
    explanation: 'Set volume = weight * reps = 92.5 * 8 = 740 kg.'
  });

  // 5. Deterministic PR Progression Sequence
  // Session 1: 100kg x 3 (e1RM 110kg, vol 300kg)
  // Session 2: 95kg x 6 (e1RM 114kg, vol 570kg) -> breaks e1RM and Volume
  // Session 3: 105kg x 2 (e1RM 112kg, vol 210kg) -> breaks Weight (105 > 100)
  const mockWorkouts: Workout[] = [
    { id: 'w1', name: 'Day 1', date: '2026-01-01', completed: true },
    { id: 'w2', name: 'Day 2', date: '2026-01-08', completed: true },
    { id: 'w3', name: 'Day 3', date: '2026-01-15', completed: true }
  ];
  const mockWEs: WorkoutExercise[] = [
    { id: 'we1', workoutId: 'w1', exerciseId: 'ex1', order: 0 },
    { id: 'we2', workoutId: 'w2', exerciseId: 'ex1', order: 0 },
    { id: 'we3', workoutId: 'w3', exerciseId: 'ex1', order: 0 }
  ];
  const mockSets: Set[] = [
    { id: 's1', workoutExerciseId: 'we1', weight: 100, reps: 3, completed: true, order: 0 },
    { id: 's2', workoutExerciseId: 'we2', weight: 95, reps: 6, completed: true, order: 0 },
    { id: 's3', workoutExerciseId: 'we3', weight: 105, reps: 2, completed: true, order: 0 }
  ];

  const prOutput = detectDeterministicPRs('ex1', 'Bench Press', mockWorkouts, mockWEs, mockSets);
  const maxWeightPr = prOutput.records.maxWeight?.value;
  const best1RMPr = prOutput.records.bestEstimated1RM?.value;

  tests.push({
    name: 'Deterministic PR Peak Weight Detection',
    category: 'PR Detection',
    passed: maxWeightPr === 105,
    expected: 105,
    actual: maxWeightPr,
    explanation: 'Peak weight across all 3 sessions is strictly 105 kg from Session 3.'
  });

  tests.push({
    name: 'Deterministic PR Peak Estimated 1RM Detection',
    category: 'PR Detection',
    passed: best1RMPr === 114,
    expected: 114,
    actual: best1RMPr,
    explanation: 'Session 2 (95kg x 6) yields e1RM of 95*(1+6/30)=114kg, higher than Session 1 (110kg) and Session 3 (112kg).'
  });

  // 6. 7-Day Rolling Average Verification
  const sampleWeights: BodyWeight[] = [
    { id: 'bw1', date: '2026-02-01', weight: 80.0 },
    { id: 'bw2', date: '2026-02-02', weight: 80.5 },
    { id: 'bw3', date: '2026-02-03', weight: 81.0 },
    { id: 'bw4', date: '2026-02-04', weight: 80.8 },
    { id: 'bw5', date: '2026-02-05', weight: 80.2 },
    { id: 'bw6', date: '2026-02-06', weight: 80.4 },
    { id: 'bw7', date: '2026-02-07', weight: 80.1 }
  ];
  // Sum = 80.0 + 80.5 + 81.0 + 80.8 + 80.2 + 80.4 + 80.1 = 563.0 / 7 = 80.428... => 80.4
  const bwStats = calculateBodyWeightStats(sampleWeights);
  const day7RollingAvg = bwStats.chartPoints[6]?.rolling7DayAvg;

  tests.push({
    name: '7-Day Rolling Weight Average Math',
    category: 'Rolling Average',
    passed: day7RollingAvg === 80.4,
    expected: 80.4,
    actual: day7RollingAvg,
    explanation: 'Average of 7 daily weigh-ins summing to 563.0 / 7 rounded to 1 decimal equals 80.4 kg.'
  });

  // 7. Measurement Net Delta
  const sampleMeasurements: Measurement[] = [
    { id: 'm1', type: 'waist', value: 88, unit: 'cm', date: '2026-01-01' },
    { id: 'm2', type: 'waist', value: 85, unit: 'cm', date: '2026-01-15' },
    { id: 'm3', type: 'waist', value: 83, unit: 'cm', date: '2026-02-01' }
  ];
  const mStats = calculateMeasurementStats(sampleMeasurements);
  const waistDelta = mStats.find(t => t.type === 'waist')?.netChange;

  tests.push({
    name: 'Circumference Net Measurement Delta',
    category: 'Measurement Delta',
    passed: waistDelta === -5,
    expected: -5,
    actual: waistDelta,
    explanation: '83 cm latest minus 88 cm baseline equals exactly -5.0 cm reduction.'
  });

  return tests;
}
