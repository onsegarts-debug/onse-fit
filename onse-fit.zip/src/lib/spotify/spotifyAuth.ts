/**
 * ONSE FIT
 * Spotify OAuth 2.0 Auth Engine with PKCE
 * Secure token management without exposing client secrets
 */

import { generateCodeVerifier, generateCodeChallenge, generateRandomString } from './pkce';
import type { SpotifyTokens, SpotifyUserProfile } from '../../types';

export const SPOTIFY_AUTH_ENDPOINT = 'https://accounts.spotify.com/authorize';
export const SPOTIFY_TOKEN_ENDPOINT = 'https://accounts.spotify.com/api/token';

export const SPOTIFY_SCOPES = [
  'user-read-private',
  'user-read-email',
  'playlist-read-private',
  'playlist-read-collaborative',
  'user-read-playback-state',
  'user-modify-playback-state'
].join(' ');

// LocalStorage Keys
export const STORAGE_KEYS = {
  TOKENS: 'onse_spotify_tokens',
  CLIENT_ID: 'onse_spotify_client_id',
  VERIFIER: 'onse_spotify_code_verifier',
  STATE: 'onse_spotify_auth_state',
  REDIRECT_URI: 'onse_spotify_redirect_uri',
  USER_PROFILE: 'onse_spotify_user_profile',
  PLAYLISTS_CACHE: 'onse_spotify_playlists_cache'
};

// Default Fallback Client ID (can be overridden by user in Profile > Integrations > Spotify)
export const DEFAULT_SPOTIFY_CLIENT_ID = 'b7f03d9ff94a4c6a9643d99e525656bb';

export function getSpotifyClientId(): string {
  try {
    return localStorage.getItem(STORAGE_KEYS.CLIENT_ID) || DEFAULT_SPOTIFY_CLIENT_ID;
  } catch {
    return DEFAULT_SPOTIFY_CLIENT_ID;
  }
}

export function setSpotifyClientId(id: string): void {
  try {
    if (!id || id.trim() === '') {
      localStorage.removeItem(STORAGE_KEYS.CLIENT_ID);
    } else {
      localStorage.setItem(STORAGE_KEYS.CLIENT_ID, id.trim());
    }
  } catch (err) {
    console.warn('Failed to save Spotify Client ID to localStorage', err);
  }
}

export function getSpotifyRedirectUri(): string {
  if (typeof window !== 'undefined') {
    return `${window.location.origin}/callback/spotify`;
  }
  return 'https://ais-dev-v3ewsh7qwltpvio53lti2g-443987487114.asia-southeast1.run.app/callback/spotify';
}

export function getStoredTokens(): SpotifyTokens | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TOKENS);
    if (!raw) return null;
    return JSON.parse(raw) as SpotifyTokens;
  } catch {
    return null;
  }
}

export function saveTokens(tokens: SpotifyTokens): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(tokens));
  } catch (err) {
    console.warn('Failed to persist Spotify tokens', err);
  }
}

export function clearTokens(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.TOKENS);
    localStorage.removeItem(STORAGE_KEYS.VERIFIER);
    localStorage.removeItem(STORAGE_KEYS.STATE);
    localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  } catch (err) {
    console.warn('Failed to clear Spotify tokens', err);
  }
}

export function getStoredUserProfile(): SpotifyUserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) return null;
    return JSON.parse(raw) as SpotifyUserProfile;
  } catch {
    return null;
  }
}

export function saveStoredUserProfile(profile: SpotifyUserProfile): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  } catch (err) {
    console.warn('Failed to persist Spotify user profile', err);
  }
}

export function isTokenExpired(tokens: SpotifyTokens): boolean {
  // Add 60s buffer for safety
  return Date.now() >= (tokens.expiresAt - 60000);
}

/**
 * Builds the authorization URL and stores code_verifier + state in sessionStorage/localStorage
 */
export async function createAuthorizationUrl(customClientId?: string): Promise<{ url: string; state: string }> {
  const clientId = customClientId || getSpotifyClientId();
  const redirectUri = getSpotifyRedirectUri();
  const verifier = generateCodeVerifier();
  const challenge = await generateCodeChallenge(verifier);
  const state = generateRandomString(16);

  // Store for retrieval upon redirect/callback
  sessionStorage.setItem(STORAGE_KEYS.VERIFIER, verifier);
  sessionStorage.setItem(STORAGE_KEYS.STATE, state);
  sessionStorage.setItem(STORAGE_KEYS.REDIRECT_URI, redirectUri);
  sessionStorage.setItem(STORAGE_KEYS.CLIENT_ID, clientId);

  // Also persist to localStorage for cross-tab or popup safety
  localStorage.setItem(STORAGE_KEYS.VERIFIER, verifier);
  localStorage.setItem(STORAGE_KEYS.STATE, state);
  localStorage.setItem(STORAGE_KEYS.REDIRECT_URI, redirectUri);

  const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'code',
    redirect_uri: redirectUri,
    state: state,
    scope: SPOTIFY_SCOPES,
    code_challenge_method: 'S256',
    code_challenge: challenge,
    show_dialog: 'true' // forces login dialog to allow switching accounts
  });

  return {
    url: `${SPOTIFY_AUTH_ENDPOINT}?${params.toString()}`,
    state
  };
}

/**
 * Exchanges authorization code for access and refresh tokens using PKCE (no secret needed)
 */
export async function exchangeCodeForTokens(code: string, returnedState: string): Promise<SpotifyTokens> {
  const storedVerifier = sessionStorage.getItem(STORAGE_KEYS.VERIFIER) || localStorage.getItem(STORAGE_KEYS.VERIFIER);
  const storedState = sessionStorage.getItem(STORAGE_KEYS.STATE) || localStorage.getItem(STORAGE_KEYS.STATE);
  const redirectUri = sessionStorage.getItem(STORAGE_KEYS.REDIRECT_URI) || localStorage.getItem(STORAGE_KEYS.REDIRECT_URI) || getSpotifyRedirectUri();
  const clientId = sessionStorage.getItem(STORAGE_KEYS.CLIENT_ID) || getSpotifyClientId();

  if (!storedVerifier) {
    throw new Error('Code verifier missing from session. Authorization session timed out.');
  }

  if (storedState && returnedState && storedState !== returnedState) {
    throw new Error('OAuth state mismatch (CSRF protection). Please retry connecting.');
  }

  const bodyParams = new URLSearchParams({
    client_id: clientId,
    grant_type: 'authorization_code',
    code: code,
    redirect_uri: redirectUri,
    code_verifier: storedVerifier
  });

  const response = await fetch(SPOTIFY_TOKEN_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: bodyParams.toString()
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const errorDesc = errorData.error_description || errorData.error || response.statusText;
    throw new Error(`Token exchange failed (${response.status}): ${errorDesc}`);
  }

  const data = await response.json();
  const tokens: SpotifyTokens = {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    expiresIn: data.expires_in,
    expiresAt: Date.now() + (data.expires_in * 1000),
    scope: data.scope,
    tokenType: data.token_type
  };

  saveTokens(tokens);
  return tokens;
}

/**
 * Refreshes an expired access token using the stored refresh_token
 */
export async function refreshAccessToken(refreshToken: string, customClientId?: string): Promise<SpotifyTokens> {
  const clientId = customClientId || getSpotifyClientId();

  const bodyParams = new URLSearchParams({
    client_id: clientId,
    grant_type: 'refresh_token',
    refresh_token: refreshToken
  });

  const response = await fetch(SPOTIFY_TOKEN_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: bodyParams.toString()
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(`Failed to refresh token (${response.status}): ${errorData.error_description || response.statusText}`);
  }

  const data = await response.json();
  const currentTokens = getStoredTokens();

  const updatedTokens: SpotifyTokens = {
    accessToken: data.access_token,
    refreshToken: data.refresh_token || refreshToken, // Spotify may or may not return a new refresh token
    expiresIn: data.expires_in,
    expiresAt: Date.now() + (data.expires_in * 1000),
    scope: data.scope || currentTokens?.scope,
    tokenType: data.token_type || 'Bearer'
  };

  saveTokens(updatedTokens);
  return updatedTokens;
}
