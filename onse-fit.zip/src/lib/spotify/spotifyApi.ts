/**
 * ONSE FIT
 * Spotify Web API Client
 * Robust offline-first, error-mapped communication with Spotify endpoints.
 * Never invents mock or simulated playlists.
 */

import type { SpotifyUserProfile, SpotifyPlaylist, SpotifyConnectionStatus } from '../../types';
import { STORAGE_KEYS } from './spotifyAuth';

export const SPOTIFY_API_BASE = 'https://api.spotify.com/v1';

export class SpotifyApiError extends Error {
  status?: number;
  code: SpotifyConnectionStatus;

  constructor(message: string, code: SpotifyConnectionStatus, status?: number) {
    super(message);
    this.name = 'SpotifyApiError';
    this.code = code;
    this.status = status;
  }
}

/**
 * Check if the browser currently has an active network connection
 */
export function isNetworkAvailable(): boolean {
  return typeof navigator !== 'undefined' ? navigator.onLine : true;
}

/**
 * Base fetch wrapper that translates HTTP and network statuses to ONSE FIT Spotify connection states
 */
async function spotifyFetch<T>(endpoint: string, accessToken: string): Promise<T> {
  if (!isNetworkAvailable()) {
    throw new SpotifyApiError('Network connection unavailable. Operating in offline mode.', 'network_unavailable');
  }

  const url = endpoint.startsWith('http') ? endpoint : `${SPOTIFY_API_BASE}${endpoint}`;

  let response: Response;
  try {
    response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
  } catch (networkErr: any) {
    // Network fetch failure (DNS error, connection reset, offline)
    throw new SpotifyApiError(
      networkErr?.message || 'Failed to connect to Spotify. Network unavailable.',
      'network_unavailable'
    );
  }

  if (response.status === 401) {
    throw new SpotifyApiError('Spotify access token expired or revoked. Authentication required.', 'auth_required', 401);
  }

  if (response.status === 403) {
    throw new SpotifyApiError('Permission denied. Insufficient Spotify account permissions or scopes.', 'permission_denied', 403);
  }

  if (response.status >= 500 && response.status <= 504) {
    throw new SpotifyApiError('Spotify services are temporarily unavailable (server error). Local fitness data remains intact.', 'spotify_unavailable', response.status);
  }

  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}));
    const message = errorBody?.error?.message || response.statusText || 'Spotify API request failed';
    throw new SpotifyApiError(message, 'auth_failed', response.status);
  }

  return response.json();
}

/**
 * Fetch current authorized user's profile (/v1/me)
 */
export async function fetchUserProfile(accessToken: string): Promise<SpotifyUserProfile> {
  const data = await spotifyFetch<any>('/me', accessToken);

  const profile: SpotifyUserProfile = {
    id: data.id,
    displayName: data.display_name || data.id,
    email: data.email,
    product: data.product,
    imageUrl: data.images?.[0]?.url,
    uri: data.uri,
    externalUrl: data.external_urls?.spotify
  };

  return profile;
}

/**
 * Fetch current user's playlists (/v1/me/playlists)
 * Persists results to local cache so user can view their playlists offline
 */
export async function fetchUserPlaylists(accessToken: string, limit = 50): Promise<SpotifyPlaylist[]> {
  const data = await spotifyFetch<any>(`/me/playlists?limit=${limit}`, accessToken);

  if (!data || !Array.isArray(data.items)) {
    return [];
  }

  const playlists: SpotifyPlaylist[] = data.items
    .filter((item: any) => item !== null && item !== undefined)
    .map((item: any) => ({
      id: item.id,
      name: item.name || 'Untitled Playlist',
      description: item.description || '',
      uri: item.uri || `spotify:playlist:${item.id}`,
      externalUrl: item.external_urls?.spotify || `https://open.spotify.com/playlist/${item.id}`,
      imageUrl: item.images?.[0]?.url,
      tracksTotal: item.tracks?.total || 0,
      ownerName: item.owner?.display_name || 'Spotify'
    }));

  // Save to local cache for offline viewing
  try {
    localStorage.setItem(STORAGE_KEYS.PLAYLISTS_CACHE, JSON.stringify(playlists));
  } catch (err) {
    console.warn('Failed to cache playlists', err);
  }

  return playlists;
}

/**
 * Retrieve cached playlists from local storage (safe offline fallback)
 */
export function getCachedPlaylists(): SpotifyPlaylist[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PLAYLISTS_CACHE);
    if (!raw) return [];
    return JSON.parse(raw) as SpotifyPlaylist[];
  } catch {
    return [];
  }
}

/**
 * Fetch details for a specific playlist by ID (/v1/playlists/{id})
 */
export async function fetchPlaylist(accessToken: string, playlistId: string): Promise<SpotifyPlaylist> {
  const data = await spotifyFetch<any>(`/playlists/${playlistId}`, accessToken);

  return {
    id: data.id,
    name: data.name,
    description: data.description,
    uri: data.uri,
    externalUrl: data.external_urls?.spotify,
    imageUrl: data.images?.[0]?.url,
    tracksTotal: data.tracks?.total || 0,
    ownerName: data.owner?.display_name
  };
}

/**
 * Formats or parses a Spotify playlist link or URI
 * E.g.: "spotify:playlist:37i9dQZF1DXdLEN7aqioXM" or "https://open.spotify.com/playlist/37i9dQZF1DXdLEN7aqioXM?si=..."
 */
export function parseSpotifyPlaylistInput(input: string): { id: string; uri: string; url: string } | null {
  const trimmed = input.trim();
  if (!trimmed) return null;

  // URI match: spotify:playlist:ID
  const uriMatch = trimmed.match(/spotify:playlist:([a-zA-Z0-9]+)/);
  if (uriMatch && uriMatch[1]) {
    const id = uriMatch[1];
    return {
      id,
      uri: `spotify:playlist:${id}`,
      url: `https://open.spotify.com/playlist/${id}`
    };
  }

  // URL match: https://open.spotify.com/playlist/ID
  const urlMatch = trimmed.match(/open\.spotify\.com\/playlist\/([a-zA-Z0-9]+)/);
  if (urlMatch && urlMatch[1]) {
    const id = urlMatch[1];
    return {
      id,
      uri: `spotify:playlist:${id}`,
      url: `https://open.spotify.com/playlist/${id}`
    };
  }

  // Bare ID match (22 chars alphanumeric)
  if (/^[a-zA-Z0-9]{22}$/.test(trimmed)) {
    return {
      id: trimmed,
      uri: `spotify:playlist:${trimmed}`,
      url: `https://open.spotify.com/playlist/${trimmed}`
    };
  }

  return null;
}
