/**
 * ONSE FIT
 * Spotify Context & Provider
 * Manages connection lifecycle, playlist caching, associations with workouts/programs/days,
 * and robust error state handling across light/dark themes and mobile devices.
 */

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import type { 
  SpotifyConnectionStatus, 
  SpotifyUserProfile, 
  SpotifyPlaylist, 
  SpotifyTokens,
  SpotifyAssociation
} from '../../types';
import { 
  getStoredTokens, 
  saveTokens, 
  clearTokens, 
  getStoredUserProfile, 
  saveStoredUserProfile,
  isTokenExpired, 
  refreshAccessToken,
  createAuthorizationUrl,
  getSpotifyClientId,
  setSpotifyClientId as persistSpotifyClientId,
  getSpotifyRedirectUri
} from './spotifyAuth';
import { 
  fetchUserProfile, 
  fetchUserPlaylists, 
  getCachedPlaylists,
  isNetworkAvailable,
  SpotifyApiError
} from './spotifyApi';
import { db } from '../../db';
import { workoutsRepo, programsRepo, spotifyAssociationsRepo } from '../../db/api';

interface SpotifyContextType {
  status: SpotifyConnectionStatus;
  user: SpotifyUserProfile | null;
  playlists: SpotifyPlaylist[];
  isLoading: boolean;
  errorMessage: string | null;
  clientId: string;
  setClientId: (id: string) => void;
  redirectUri: string;
  connect: (customClientId?: string) => Promise<void>;
  disconnect: () => Promise<void>;
  refreshPlaylists: () => Promise<void>;
  openPlaylist: (uriOrUrl: string) => void;
  setManualTestStatus: (status: SpotifyConnectionStatus | null) => void;
  isTestMode: boolean;
  associatePlaylistWithWorkout: (workoutId: string, playlist: { id: string; name: string; uri: string }) => Promise<void>;
  removeWorkoutPlaylist: (workoutId: string) => Promise<void>;
  associatePlaylistWithProgram: (programId: string, playlist: { id: string; name: string; uri: string }) => Promise<void>;
  removeProgramPlaylist: (programId: string) => Promise<void>;
  associatePlaylistWithDay: (dateStr: string, playlist: { id: string; name: string; uri: string }) => Promise<void>;
  removeDayPlaylist: (dateStr: string) => Promise<void>;
}

const SpotifyContext = createContext<SpotifyContextType | null>(null);

export function SpotifyProvider({ children }: { children: ReactNode }) {
  const [clientId, setClientIdState] = useState<string>(getSpotifyClientId());
  const [tokens, setTokens] = useState<SpotifyTokens | null>(() => getStoredTokens());
  const [user, setUser] = useState<SpotifyUserProfile | null>(() => getStoredUserProfile());
  const [playlists, setPlaylists] = useState<SpotifyPlaylist[]>(() => getCachedPlaylists());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [testStatus, setTestStatus] = useState<SpotifyConnectionStatus | null>(null);

  // Derive base status
  const [realStatus, setRealStatus] = useState<SpotifyConnectionStatus>(() => {
    if (!isNetworkAvailable()) return 'network_unavailable';
    const stored = getStoredTokens();
    if (!stored) return 'disconnected';
    if (isTokenExpired(stored)) return 'auth_required';
    return 'connected';
  });

  const activeStatus = testStatus || realStatus;
  const redirectUri = getSpotifyRedirectUri();

  const setClientId = (id: string) => {
    persistSpotifyClientId(id);
    setClientIdState(id);
  };

  // Safe Token Acquisition (handles refresh automatically)
  const getValidAccessToken = useCallback(async (): Promise<string | null> => {
    const currentTokens = tokens || getStoredTokens();
    if (!currentTokens) return null;

    if (!isTokenExpired(currentTokens)) {
      return currentTokens.accessToken;
    }

    if (!currentTokens.refreshToken) {
      setRealStatus('auth_required');
      setErrorMessage('Spotify session expired. Please re-authenticate.');
      return null;
    }

    try {
      setIsLoading(true);
      const refreshed = await refreshAccessToken(currentTokens.refreshToken, clientId);
      setTokens(refreshed);
      return refreshed.accessToken;
    } catch (err: any) {
      console.warn('Failed to refresh Spotify access token:', err);
      setRealStatus('auth_required');
      setErrorMessage(err.message || 'Spotify session expired.');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [tokens, clientId]);

  // Load User Data & Playlists
  const syncSpotifyData = useCallback(async () => {
    if (!isNetworkAvailable()) {
      setRealStatus('network_unavailable');
      setErrorMessage('Network connection offline. Local fitness data is ready.');
      return;
    }

    const token = await getValidAccessToken();
    if (!token) {
      if (!tokens) setRealStatus('disconnected');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      // 1. Fetch User Profile
      const profile = await fetchUserProfile(token);
      setUser(profile);
      saveStoredUserProfile(profile);

      // 2. Fetch User Playlists
      const userPlaylists = await fetchUserPlaylists(token);
      setPlaylists(userPlaylists);
      setRealStatus('connected');
    } catch (err: any) {
      if (err instanceof SpotifyApiError) {
        setRealStatus(err.code);
        setErrorMessage(err.message);
      } else {
        setRealStatus('spotify_unavailable');
        setErrorMessage(err.message || 'Unable to communicate with Spotify services.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [getValidAccessToken, tokens]);

  // Handle Online / Offline network changes
  useEffect(() => {
    const handleOnline = () => {
      const stored = getStoredTokens();
      if (stored) {
        syncSpotifyData();
      } else {
        setRealStatus('disconnected');
      }
    };

    const handleOffline = () => {
      setRealStatus('network_unavailable');
      setErrorMessage('Network connection lost. Offline logbook mode active.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [syncSpotifyData]);

  // Initial token verification on mount
  useEffect(() => {
    if (getStoredTokens()) {
      syncSpotifyData();
    }
  }, [syncSpotifyData]);

  // Listen for postMessage from OAuth popup if used
  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      if (event.data?.type === 'ONSE_SPOTIFY_AUTH_SUCCESS') {
        const stored = getStoredTokens();
        if (stored) {
          setTokens(stored);
          await syncSpotifyData();
        }
      } else if (event.data?.type === 'ONSE_SPOTIFY_AUTH_ERROR') {
        setRealStatus(event.data.code || 'auth_failed');
        setErrorMessage(event.data.message || 'Spotify authorization failed.');
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [syncSpotifyData]);

  // Connect Action
  const connect = async (customClientId?: string) => {
    const targetClientId = customClientId || clientId;
    if (!targetClientId || targetClientId.trim() === '') {
      setRealStatus('auth_failed');
      setErrorMessage('Please provide a valid Spotify Client ID.');
      return;
    }

    if (!isNetworkAvailable()) {
      setRealStatus('network_unavailable');
      setErrorMessage('Network connection unavailable. Cannot initiate Spotify connection.');
      return;
    }

    setRealStatus('connecting');
    setErrorMessage(null);

    try {
      const { url } = await createAuthorizationUrl(targetClientId);

      // Try opening in popup window for desktop/tablet
      const width = 500;
      const height = 700;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;
      
      const popup = window.open(
        url,
        'spotify_oauth_popup',
        `width=${width},height=${height},left=${left},top=${top},scrollbars=yes`
      );

      if (!popup || popup.closed || typeof popup.closed === 'undefined') {
        // Fallback: Redirect directly in same window if popup was blocked
        window.location.href = url;
      }
    } catch (err: any) {
      setRealStatus('auth_failed');
      setErrorMessage(err.message || 'Failed to initialize Spotify authorization flow.');
    }
  };

  // Disconnect Action
  const disconnect = async () => {
    clearTokens();
    setTokens(null);
    setUser(null);
    setTestStatus(null);
    setRealStatus('disconnected');
    setErrorMessage(null);
  };

  // Refresh Playlists Action
  const refreshPlaylists = async () => {
    await syncSpotifyData();
  };

  // Open Playlist in Spotify App / Web
  const openPlaylist = (uriOrUrl: string) => {
    if (!uriOrUrl) return;

    // Check if on mobile or supports custom URI schemes
    if (uriOrUrl.startsWith('spotify:')) {
      // Attempt deep-linking to native Spotify app
      const fallbackUrl = `https://open.spotify.com/playlist/${uriOrUrl.replace('spotify:playlist:', '')}`;
      
      // Open window
      const win = window.open(uriOrUrl, '_blank');
      // If native protocol fails or doesn't navigate, fallback
      setTimeout(() => {
        if (!win || win.closed) {
          window.open(fallbackUrl, '_blank');
        }
      }, 500);
    } else {
      window.open(uriOrUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // Playlist Associations with SQLite / Dexie
  const associatePlaylistWithWorkout = async (
    workoutId: string, 
    playlist: { id: string; name: string; uri: string }
  ) => {
    // 1. Update Workout entity directly in SQLite/Dexie
    await workoutsRepo.update(workoutId, {
      spotifyPlaylistId: playlist.id,
      spotifyPlaylistName: playlist.name,
      spotifyPlaylistUri: playlist.uri
    });

    // 2. Persist in spotifyAssociations table for relational indexing
    const associationId = `workout_${workoutId}`;
    await spotifyAssociationsRepo.create({
      id: associationId,
      type: 'workout',
      targetId: workoutId,
      playlistId: playlist.id,
      playlistName: playlist.name,
      playlistUri: playlist.uri,
      updatedAt: new Date().toISOString()
    }).catch(async () => {
      // If already exists, update
      await spotifyAssociationsRepo.update(associationId, {
        playlistId: playlist.id,
        playlistName: playlist.name,
        playlistUri: playlist.uri,
        updatedAt: new Date().toISOString()
      });
    });
  };

  const removeWorkoutPlaylist = async (workoutId: string) => {
    await workoutsRepo.update(workoutId, {
      spotifyPlaylistId: undefined,
      spotifyPlaylistName: undefined,
      spotifyPlaylistUri: undefined
    });
    await spotifyAssociationsRepo.delete(`workout_${workoutId}`).catch(() => {});
  };

  const associatePlaylistWithProgram = async (
    programId: string, 
    playlist: { id: string; name: string; uri: string }
  ) => {
    await programsRepo.update(programId, {
      spotifyPlaylistId: playlist.id,
      spotifyPlaylistName: playlist.name,
      spotifyPlaylistUri: playlist.uri
    });

    const associationId = `program_${programId}`;
    await spotifyAssociationsRepo.create({
      id: associationId,
      type: 'program',
      targetId: programId,
      playlistId: playlist.id,
      playlistName: playlist.name,
      playlistUri: playlist.uri,
      updatedAt: new Date().toISOString()
    }).catch(async () => {
      await spotifyAssociationsRepo.update(associationId, {
        playlistId: playlist.id,
        playlistName: playlist.name,
        playlistUri: playlist.uri,
        updatedAt: new Date().toISOString()
      });
    });
  };

  const removeProgramPlaylist = async (programId: string) => {
    await programsRepo.update(programId, {
      spotifyPlaylistId: undefined,
      spotifyPlaylistName: undefined,
      spotifyPlaylistUri: undefined
    });
    await spotifyAssociationsRepo.delete(`program_${programId}`).catch(() => {});
  };

  const associatePlaylistWithDay = async (
    dateStr: string, 
    playlist: { id: string; name: string; uri: string }
  ) => {
    const associationId = `day_${dateStr}`;
    await spotifyAssociationsRepo.create({
      id: associationId,
      type: 'day',
      targetId: dateStr,
      playlistId: playlist.id,
      playlistName: playlist.name,
      playlistUri: playlist.uri,
      updatedAt: new Date().toISOString()
    }).catch(async () => {
      await spotifyAssociationsRepo.update(associationId, {
        playlistId: playlist.id,
        playlistName: playlist.name,
        playlistUri: playlist.uri,
        updatedAt: new Date().toISOString()
      });
    });
  };

  const removeDayPlaylist = async (dateStr: string) => {
    await spotifyAssociationsRepo.delete(`day_${dateStr}`).catch(() => {});
  };

  const value: SpotifyContextType = {
    status: activeStatus,
    user,
    playlists,
    isLoading,
    errorMessage,
    clientId,
    setClientId,
    redirectUri,
    connect,
    disconnect,
    refreshPlaylists,
    openPlaylist,
    setManualTestStatus: setTestStatus,
    isTestMode: testStatus !== null,
    associatePlaylistWithWorkout,
    removeWorkoutPlaylist,
    associatePlaylistWithProgram,
    removeProgramPlaylist,
    associatePlaylistWithDay,
    removeDayPlaylist
  };

  return (
    <SpotifyContext.Provider value={value}>
      {children}
    </SpotifyContext.Provider>
  );
}

export function useSpotify() {
  const context = useContext(SpotifyContext);
  if (!context) {
    throw new Error('useSpotify must be used within a SpotifyProvider');
  }
  return context;
}
