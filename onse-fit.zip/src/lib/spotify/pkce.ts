/**
 * ONSE FIT
 * Spotify PKCE (Proof Key for Code Exchange) Cryptographic Utilities
 * RFC 7636 compliant for client-side OAuth security without secrets.
 */

// Generate random string for code_verifier and state
export function generateRandomString(length: number): string {
  const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
  const values = crypto.getRandomValues(new Uint8Array(length));
  return Array.from(values).reduce((acc, x) => acc + possible[x % possible.length], '');
}

// Generate code verifier (between 43 and 128 characters)
export function generateCodeVerifier(length = 64): string {
  return generateRandomString(length);
}

// Generate S256 code challenge from verifier using Web Crypto API
export async function generateCodeChallenge(codeVerifier: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(codeVerifier);
  const digest = await crypto.subtle.digest('SHA-256', data);

  // Convert buffer to base64url string
  return btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}
