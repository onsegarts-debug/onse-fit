import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { OnsenseiMessage } from '../../types';
import { 
  getConversationMessages, 
  saveMessage, 
  updateMessage, 
  clearConversationHistory,
  DEFAULT_CONVERSATION_ID 
} from './historyRepo';
import { getControlledFitnessContext, type FitnessContextSummary } from './contextEngine';
import { routePromptContext, type ContextRoutingDecision } from './contextRouter';
import { providerRegistry, type ProviderStatus, type OnsenseiAIProvider } from './providers';

interface OnsenseiContextType {
  isOpen: boolean;
  openOnsensei: () => void;
  closeOnsensei: () => void;
  toggleOnsensei: () => void;
  messages: OnsenseiMessage[];
  isLoading: boolean;
  providerStatus: ProviderStatus;
  contextSummary: FitnessContextSummary | null;
  lastRouting: ContextRoutingDecision | null;
  sendMessage: (text: string) => Promise<void>;
  retryMessage: (messageId: string) => Promise<void>;
  clearHistory: () => Promise<void>;
  refreshStatus: () => Promise<void>;
}

const OnsenseiContext = createContext<OnsenseiContextType | undefined>(undefined);

export function OnsenseiProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<OnsenseiMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [contextSummary, setContextSummary] = useState<FitnessContextSummary | null>(null);
  const [lastRouting, setLastRouting] = useState<ContextRoutingDecision | null>(null);
  const [providerStatus, setProviderStatus] = useState<ProviderStatus>({
    code: 'ready',
    isAvailable: true,
    providerName: 'Gemini',
    modelName: 'gemini-3.8-flash',
    message: 'Initializing...',
  });

  const activeProvider: OnsenseiAIProvider = providerRegistry.getActiveProvider();

  // Load message history from Dexie/IndexedDB on mount safely
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const loaded = await getConversationMessages(DEFAULT_CONVERSATION_ID);
        if (isMounted) {
          setMessages(loaded);
        }
      } catch (err) {
        console.warn('[ONSENSEI] Error reading persisted conversation history:', err);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  // Check provider status & online connectivity
  const refreshStatus = useCallback(async () => {
    try {
      const status = await activeProvider.getStatus();
      setProviderStatus(status);
    } catch {
      setProviderStatus({
        code: 'network_error',
        isAvailable: false,
        providerName: 'Gemini',
        modelName: 'gemini-3.8-flash',
        message: 'Could not reach AI provider service',
      });
    }
  }, [activeProvider]);

  // Load fresh fitness context safely
  const refreshContext = useCallback(async () => {
    try {
      const summary = await getControlledFitnessContext();
      setContextSummary(summary);
    } catch (e) {
      console.warn('[ONSENSEI] Failed to assemble ONSE FIT data context:', e);
    }
  }, []);

  useEffect(() => {
    refreshStatus().catch(() => {});
    refreshContext().catch(() => {});

    const handleOnline = () => {
      refreshStatus().catch(() => {});
    };
    const handleOffline = () => {
      setProviderStatus({
        code: 'offline',
        isAvailable: false,
        providerName: 'Gemini',
        modelName: 'gemini-3.8-flash',
        message: 'Device is offline',
        details: 'Internet connection is required for live consultations.',
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [refreshStatus, refreshContext]);

  // Refresh context and status when modal opens
  const openOnsensei = useCallback(() => {
    setIsOpen(true);
    refreshStatus().catch(() => {});
    refreshContext().catch(() => {});
  }, [refreshStatus, refreshContext]);

  const closeOnsensei = useCallback(() => {
    setIsOpen(false);
  }, []);

  const toggleOnsensei = useCallback(() => {
    setIsOpen((prev) => {
      const next = !prev;
      if (next) {
        refreshStatus().catch(() => {});
        refreshContext().catch(() => {});
      }
      return next;
    });
  }, [refreshStatus, refreshContext]);

  // Core send message implementation
  const sendMessage = useCallback(async (rawText: string) => {
    const text = rawText.trim();
    if (!text || isLoading) return;

    // Check if offline
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      const offlineMsgId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const offlineUserMsg: OnsenseiMessage = {
        id: offlineMsgId,
        conversationId: DEFAULT_CONVERSATION_ID,
        role: 'user',
        content: text,
        timestamp: new Date().toISOString(),
        status: 'error',
        error: 'ONSENSEI is offline. Connect to the internet to consult your training advisor.',
      };
      setMessages((prev) => [...prev, offlineUserMsg]);
      try {
        await saveMessage(offlineUserMsg);
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB save failed:', dbErr);
      }
      return;
    }

    const userMsgId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const userMessage: OnsenseiMessage = {
      id: userMsgId,
      conversationId: DEFAULT_CONVERSATION_ID,
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
      status: 'sending',
    };

    // Optimistically append user message
    setMessages((prev) => [...prev, userMessage]);
    try {
      await saveMessage(userMessage);
    } catch (dbErr) {
      console.warn('[ONSENSEI] DB save failed:', dbErr);
    }

    setIsLoading(true);

    try {
      // Determine context routing (General AI vs ONSE FIT targeted context)
      let contextSnippet = '';
      try {
        const routing = await routePromptContext(text, contextSummary);
        setLastRouting(routing);
        if (routing.isFitnessRelevant) {
          contextSnippet = routing.contextSnippet;
        }
      } catch (ctxErr) {
        console.warn('[ONSENSEI] Context routing failed, proceeding with general mode:', ctxErr);
      }

      // Build message payload (include recent valid messages for context continuity)
      const currentHistory = messages.filter((m) => m.status !== 'error').slice(-8);
      const conversationPayload = [
        ...currentHistory.map((m) => ({
          role: m.role as 'user' | 'assistant' | 'system',
          content: m.content,
        })),
        { role: 'user' as const, content: text },
      ];

      const response = await activeProvider.sendMessage({
        messages: conversationPayload,
        context: contextSnippet,
      });

      // Mark user message as sent
      try {
        await updateMessage(userMsgId, { status: 'sent' });
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB update failed:', dbErr);
      }
      setMessages((prev) =>
        prev.map((m) => (m.id === userMsgId ? { ...m, status: 'sent' } : m))
      );

      // Create assistant message
      const assistantMsgId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const assistantMessage: OnsenseiMessage = {
        id: assistantMsgId,
        conversationId: DEFAULT_CONVERSATION_ID,
        role: 'assistant',
        content: response.content,
        timestamp: new Date().toISOString(),
        status: 'sent',
        provider: response.provider,
        model: response.model,
      };

      setMessages((prev) => [...prev, assistantMessage]);
      try {
        await saveMessage(assistantMessage);
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB save failed:', dbErr);
      }
    } catch (err: any) {
      console.error('[ONSENSEI] Send message failed safely:', err);
      const errorMsg = err?.message || 'Failed to consult ONSENSEI. Tap retry to attempt again.';
      try {
        await updateMessage(userMsgId, { status: 'error', error: errorMsg });
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB update failed:', dbErr);
      }
      setMessages((prev) =>
        prev.map((m) => (m.id === userMsgId ? { ...m, status: 'error', error: errorMsg } : m))
      );
    } finally {
      setIsLoading(false);
    }
  }, [activeProvider, messages, isLoading, contextSummary]);

  // Safe retry action for a failed message
  const retryMessage = useCallback(async (messageId: string) => {
    if (isLoading) return;

    const targetMsg = messages.find((m) => m.id === messageId);
    if (!targetMsg) return;

    // Reset its status to sending
    try {
      await updateMessage(messageId, { status: 'sending', error: undefined });
    } catch (dbErr) {
      console.warn('[ONSENSEI] DB update failed:', dbErr);
    }
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, status: 'sending', error: undefined } : m))
    );

    setIsLoading(true);

    try {
      let contextSnippet = '';
      try {
        const routing = await routePromptContext(targetMsg.content, contextSummary);
        setLastRouting(routing);
        if (routing.isFitnessRelevant) {
          contextSnippet = routing.contextSnippet;
        }
      } catch (ctxErr) {
        console.warn('[ONSENSEI] Context routing failed during retry:', ctxErr);
      }

      const precedingHistory = messages
        .filter((m) => m.id !== messageId && m.status !== 'error')
        .slice(-8);

      const conversationPayload = [
        ...precedingHistory.map((m) => ({
          role: m.role as 'user' | 'assistant' | 'system',
          content: m.content,
        })),
        { role: 'user' as const, content: targetMsg.content },
      ];

      const response = await activeProvider.sendMessage({
        messages: conversationPayload,
        context: contextSnippet,
      });

      try {
        await updateMessage(messageId, { status: 'sent', error: undefined });
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB update failed:', dbErr);
      }
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, status: 'sent', error: undefined } : m))
      );

      const assistantMsgId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const assistantMessage: OnsenseiMessage = {
        id: assistantMsgId,
        conversationId: DEFAULT_CONVERSATION_ID,
        role: 'assistant',
        content: response.content,
        timestamp: new Date().toISOString(),
        status: 'sent',
        provider: response.provider,
        model: response.model,
      };

      setMessages((prev) => [...prev, assistantMessage]);
      try {
        await saveMessage(assistantMessage);
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB save failed:', dbErr);
      }
    } catch (err: any) {
      console.error('[ONSENSEI] Retry message failed safely:', err);
      const errorMsg = err?.message || 'Retry failed. Please check connection.';
      try {
        await updateMessage(messageId, { status: 'error', error: errorMsg });
      } catch (dbErr) {
        console.warn('[ONSENSEI] DB update failed:', dbErr);
      }
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, status: 'error', error: errorMsg } : m))
      );
    } finally {
      setIsLoading(false);
    }
  }, [activeProvider, messages, isLoading, contextSummary]);

  const clearHistory = useCallback(async () => {
    try {
      await clearConversationHistory(DEFAULT_CONVERSATION_ID);
    } catch (dbErr) {
      console.warn('[ONSENSEI] Clear history DB failed:', dbErr);
    }
    setMessages([]);
  }, []);

  return (
    <OnsenseiContext.Provider
      value={{
        isOpen,
        openOnsensei,
        closeOnsensei,
        toggleOnsensei,
        messages,
        isLoading,
        providerStatus,
        contextSummary,
        lastRouting,
        sendMessage,
        retryMessage,
        clearHistory,
        refreshStatus,
      }}
    >
      {children}
    </OnsenseiContext.Provider>
  );
}

export function useOnsensei() {
  const ctx = useContext(OnsenseiContext);
  if (!ctx) {
    throw new Error('useOnsensei must be used within an OnsenseiProvider');
  }
  return ctx;
}
