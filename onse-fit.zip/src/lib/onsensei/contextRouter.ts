import { getControlledFitnessContext, type FitnessContextSummary } from './contextEngine';

export type ContextCategory =
  | 'general'
  | 'workout_today'
  | 'recent_workouts'
  | 'personal_records'
  | 'recovery_sleep'
  | 'habits'
  | 'bodyweight'
  | 'planning_overload'
  | 'comprehensive_fitness';

export interface ContextRoutingDecision {
  isFitnessRelevant: boolean;
  category: ContextCategory;
  categoryLabel: string;
  contextSnippet: string;
}

/**
 * Determines whether the user query is asking about their personal ONSE FIT logs
 * or asking a general AI question, and returns only the necessary context slice.
 */
export async function routePromptContext(
  userPrompt: string,
  summaryOverride?: FitnessContextSummary | null
): Promise<ContextRoutingDecision> {
  const text = userPrompt.toLowerCase().trim();

  // Pattern detection for personal logbook intent
  const todayPatterns = [
    'today', 'todays', 'today\'s', 'current workout', 'this workout',
    'what did i lift today', 'workout today', 'my workout', 'session today'
  ];

  const recentHistoryPatterns = [
    'recent', 'last week', 'yesterday', 'past workout', 'previous workout',
    'past session', 'history', 'consistency', 'streak', 'how consistent',
    'training frequency', 'volume trend'
  ];

  const prPatterns = [
    'pr', 'prs', 'personal record', 'personal records', 'max', '1rm',
    'heaviest', 'best lift', 'bench pr', 'squat pr', 'deadlift pr', 'pr on'
  ];

  const recoveryPatterns = [
    'sleep', 'recovery', 'sore', 'soreness', 'fatigue', 'tired', 'rest',
    'readiness', 'energy', 'stress', 'how recovered'
  ];

  const habitPatterns = [
    'habit', 'habits', 'daily habit', 'water intake', 'hydration', 'check-in'
  ];

  const bodyweightPatterns = [
    'body weight', 'bodyweight', 'weigh in', 'scale weight', 'weighed', 'weight trend'
  ];

  const planningPatterns = [
    'what should i focus on', 'next workout', 'plan my workout', 'next session',
    'progressive overload', 'what should i do next', 'tomorrow workout', 'suggest weights'
  ];

  const broadFitnessPatterns = [
    'onse fit', 'onsefit', 'my logs', 'my data', 'my stats', 'my routine',
    'my program', 'logbook', 'my training', 'analyze my fitness', 'my exercise'
  ];

  // Helper matcher
  const matchesAny = (patterns: string[]) => patterns.some(p => text.includes(p));

  // Determine category
  let category: ContextCategory = 'general';
  let categoryLabel = 'General AI Intelligence';

  if (matchesAny(prPatterns)) {
    category = 'personal_records';
    categoryLabel = 'Personal Records';
  } else if (matchesAny(todayPatterns)) {
    category = 'workout_today';
    categoryLabel = "Today's Workout";
  } else if (matchesAny(planningPatterns)) {
    category = 'planning_overload';
    categoryLabel = 'Session Planning & Overload';
  } else if (matchesAny(recentHistoryPatterns)) {
    category = 'recent_workouts';
    categoryLabel = 'Recent Workout History';
  } else if (matchesAny(recoveryPatterns)) {
    category = 'recovery_sleep';
    categoryLabel = 'Sleep & Recovery';
  } else if (matchesAny(habitPatterns)) {
    category = 'habits';
    categoryLabel = 'Active Habits';
  } else if (matchesAny(bodyweightPatterns)) {
    category = 'bodyweight';
    categoryLabel = 'Bodyweight Trend';
  } else if (matchesAny(broadFitnessPatterns)) {
    category = 'comprehensive_fitness';
    categoryLabel = 'ONSE FIT Logbook';
  }

  // If general, don't fetch or attach any database context
  if (category === 'general') {
    return {
      isFitnessRelevant: false,
      category: 'general',
      categoryLabel,
      contextSnippet: '',
    };
  }

  // Fetch summary if not passed
  const summary = summaryOverride || await getControlledFitnessContext().catch(() => null);
  if (!summary) {
    return {
      isFitnessRelevant: true,
      category,
      categoryLabel,
      contextSnippet: '[No local fitness data logged in ONSE FIT database yet.]',
    };
  }

  const athleteHeader = `[ATHLETE PROFILE]
Name: ${summary.profileName}
Goal: ${summary.trainingGoal}
Active Streak: ${summary.trainingStreak} days
Active Program: ${summary.activeProgramName || 'None'}
Date: ${summary.currentDate} (${summary.dayOfWeek})`;

  let contextSnippet = '';

  switch (category) {
    case 'workout_today':
      contextSnippet = `${athleteHeader}\n\n[TODAY'S WORKOUT]\n${summary.todayWorkoutSummary}`;
      break;

    case 'personal_records':
      contextSnippet = `${athleteHeader}\n\n[PERSONAL RECORDS / KEY LIFTS]\n${summary.personalRecordsSummary}`;
      break;

    case 'recent_workouts':
      contextSnippet = `${athleteHeader}\n\n[RECENT SESSIONS]\n${summary.recentWorkoutsSummary}`;
      break;

    case 'recovery_sleep':
      contextSnippet = `${athleteHeader}\n\n[SLEEP & RECOVERY STATUS]\n${summary.sleepAndRecoverySummary}`;
      break;

    case 'habits':
      contextSnippet = `${athleteHeader}\n\n[HABITS TRACKER TODAY]\n${summary.habitsSummary}`;
      break;

    case 'bodyweight':
      contextSnippet = `${athleteHeader}\n\n[BODY WEIGHT TREND]\n${summary.latestBodyWeightSummary}`;
      break;

    case 'planning_overload':
      contextSnippet = `${athleteHeader}\n\n[TODAY'S WORKOUT]\n${summary.todayWorkoutSummary}\n\n[RECENT SESSIONS]\n${summary.recentWorkoutsSummary}\n\n[KEY PERSONAL RECORDS]\n${summary.personalRecordsSummary}`;
      break;

    case 'comprehensive_fitness':
    default:
      contextSnippet = summary.fullPromptContext;
      break;
  }

  return {
    isFitnessRelevant: true,
    category,
    categoryLabel,
    contextSnippet: contextSnippet.trim(),
  };
}
