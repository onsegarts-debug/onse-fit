import type { OnsenseiAIProvider } from './types';
import { ServerGeminiProvider } from './ServerGeminiProvider';

class OnsenseiProviderRegistry {
  private providers: Map<string, OnsenseiAIProvider> = new Map();
  private activeProviderId: string;

  constructor() {
    const defaultProvider = new ServerGeminiProvider();
    this.registerProvider(defaultProvider);
    this.activeProviderId = defaultProvider.id;
  }

  registerProvider(provider: OnsenseiAIProvider) {
    this.providers.set(provider.id, provider);
  }

  setActiveProvider(id: string) {
    if (!this.providers.has(id)) {
      throw new Error(`Provider "${id}" is not registered.`);
    }
    this.activeProviderId = id;
  }

  getActiveProvider(): OnsenseiAIProvider {
    const provider = this.providers.get(this.activeProviderId);
    if (!provider) {
      // Fallback
      return new ServerGeminiProvider();
    }
    return provider;
  }

  getAllProviders(): OnsenseiAIProvider[] {
    return Array.from(this.providers.values());
  }
}

export const providerRegistry = new OnsenseiProviderRegistry();
export * from './types';
export * from './ServerGeminiProvider';
