export type ProviderStatusCode = 
  | 'ready'
  | 'unconfigured'
  | 'offline'
  | 'network_error'
  | 'auth_error'
  | 'provider_error'
  | 'rate_limited';

export interface ProviderStatus {
  code: ProviderStatusCode;
  isAvailable: boolean;
  providerName: string;
  modelName: string;
  message?: string;
  details?: string;
}

export interface ChatMessagePayload {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface AIProviderRequest {
  messages: ChatMessagePayload[];
  context?: string;
}

export interface AIProviderResponse {
  content: string;
  provider: string;
  model: string;
}

export interface OnsenseiAIProvider {
  readonly id: string;
  readonly name: string;
  getStatus(): Promise<ProviderStatus>;
  sendMessage(req: AIProviderRequest): Promise<AIProviderResponse>;
}
