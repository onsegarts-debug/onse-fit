import type { 
  OnsenseiAIProvider, 
  ProviderStatus, 
  AIProviderRequest, 
  AIProviderResponse 
} from './types';

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export class ServerGeminiProvider implements OnsenseiAIProvider {
  readonly id = 'server-gemini';
  readonly name = 'Gemini 3.8 Flash (Server Proxy)';

  async getStatus(): Promise<ProviderStatus> {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return {
        code: 'offline',
        isAvailable: false,
        providerName: 'Gemini',
        modelName: 'gemini-3.8-flash',
        message: 'Device is offline',
        details: 'Internet connection is required for live consultations.',
      };
    }

    try {
      const res = await fetch('/api/onsensei/status', {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
      });

      if (!res.ok) {
        return {
          code: 'provider_error',
          isAvailable: false,
          providerName: 'Gemini',
          modelName: 'gemini-3.8-flash',
          message: `Server returned HTTP ${res.status}`,
        };
      }

      const data = await res.json().catch(() => ({}));
      if (!data.configured) {
        return {
          code: 'unconfigured',
          isAvailable: false,
          providerName: data.provider || 'Gemini',
          modelName: data.model || 'gemini-3.8-flash',
          message: 'Provider API key is not set',
          details: 'GEMINI_API_KEY is not configured in the server environment.',
        };
      }

      return {
        code: 'ready',
        isAvailable: true,
        providerName: data.provider || 'Gemini',
        modelName: data.model || 'gemini-3.8-flash',
        message: 'Connected & Ready',
      };
    } catch (err: any) {
      return {
        code: 'network_error',
        isAvailable: false,
        providerName: 'Gemini',
        modelName: 'gemini-3.8-flash',
        message: 'Could not reach server proxy',
        details: err?.message || 'Network error',
      };
    }
  }

  async sendMessage(req: AIProviderRequest): Promise<AIProviderResponse> {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      throw new Error('Device is offline. Connect to the internet to consult ONSENSEI.');
    }

    const maxClientAttempts = 2; // Initial attempt + 1 safe retry with backoff
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= maxClientAttempts; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 25000); // 25s timeout

        const response = await fetch('/api/onsensei/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: JSON.stringify({
            messages: req.messages,
            context: req.context,
          }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
          const status = response.status;
          const serverErrorMsg = data?.error;

          if (status === 503) {
            const err = new Error(
              serverErrorMsg || 'ONSENSEI is currently experiencing high demand. Please try again in a few moments.'
            );
            (err as any).code = 'HIGH_DEMAND';
            (err as any).status = 503;
            lastError = err;

            // Safe client-side retry for 503 if attempts remain
            if (attempt < maxClientAttempts) {
              await sleep(1500);
              continue;
            }
            throw err;
          }

          if (status === 429) {
            const err = new Error(
              serverErrorMsg || 'Rate limit reached. Please wait a moment before trying again.'
            );
            (err as any).code = 'RATE_LIMIT';
            (err as any).status = 429;
            throw err;
          }

          if (status === 401 || status === 403) {
            const err = new Error(
              serverErrorMsg || 'AI Provider authentication error. Please verify GEMINI_API_KEY in AI Studio Settings.'
            );
            (err as any).code = 'AUTH_ERROR';
            (err as any).status = status;
            throw err;
          }

          if (status === 502) {
            const err = new Error(
              serverErrorMsg || 'Empty response received from AI provider. Please retry your question.'
            );
            (err as any).code = 'EMPTY_RESPONSE';
            (err as any).status = 502;
            throw err;
          }

          const fallbackMsg = serverErrorMsg || `Server error (HTTP ${status}). Tap retry to attempt again.`;
          const err = new Error(fallbackMsg);
          (err as any).code = data?.code || 'PROVIDER_ERROR';
          (err as any).status = status;
          throw err;
        }

        const content = data?.content?.trim();
        if (!content) {
          const err = new Error('Empty response received from AI provider. Please retry your question.');
          (err as any).code = 'EMPTY_RESPONSE';
          throw err;
        }

        return {
          content,
          provider: data.provider || 'Gemini',
          model: data.model || 'gemini-3.8-flash',
        };
      } catch (err: any) {
        lastError = err;

        // If it was an abort/timeout
        if (err.name === 'AbortError') {
          const timeoutErr = new Error('Request timed out. ONSENSEI took too long to respond.');
          (timeoutErr as any).code = 'TIMEOUT';
          lastError = timeoutErr;
          if (attempt < maxClientAttempts) {
            await sleep(1000);
            continue;
          }
          throw timeoutErr;
        }

        // If it was a network drop/fetch error
        if (err.message && err.message.includes('fetch')) {
          const netErr = new Error('Network failure: Unable to reach ONSENSEI server proxy.');
          (netErr as any).code = 'NETWORK_ERROR';
          lastError = netErr;
          if (attempt < maxClientAttempts) {
            await sleep(1200);
            continue;
          }
          throw netErr;
        }

        // If it's already an evaluated Error with code
        if (err.code && err.code !== 'HIGH_DEMAND') {
          throw err;
        }

        if (attempt >= maxClientAttempts) {
          throw err;
        }
        await sleep(1500);
      }
    }

    throw lastError || new Error('An unexpected error occurred while consulting ONSENSEI.');
  }
}
