import { db } from '../../db';
import type { OnsenseiMessage } from '../../types';

export const DEFAULT_CONVERSATION_ID = 'onsensei_main_session';

export async function getConversationMessages(conversationId = DEFAULT_CONVERSATION_ID): Promise<OnsenseiMessage[]> {
  try {
    const messages = await db.onsenseiMessages
      .where('conversationId')
      .equals(conversationId)
      .sortBy('timestamp');
    return messages;
  } catch (error) {
    console.error('Failed to load ONSENSEI history from local database:', error);
    return [];
  }
}

export async function saveMessage(message: OnsenseiMessage): Promise<void> {
  try {
    await db.onsenseiMessages.put(message);
  } catch (error) {
    console.error('Failed to save ONSENSEI message to local database:', error);
  }
}

export async function updateMessage(id: string, updates: Partial<OnsenseiMessage>): Promise<void> {
  try {
    await db.onsenseiMessages.update(id, updates);
  } catch (error) {
    console.error('Failed to update ONSENSEI message:', error);
  }
}

export async function deleteMessage(id: string): Promise<void> {
  try {
    await db.onsenseiMessages.delete(id);
  } catch (error) {
    console.error('Failed to delete ONSENSEI message:', error);
  }
}

export async function clearConversationHistory(conversationId = DEFAULT_CONVERSATION_ID): Promise<void> {
  try {
    const messages = await db.onsenseiMessages
      .where('conversationId')
      .equals(conversationId)
      .toArray();
    const ids = messages.map(m => m.id);
    await db.onsenseiMessages.bulkDelete(ids);
  } catch (error) {
    console.error('Failed to clear ONSENSEI conversation history:', error);
  }
}
