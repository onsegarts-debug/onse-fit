import { db } from '../../db';

export interface FitnessContextSummary {
  profileName: string;
  trainingGoal: string;
  trainingStreak: number;
  activeProgramName?: string;
  currentDate: string;
  dayOfWeek: string;
  todayWorkoutSummary: string;
  recentWorkoutsSummary: string;
  personalRecordsSummary: string;
  latestBodyWeightSummary: string;
  sleepAndRecoverySummary: string;
  habitsSummary: string;
  fullPromptContext: string;
}

export async function getControlledFitnessContext(): Promise<FitnessContextSummary> {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const dayOfWeek = days[now.getDay()];

  // 1. Profile
  const profile = await db.profiles.toCollection().first();
  const profileName = profile?.name || 'Athlete';
  const trainingGoal = profile?.goal || 'General Strength & Discipline';
  const trainingStreak = profile?.trainingStreak ?? 0;

  // Active Program
  let activeProgramName = 'None';
  if (profile?.currentProgramId) {
    const prog = await db.programs.get(profile.currentProgramId);
    if (prog) activeProgramName = prog.name;
  }

  // 2. Today's Workout
  const todayWorkouts = await db.workouts.where('date').equals(todayStr).toArray();
  let todayWorkoutSummary = 'No workout scheduled or logged for today.';

  if (todayWorkouts.length > 0) {
    const lines: string[] = [];
    for (const w of todayWorkouts) {
      lines.push(`Workout: "${w.name}" [Status: ${w.completed ? 'COMPLETED' : 'IN PROGRESS / PENDING'}]`);
      if (w.notes) lines.push(`  Notes: ${w.notes}`);

      const workoutExercises = await db.workoutExercises
        .where('workoutId')
        .equals(w.id)
        .sortBy('order');

      for (const we of workoutExercises) {
        const exercise = await db.exercises.get(we.exerciseId);
        const exName = exercise?.name || 'Exercise';
        const sets = await db.sets
          .where('workoutExerciseId')
          .equals(we.id)
          .sortBy('order');

        const completedSets = sets.filter(s => s.completed);
        const setDetails = completedSets.map((s, idx) => 
          `Set ${idx + 1}: ${s.weight}kg x ${s.reps} reps${s.rpe ? ` @ RPE ${s.rpe}` : ''}`
        ).join(', ');

        lines.push(`  - ${exName}: ${completedSets.length}/${sets.length} sets completed${setDetails ? ` (${setDetails})` : ''}`);
      }
    }
    todayWorkoutSummary = lines.join('\n');
  }

  // 3. Recent Workouts (Past 3-5 sessions)
  const recentWorkouts = await db.workouts
    .where('date')
    .below(todayStr)
    .reverse()
    .sortBy('date');
  const pastWorkoutsSlice = recentWorkouts.slice(0, 3);
  let recentWorkoutsSummary = 'No previous workouts recorded in logbook.';
  if (pastWorkoutsSlice.length > 0) {
    recentWorkoutsSummary = pastWorkoutsSlice
      .map(w => `• ${w.date}: "${w.name}" (${w.completed ? 'Completed' : 'Partial'})`)
      .join('\n');
  }

  // 4. Personal Records
  const prs = await db.personalRecords.toArray();
  let personalRecordsSummary = 'No personal records logged yet.';
  if (prs.length > 0) {
    const prLines: string[] = [];
    // Grab latest 5 PRs
    const sortedPrs = prs.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
    for (const pr of sortedPrs) {
      const ex = await db.exercises.get(pr.exerciseId);
      const exName = ex?.name || 'Lift';
      prLines.push(`• ${exName}: ${pr.value}kg${pr.reps ? ` for ${pr.reps} reps` : ''} (${pr.type}) on ${pr.date}`);
    }
    personalRecordsSummary = prLines.join('\n');
  }

  // 5. Body Weight
  const bodyWeights = await db.bodyWeights.orderBy('date').reverse().limit(3).toArray();
  let latestBodyWeightSummary = 'No body weight entries recorded.';
  if (bodyWeights.length > 0) {
    latestBodyWeightSummary = bodyWeights
      .map(bw => `• ${bw.date}: ${bw.weight} kg${bw.notes ? ` (${bw.notes})` : ''}`)
      .join('\n');
  }

  // 6. Sleep & Recovery (Today or Yesterday)
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const recentSleep = await db.sleepEntries
    .where('date')
    .anyOf([todayStr, yesterday])
    .reverse()
    .sortBy('date');
  
  const recentRecovery = await db.recoveryEntries
    .where('date')
    .anyOf([todayStr, yesterday])
    .reverse()
    .sortBy('date');

  const sleepParts: string[] = [];
  if (recentSleep.length > 0) {
    const s = recentSleep[0];
    sleepParts.push(`Sleep (${s.date}): ${s.durationMinutes ? `${Math.round(s.durationMinutes / 60 * 10) / 10} hrs` : 'Logged'}, Quality: ${s.quality || 'N/A'}/5`);
  } else {
    sleepParts.push('No recent sleep logged.');
  }

  if (recentRecovery.length > 0) {
    const r = recentRecovery[0];
    sleepParts.push(`Recovery (${r.date}): Overall rating: ${r.rating}/5, Soreness: ${r.soreness}/5, Energy: ${r.energy}/5, Stress: ${r.stress}/5`);
  } else {
    sleepParts.push('No recovery check-in logged for today/yesterday.');
  }
  const sleepAndRecoverySummary = sleepParts.join('\n');

  // 7. Habits
  const habits = await db.habits.toArray();
  let habitsSummary = 'No active habits tracked.';
  if (habits.length > 0) {
    const habitLogs = await db.habitLogs.where('date').equals(todayStr).toArray();
    const completedSet = new Set(habitLogs.filter(l => l.completed).map(l => l.habitId));
    habitsSummary = habits
      .map(h => `• ${h.name}: ${completedSet.has(h.id) ? 'DONE [✓]' : 'PENDING'}`)
      .join('\n');
  }

  // Combined context string designed for system prompt ingestion
  const fullPromptContext = `
[ONSE FIT LOGBOOK CONTEXT - SINGLE SOURCE OF TRUTH]
Current Date: ${todayStr} (${dayOfWeek})
Athlete Name: ${profileName}
Training Goal: ${trainingGoal}
Active Streak: ${trainingStreak} days
Active Program: ${activeProgramName}

[TODAY'S WORKOUT]
${todayWorkoutSummary}

[RECENT SESSIONS]
${recentWorkoutsSummary}

[PERSONAL RECORDS / KEY LIFTS]
${personalRecordsSummary}

[BODY WEIGHT TREND]
${latestBodyWeightSummary}

[SLEEP & RECOVERY STATUS]
${sleepAndRecoverySummary}

[HABITS TRACKER TODAY]
${habitsSummary}
`.trim();

  return {
    profileName,
    trainingGoal,
    trainingStreak,
    activeProgramName,
    currentDate: todayStr,
    dayOfWeek,
    todayWorkoutSummary,
    recentWorkoutsSummary,
    personalRecordsSummary,
    latestBodyWeightSummary,
    sleepAndRecoverySummary,
    habitsSummary,
    fullPromptContext,
  };
}
