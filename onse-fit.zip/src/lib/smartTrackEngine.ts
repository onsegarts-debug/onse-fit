import type { 
  Workout, WorkoutExercise, Set, Exercise, SleepEntry, 
  RecoveryEntry, Habit, HabitLog, BodyWeight, Profile 
} from '../types';
import { calculateEstimated1RM, calculateSetVolume } from './analytics';

/**
 * ONSE FIT — SMART TRACK ENGINE
 * 
 * Purely deterministic, local intelligence engine.
 * Synthesizes all stored database tables into structured summaries and factual insights.
 * 
 * Strict Constraint:
 * - Zero artificial/simulated generative filler.
 * - Zero empty cheerleading or motivational boilerplate.
 * - Every observation is anchored in exact numerical records.
 */

// ==========================================
// DATA INTERFACES
// ==========================================

export interface DailySummaryData {
  date: string;
  isToday: boolean;
  hasData: boolean;
  workouts: Array<{
    id: string;
    name: string;
    completed: boolean;
    durationMinutes: number;
    totalVolumeKg: number;
    totalSets: number;
    totalReps: number;
    exercises: Array<{
      exerciseName: string;
      category: string;
      setsCount: number;
      bestSet: { weight: number; reps: number; e1RM: number };
      volumeKg: number;
    }>;
  }>;
  totalDailyVolumeKg: number;
  totalDailySets: number;
  totalDailyReps: number;
  sleep: {
    durationHours: number;
    quality?: number;
    hasEntry: boolean;
  } | null;
  recovery: {
    soreness: number; // 1-5
    energy: number;   // 1-5
    stress?: number;  // 1-5
    rating?: number;  // 1-5
    hasEntry: boolean;
  } | null;
  readinessScore: number | null; // 0-100 deterministic index
  habits: {
    totalHabits: number;
    completedCount: number;
    completionRate: number; // 0-100%
    items: Array<{ habitId: string; name: string; completed: boolean }>;
  };
  bodyWeight: number | null;
  prEventsToday: DetectedSmartPR[];
  factualBullets: string[];
}

export interface WeeklySummaryData {
  weekKey: string;
  startDate: string;
  endDate: string;
  isCurrentWeek: boolean;
  hasData: boolean;
  workoutsCompleted: number;
  workoutsPlanned: number;
  adherencePercentage: number;
  totalVolumeKg: number;
  previousWeekVolumeKg: number | null;
  volumeChangeKg: number | null;
  volumeChangePercent: number | null;
  totalSets: number;
  totalReps: number;
  averageSessionDurationMinutes: number;
  muscleAllocation: Array<{ category: string; volumeKg: number; percentage: number; setCount: number }>;
  sleepAverages: {
    averageHoursPerNight: number;
    loggedNights: number;
    adherenceTo7Hours: number;
  } | null;
  recoveryAverages: {
    averageSoreness: number;
    averageEnergy: number;
    averageReadiness: number;
  } | null;
  activeDaysCount: number;
  restDaysCount: number;
  factualBullets: string[];
}

export interface TrainingConsistencyData {
  currentDayStreak: number;
  currentWeekStreak: number;
  daysSinceLastWorkout: number | null;
  frequencyLast4Weeks: number;
  frequencyLast8Weeks: number;
  targetFrequency: number;
  adherenceLast4WeeksPercent: number;
  dayOfWeekDistribution: Array<{ dayName: string; dayIndex: number; count: number; percentage: number }>;
  averageRestIntervalDays: number;
  maxRestIntervalDays: number;
  totalHistoricalWorkouts: number;
  consistencyScore: number; // 0-100 index
  factualBullets: string[];
}

export interface VolumeChangeData {
  weeklyProgressions: Array<{
    weekLabel: string;
    startDate: string;
    endDate: string;
    volumeKg: number;
    workoutsCount: number;
    wowDeltaKg: number | null;
    wowDeltaPercent: number | null;
  }>;
  monthOverMonth: {
    currentMonthVolumeKg: number;
    previousMonthVolumeKg: number;
    momDeltaKg: number;
    momDeltaPercent: number;
    currentMonthName: string;
    previousMonthName: string;
  } | null;
  muscleGroupDeltas: Array<{
    category: string;
    recentVolumeKg: number;
    priorVolumeKg: number;
    deltaKg: number;
    deltaPercent: number;
  }>;
  overloadStatus: 'increasing' | 'maintaining' | 'deloading' | 'insufficient_data';
  overloadPercentChange: number;
  factualBullets: string[];
}

export interface DetectedSmartPR {
  id: string;
  exerciseId: string;
  exerciseName: string;
  category: string;
  date: string;
  workoutId: string;
  workoutName: string;
  metricType: 'weight' | 'estimated1RM' | 'volume';
  newValue: number;
  previousValue: number;
  delta: number;
  percentGain: number;
  reps: number;
  weight: number;
}

export interface PREventData {
  allPREvents: DetectedSmartPR[];
  totalPRsAllTime: number;
  prsLast7Days: number;
  prsLast30Days: number;
  exercisePRSummary: Array<{
    exerciseName: string;
    totalPRs: number;
    best1RM: number;
    bestWeight: number;
    lastPRDate: string;
  }>;
  factualBullets: string[];
}

export interface MissedWorkoutData {
  uncompletedScheduledWorkouts: Array<{
    id: string;
    name: string;
    scheduledDate: string;
    reason: 'scheduled_past_uncompleted';
  }>;
  weeklyDeficits: Array<{
    weekLabel: string;
    startDate: string;
    endDate: string;
    targetSessions: number;
    completedSessions: number;
    missedSessionsCount: number;
  }>;
  extendedTrainingGaps: Array<{
    startDate: string;
    endDate: string;
    gapDays: number;
    precedingWorkoutName: string;
    followingWorkoutName?: string;
  }>;
  totalMissedSessions: number;
  overallScheduleAdherencePercent: number;
  factualBullets: string[];
}

export interface RecoveryOverviewData {
  sleep7DayAvg: number | null;
  sleep30DayAvg: number | null;
  sleepLoggedCount: number;
  sleepMinHours: number | null;
  sleepMaxHours: number | null;
  soreness7DayAvg: number | null;
  energy7DayAvg: number | null;
  readinessScoreCurrent: number | null;
  restDaysLast7Days: number;
  restDaysLast14Days: number;
  trainingLoadCorrelation: {
    highLoadAvgSoreness: number | null;
    lowLoadAvgSoreness: number | null;
    sorenessDelta: number | null;
    hasCorrelationData: boolean;
  };
  dailyRecoveryPoints: Array<{
    date: string;
    sleepHours: number | null;
    soreness: number | null;
    energy: number | null;
    readinessScore: number | null;
    hadWorkout: boolean;
    workoutVolumeKg: number;
  }>;
  factualBullets: string[];
}

export interface FactualInsightsData {
  categories: {
    volumeOverload: string[];
    scheduleAdherence: string[];
    recoverySleep: string[];
    strengthRecords: string[];
  };
  totalInsightsCount: number;
}

// ==========================================
// DETERMINISTIC UTILITY HELPERS
// ==========================================

export function calculateReadinessIndex(
  sleepHours: number | null, 
  energy: number | null, 
  soreness: number | null
): number | null {
  if (sleepHours === null && energy === null && soreness === null) return null;

  let score = 0;
  let weightsSum = 0;

  if (sleepHours !== null && sleepHours > 0) {
    // 8 hours = 100% of sleep factor (40 pts)
    const sleepFactor = Math.min(40, (sleepHours / 8) * 40);
    score += sleepFactor;
    weightsSum += 40;
  }

  if (energy !== null && energy >= 1) {
    // 5 energy = 100% of energy factor (35 pts)
    const energyFactor = (energy / 5) * 35;
    score += energyFactor;
    weightsSum += 35;
  }

  if (soreness !== null && soreness >= 1) {
    // 1 soreness is freshest = 100% of soreness factor (25 pts)
    // 5 soreness is worst = 20%
    const sorenessFactor = ((6 - soreness) / 5) * 25;
    score += sorenessFactor;
    weightsSum += 25;
  }

  if (weightsSum === 0) return null;

  // Scale up to 100 if only partial markers logged
  const scaledScore = Math.round((score / weightsSum) * 100);
  return Math.min(100, Math.max(0, scaledScore));
}

function getDayDiff(d1: string, d2: string): number {
  const date1 = new Date(d1);
  const date2 = new Date(d2);
  const diffTime = Math.abs(date2.getTime() - date1.getTime());
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

function formatDateISO(date: Date): string {
  return date.toISOString().split('T')[0];
}

function getMondayOfDate(d: Date): Date {
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(d);
  monday.setDate(diff);
  monday.setHours(0, 0, 0, 0);
  return monday;
}

// ==========================================
// 1. DAILY SUMMARY ENGINE
// ==========================================

export function generateDailySummary(
  targetDate: string,
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  exercises: Exercise[],
  sleepEntries: SleepEntry[],
  recoveryEntries: RecoveryEntry[],
  habits: Habit[],
  habitLogs: HabitLog[],
  bodyWeights: BodyWeight[]
): DailySummaryData {
  const todayStr = formatDateISO(new Date());
  const isToday = targetDate === todayStr;

  const dayWorkouts = workouts.filter(w => w.date === targetDate);
  const daySleep = sleepEntries.find(s => s.date === targetDate);
  const dayRecovery = recoveryEntries.find(r => r.date === targetDate);
  const dayBw = bodyWeights.find(b => b.date === targetDate);

  const exMap = new Map(exercises.map(e => [e.id, e]));

  // Process workouts
  let totalDailyVolumeKg = 0;
  let totalDailySets = 0;
  let totalDailyReps = 0;

  const processedWorkouts = dayWorkouts.map(w => {
    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    let wVol = 0;
    let wSets = 0;
    let wReps = 0;

    const exercisesSummary = wExs.map(we => {
      const ex = exMap.get(we.exerciseId);
      const exName = ex?.name || 'Exercise';
      const exCat = ex?.category || 'General';

      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);
      let bestSet = { weight: 0, reps: 0, e1RM: 0 };
      let exVol = 0;

      weSets.forEach(s => {
        const vol = calculateSetVolume(s.weight, s.reps);
        const e1rm = calculateEstimated1RM(s.weight, s.reps);
        exVol += vol;
        wSets += 1;
        wReps += s.reps;

        if (e1rm > bestSet.e1RM || (e1rm === bestSet.e1RM && s.weight > bestSet.weight)) {
          bestSet = { weight: s.weight, reps: s.reps, e1RM: e1rm };
        }
      });

      wVol += exVol;

      return {
        exerciseName: exName,
        category: exCat,
        setsCount: weSets.length,
        bestSet,
        volumeKg: exVol
      };
    });

    totalDailyVolumeKg += wVol;
    totalDailySets += wSets;
    totalDailyReps += wReps;

    let durationMinutes = 0;
    if (w.startTime && w.endTime) {
      const start = new Date(w.startTime).getTime();
      const end = new Date(w.endTime).getTime();
      durationMinutes = Math.max(0, Math.round((end - start) / 60000));
    }

    return {
      id: w.id,
      name: w.name,
      completed: w.completed,
      durationMinutes,
      totalVolumeKg: wVol,
      totalSets: wSets,
      totalReps: wReps,
      exercises: exercisesSummary
    };
  });

  // Process Habits
  const habitItems = habits.map(h => {
    const log = habitLogs.find(l => l.habitId === h.id && l.date === targetDate);
    return {
      habitId: h.id,
      name: h.name,
      completed: !!log?.completed
    };
  });
  const completedHabitsCount = habitItems.filter(h => h.completed).length;
  const habitRate = habits.length > 0 ? Math.round((completedHabitsCount / habits.length) * 100) : 0;

  // Process Sleep & Recovery
  const sleepHours = daySleep?.durationMinutes ? Math.round((daySleep.durationMinutes / 60) * 10) / 10 : null;
  const readiness = calculateReadinessIndex(
    sleepHours, 
    dayRecovery?.energy ?? null, 
    dayRecovery?.soreness ?? null
  );

  // PRs on this day
  const prs = detectSmartPRs(workouts, workoutExercises, sets, exercises);
  const dayPRs = prs.filter(p => p.date === targetDate);

  // Factual observations for the day
  const factualBullets: string[] = [];
  const completedWorkouts = processedWorkouts.filter(w => w.completed);

  if (completedWorkouts.length > 0) {
    const wNames = completedWorkouts.map(w => `'${w.name}'`).join(', ');
    factualBullets.push(
      `Completed ${completedWorkouts.length} workout session${completedWorkouts.length > 1 ? 's' : ''} (${wNames}).`
    );
    factualBullets.push(
      `Total session workload: ${totalDailyVolumeKg.toLocaleString()} kg accrued across ${totalDailySets} sets (${totalDailyReps} total repetitions).`
    );
    if (completedWorkouts[0].durationMinutes > 0) {
      factualBullets.push(`Training duration logged: ${completedWorkouts[0].durationMinutes} minutes.`);
    }
  } else {
    const scheduled = dayWorkouts.filter(w => !w.completed);
    if (scheduled.length > 0) {
      factualBullets.push(`${scheduled.length} scheduled workout session was not marked completed on this date.`);
    } else {
      factualBullets.push('Zero workout sessions scheduled or logged on this date.');
    }
  }

  if (sleepHours !== null) {
    factualBullets.push(
      `Sleep logged: ${sleepHours} hours${daySleep?.quality ? ` (Quality: ${daySleep.quality}/5)` : ''}.`
    );
  }

  if (dayRecovery) {
    factualBullets.push(
      `Biometrics logged: Soreness rating ${dayRecovery.soreness}/5, Energy rating ${dayRecovery.energy}/5.`
    );
  }

  if (readiness !== null) {
    factualBullets.push(`Calculated readiness index: ${readiness}/100 based on logged sleep and recovery markers.`);
  }

  if (habits.length > 0) {
    factualBullets.push(`Habit compliance: ${completedHabitsCount} of ${habits.length} habits completed (${habitRate}%).`);
  }

  if (dayBw) {
    factualBullets.push(`Body weight recorded: ${dayBw.weight} kg.`);
  }

  if (dayPRs.length > 0) {
    factualBullets.push(`${dayPRs.length} Personal Record${dayPRs.length > 1 ? 's' : ''} established on this date.`);
  }

  const hasData = dayWorkouts.length > 0 || !!daySleep || !!dayRecovery || !!dayBw || completedHabitsCount > 0;

  return {
    date: targetDate,
    isToday,
    hasData,
    workouts: processedWorkouts,
    totalDailyVolumeKg,
    totalDailySets,
    totalDailyReps,
    sleep: sleepHours !== null ? { durationHours: sleepHours, quality: daySleep?.quality, hasEntry: true } : null,
    recovery: dayRecovery ? { ...dayRecovery, hasEntry: true } : null,
    readinessScore: readiness,
    habits: {
      totalHabits: habits.length,
      completedCount: completedHabitsCount,
      completionRate: habitRate,
      items: habitItems
    },
    bodyWeight: dayBw?.weight ?? null,
    prEventsToday: dayPRs,
    factualBullets
  };
}

// ==========================================
// 2. WEEKLY SUMMARY ENGINE
// ==========================================

export function generateWeeklySummary(
  targetDate: string, // Any date within the desired week
  targetWorkoutsPerWeek: number = 4,
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  exercises: Exercise[],
  sleepEntries: SleepEntry[],
  recoveryEntries: RecoveryEntry[]
): WeeklySummaryData {
  const refDate = new Date(targetDate);
  const monday = getMondayOfDate(refDate);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const startStr = formatDateISO(monday);
  const endStr = formatDateISO(sunday);

  // Previous week window for WoW delta
  const prevMonday = new Date(monday);
  prevMonday.setDate(monday.getDate() - 7);
  const prevSunday = new Date(monday);
  prevSunday.setDate(monday.getDate() - 1);
  const prevStartStr = formatDateISO(prevMonday);
  const prevEndStr = formatDateISO(prevSunday);

  const todayStr = formatDateISO(new Date());
  const isCurrentWeek = todayStr >= startStr && todayStr <= endStr;

  // Filter workouts
  const completedWorkouts = workouts.filter(w => w.completed && w.date >= startStr && w.date <= endStr);
  const prevCompletedWorkouts = workouts.filter(w => w.completed && w.date >= prevStartStr && w.date <= prevEndStr);

  const exMap = new Map(exercises.map(e => [e.id, e]));

  // Calculate volume, sets, reps, muscle allocation for this week
  let totalVolumeKg = 0;
  let totalSets = 0;
  let totalReps = 0;
  let totalDurationMinutes = 0;
  let durationCount = 0;
  const muscleMap = new Map<string, { volumeKg: number; setCount: number }>();
  const activeDaysSet = new Set<string>();

  completedWorkouts.forEach(w => {
    activeDaysSet.add(w.date);

    if (w.startTime && w.endTime) {
      const dur = Math.round((new Date(w.endTime).getTime() - new Date(w.startTime).getTime()) / 60000);
      if (dur > 0) {
        totalDurationMinutes += dur;
        durationCount += 1;
      }
    }

    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    wExs.forEach(we => {
      const ex = exMap.get(we.exerciseId);
      const cat = ex?.category || 'Other';
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);

      weSets.forEach(s => {
        const vol = calculateSetVolume(s.weight, s.reps);
        totalVolumeKg += vol;
        totalSets += 1;
        totalReps += s.reps;

        const cur = muscleMap.get(cat) || { volumeKg: 0, setCount: 0 };
        cur.volumeKg += vol;
        cur.setCount += 1;
        muscleMap.set(cat, cur);
      });
    });
  });

  // Previous week volume
  let prevWeekVol = 0;
  prevCompletedWorkouts.forEach(w => {
    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    wExs.forEach(we => {
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);
      weSets.forEach(s => {
        prevWeekVol += calculateSetVolume(s.weight, s.reps);
      });
    });
  });

  const prevWeekVolumeKg = prevCompletedWorkouts.length > 0 ? prevWeekVol : null;
  const volumeChangeKg = prevWeekVolumeKg !== null ? totalVolumeKg - prevWeekVolumeKg : null;
  const volumeChangePercent = prevWeekVolumeKg !== null && prevWeekVolumeKg > 0 
    ? Math.round(((totalVolumeKg - prevWeekVolumeKg) / prevWeekVolumeKg) * 1000) / 10 
    : null;

  const adherence = targetWorkoutsPerWeek > 0 
    ? Math.min(100, Math.round((completedWorkouts.length / targetWorkoutsPerWeek) * 100))
    : 100;

  // Muscle Allocation List
  const muscleAllocation = Array.from(muscleMap.entries()).map(([category, data]) => ({
    category,
    volumeKg: data.volumeKg,
    setCount: data.setCount,
    percentage: totalVolumeKg > 0 ? Math.round((data.volumeKg / totalVolumeKg) * 1000) / 10 : 0
  })).sort((a, b) => b.volumeKg - a.volumeKg);

  // Sleep and Recovery averages
  const weekSleep = sleepEntries.filter(s => s.date >= startStr && s.date <= endStr && s.durationMinutes && s.durationMinutes > 0);
  let sleepAverages = null;
  if (weekSleep.length > 0) {
    const sumMin = weekSleep.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);
    const avgHrs = Math.round((sumMin / weekSleep.length / 60) * 10) / 10;
    const over7Hrs = weekSleep.filter(s => (s.durationMinutes || 0) >= 420).length;
    sleepAverages = {
      averageHoursPerNight: avgHrs,
      loggedNights: weekSleep.length,
      adherenceTo7Hours: Math.round((over7Hrs / weekSleep.length) * 100)
    };
  }

  const weekRecovery = recoveryEntries.filter(r => r.date >= startStr && r.date <= endStr);
  let recoveryAverages = null;
  if (weekRecovery.length > 0) {
    const sumSoreness = weekRecovery.reduce((acc, r) => acc + r.soreness, 0);
    const sumEnergy = weekRecovery.reduce((acc, r) => acc + r.energy, 0);
    const avgSoreness = Math.round((sumSoreness / weekRecovery.length) * 10) / 10;
    const avgEnergy = Math.round((sumEnergy / weekRecovery.length) * 10) / 10;
    const avgReadiness = calculateReadinessIndex(
      sleepAverages?.averageHoursPerNight ?? null, 
      avgEnergy, 
      avgSoreness
    ) ?? 50;

    recoveryAverages = {
      averageSoreness: avgSoreness,
      averageEnergy: avgEnergy,
      averageReadiness: avgReadiness
    };
  }

  const activeDaysCount = activeDaysSet.size;
  const restDaysCount = Math.max(0, 7 - activeDaysCount);

  // Factual Bullets
  const factualBullets: string[] = [];
  factualBullets.push(
    `Completed ${completedWorkouts.length} of ${targetWorkoutsPerWeek} target workouts (${adherence}% schedule adherence).`
  );
  factualBullets.push(
    `Weekly tonnage totaled ${totalVolumeKg.toLocaleString()} kg across ${totalSets} sets and ${totalReps} repetitions.`
  );

  if (volumeChangePercent !== null) {
    const direction = volumeChangePercent >= 0 ? '+' : '';
    factualBullets.push(
      `Volume ${volumeChangePercent >= 0 ? 'increased' : 'decreased'} by ${direction}${volumeChangePercent}% (${direction}${volumeChangeKg?.toLocaleString()} kg) compared to the previous week.`
    );
  } else {
    factualBullets.push('No preceding week training records available for volume comparison.');
  }

  if (muscleAllocation.length > 0) {
    const topMuscle = muscleAllocation[0];
    factualBullets.push(
      `Highest volume distribution: ${topMuscle.category} at ${topMuscle.percentage}% (${topMuscle.volumeKg.toLocaleString()} kg across ${topMuscle.setCount} sets).`
    );
  }

  if (sleepAverages) {
    factualBullets.push(
      `Nightly sleep averaged ${sleepAverages.averageHoursPerNight} hours across ${sleepAverages.loggedNights} logged nights.`
    );
  }

  const hasData = completedWorkouts.length > 0 || (sleepAverages !== null) || (recoveryAverages !== null);

  return {
    weekKey: `${startStr} to ${endStr}`,
    startDate: startStr,
    endDate: endStr,
    isCurrentWeek,
    hasData,
    workoutsCompleted: completedWorkouts.length,
    workoutsPlanned: targetWorkoutsPerWeek,
    adherencePercentage: adherence,
    totalVolumeKg,
    previousWeekVolumeKg: prevWeekVolumeKg,
    volumeChangeKg,
    volumeChangePercent,
    totalSets,
    totalReps,
    averageSessionDurationMinutes: durationCount > 0 ? Math.round(totalDurationMinutes / durationCount) : 0,
    muscleAllocation,
    sleepAverages,
    recoveryAverages,
    activeDaysCount,
    restDaysCount,
    factualBullets
  };
}

// ==========================================
// 3. TRAINING CONSISTENCY ENGINE
// ==========================================

export function generateTrainingConsistency(
  workouts: Workout[],
  targetFrequency: number = 4
): TrainingConsistencyData {
  const completed = workouts
    .filter(w => w.completed)
    .sort((a, b) => a.date.localeCompare(b.date));

  if (completed.length === 0) {
    return {
      currentDayStreak: 0,
      currentWeekStreak: 0,
      daysSinceLastWorkout: null,
      frequencyLast4Weeks: 0,
      frequencyLast8Weeks: 0,
      targetFrequency,
      adherenceLast4WeeksPercent: 0,
      dayOfWeekDistribution: [
        { dayName: 'Mon', dayIndex: 1, count: 0, percentage: 0 },
        { dayName: 'Tue', dayIndex: 2, count: 0, percentage: 0 },
        { dayName: 'Wed', dayIndex: 3, count: 0, percentage: 0 },
        { dayName: 'Thu', dayIndex: 4, count: 0, percentage: 0 },
        { dayName: 'Fri', dayIndex: 5, count: 0, percentage: 0 },
        { dayName: 'Sat', dayIndex: 6, count: 0, percentage: 0 },
        { dayName: 'Sun', dayIndex: 0, count: 0, percentage: 0 }
      ],
      averageRestIntervalDays: 0,
      maxRestIntervalDays: 0,
      totalHistoricalWorkouts: 0,
      consistencyScore: 0,
      factualBullets: ['No completed workouts found in the database.']
    };
  }

  const todayStr = formatDateISO(new Date());
  const latestDate = completed[completed.length - 1].date;
  const daysSinceLast = getDayDiff(latestDate, todayStr);

  // Day streak calculation (consecutive active training days)
  const uniqueDates = Array.from(new Set(completed.map(w => w.date))).sort();
  let dayStreak = 0;
  if (daysSinceLast <= 1) {
    let checkDate = new Date(latestDate);
    for (let i = uniqueDates.length - 1; i >= 0; i--) {
      const cur = uniqueDates[i];
      const checkStr = formatDateISO(checkDate);
      if (cur === checkStr) {
        dayStreak += 1;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  // Week streak calculation (consecutive weeks with at least 1 completed workout)
  const weekKeySet = new Set<string>();
  uniqueDates.forEach(d => {
    const monday = getMondayOfDate(new Date(d));
    weekKeySet.add(formatDateISO(monday));
  });
  const sortedWeeks = Array.from(weekKeySet).sort();

  const currentMondayStr = formatDateISO(getMondayOfDate(new Date()));
  let weekStreak = 0;
  let checkMonday = new Date(getMondayOfDate(new Date()));

  // Allow current week in-progress or previous week
  if (!weekKeySet.has(currentMondayStr)) {
    checkMonday.setDate(checkMonday.getDate() - 7);
  }

  while (weekKeySet.has(formatDateISO(checkMonday))) {
    weekStreak += 1;
    checkMonday.setDate(checkMonday.getDate() - 7);
  }

  // Frequency in last 28 days (4 weeks) and 56 days (8 weeks)
  const d28Ago = new Date();
  d28Ago.setDate(d28Ago.getDate() - 28);
  const d28AgoStr = formatDateISO(d28Ago);

  const d56Ago = new Date();
  d56Ago.setDate(d56Ago.getDate() - 56);
  const d56AgoStr = formatDateISO(d56Ago);

  const workoutsLast4Weeks = completed.filter(w => w.date >= d28AgoStr).length;
  const workoutsLast8Weeks = completed.filter(w => w.date >= d56AgoStr).length;

  const freq4W = Math.round((workoutsLast4Weeks / 4) * 10) / 10;
  const freq8W = Math.round((workoutsLast8Weeks / 8) * 10) / 10;
  const target4W = targetFrequency * 4;
  const adherence4W = target4W > 0 ? Math.min(100, Math.round((workoutsLast4Weeks / target4W) * 100)) : 100;

  // Day of week distribution
  const dayCounts = [0, 0, 0, 0, 0, 0, 0]; // 0=Sun, 1=Mon, ..., 6=Sat
  completed.forEach(w => {
    const day = new Date(w.date + 'T12:00:00').getDay();
    dayCounts[day] += 1;
  });

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dayOrder = [1, 2, 3, 4, 5, 6, 0]; // Mon to Sun order
  const dayOfWeekDistribution = dayOrder.map(idx => ({
    dayName: dayNames[idx],
    dayIndex: idx,
    count: dayCounts[idx],
    percentage: completed.length > 0 ? Math.round((dayCounts[idx] / completed.length) * 100) : 0
  }));

  // Rest day interval calculation
  let totalRestDays = 0;
  let maxRestGap = 0;
  for (let i = 1; i < uniqueDates.length; i++) {
    const gap = getDayDiff(uniqueDates[i - 1], uniqueDates[i]) - 1; // rest days between
    if (gap > 0) {
      totalRestDays += gap;
      if (gap > maxRestGap) maxRestGap = gap;
    }
  }
  const intervalsCount = Math.max(1, uniqueDates.length - 1);
  const avgRestInterval = Math.round((totalRestDays / intervalsCount) * 10) / 10;

  // Consistency Score: weighted composite of adherence and frequency
  const consistencyScore = Math.min(100, Math.round(
    adherence4W * 0.7 + Math.min(1, freq4W / targetFrequency) * 30
  ));

  const factualBullets: string[] = [
    `Total historical completed workouts: ${completed.length} sessions.`,
    `Training frequency over the past 28 days: ${freq4W} sessions/week (Adherence: ${adherence4W}% of target ${targetFrequency}/week).`,
    `Current weekly streak: ${weekStreak} consecutive week${weekStreak === 1 ? '' : 's'} with logged workouts.`,
    `Last recorded session was on ${latestDate} (${daysSinceLast === 0 ? 'Today' : `${daysSinceLast} day${daysSinceLast > 1 ? 's' : ''} ago`}).`,
    `Average rest interval between workouts is ${avgRestInterval} days (maximum rest interval observed: ${maxRestGap} days).`
  ];

  return {
    currentDayStreak: dayStreak,
    currentWeekStreak: weekStreak,
    daysSinceLastWorkout: daysSinceLast,
    frequencyLast4Weeks: freq4W,
    frequencyLast8Weeks: freq8W,
    targetFrequency,
    adherenceLast4WeeksPercent: adherence4W,
    dayOfWeekDistribution,
    averageRestIntervalDays: avgRestInterval,
    maxRestIntervalDays: maxRestGap,
    totalHistoricalWorkouts: completed.length,
    consistencyScore,
    factualBullets
  };
}

// ==========================================
// 4. VOLUME CHANGES ENGINE
// ==========================================

export function generateVolumeChanges(
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  exercises: Exercise[]
): VolumeChangeData {
  const completed = workouts.filter(w => w.completed);
  if (completed.length === 0) {
    return {
      weeklyProgressions: [],
      monthOverMonth: null,
      muscleGroupDeltas: [],
      overloadStatus: 'insufficient_data',
      overloadPercentChange: 0,
      factualBullets: ['Requires at least 1 completed workout to calculate volume analytics.']
    };
  }

  const exMap = new Map(exercises.map(e => [e.id, e]));

  // Aggregate volume by week (Monday-based)
  const weekMap = new Map<string, { volumeKg: number; workoutsCount: number; startDate: string; endDate: string }>();

  completed.forEach(w => {
    const monday = getMondayOfDate(new Date(w.date));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    const startStr = formatDateISO(monday);
    const endStr = formatDateISO(sunday);
    const weekKey = `${startStr}`;

    const cur = weekMap.get(weekKey) || {
      volumeKg: 0,
      workoutsCount: 0,
      startDate: startStr,
      endDate: endStr
    };

    cur.workoutsCount += 1;

    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    wExs.forEach(we => {
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);
      weSets.forEach(s => {
        cur.volumeKg += calculateSetVolume(s.weight, s.reps);
      });
    });

    weekMap.set(weekKey, cur);
  });

  const sortedWeekKeys = Array.from(weekMap.keys()).sort();
  // Take last 6 weeks
  const recentWeekKeys = sortedWeekKeys.slice(-6);

  const weeklyProgressions = recentWeekKeys.map((key, i) => {
    const data = weekMap.get(key)!;
    let wowDeltaKg: number | null = null;
    let wowDeltaPercent: number | null = null;

    if (i > 0) {
      const prevKey = recentWeekKeys[i - 1];
      const prevData = weekMap.get(prevKey)!;
      wowDeltaKg = data.volumeKg - prevData.volumeKg;
      wowDeltaPercent = prevData.volumeKg > 0 
        ? Math.round(((data.volumeKg - prevData.volumeKg) / prevData.volumeKg) * 1000) / 10 
        : null;
    }

    return {
      weekLabel: `${data.startDate.slice(5)} to ${data.endDate.slice(5)}`,
      startDate: data.startDate,
      endDate: data.endDate,
      volumeKg: data.volumeKg,
      workoutsCount: data.workoutsCount,
      wowDeltaKg,
      wowDeltaPercent
    };
  });

  // Month-over-Month calculation
  const now = new Date();
  const curYear = now.getFullYear();
  const curMonth = now.getMonth();

  const prevMonthDate = new Date(curYear, curMonth - 1, 1);
  const prevYear = prevMonthDate.getFullYear();
  const prevMonth = prevMonthDate.getMonth();

  const curMonthPrefix = `${curYear}-${String(curMonth + 1).padStart(2, '0')}`;
  const prevMonthPrefix = `${prevYear}-${String(prevMonth + 1).padStart(2, '0')}`;

  let curMonthVol = 0;
  let prevMonthVol = 0;

  completed.forEach(w => {
    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    let vol = 0;
    wExs.forEach(we => {
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);
      weSets.forEach(s => {
        vol += calculateSetVolume(s.weight, s.reps);
      });
    });

    if (w.date.startsWith(curMonthPrefix)) {
      curMonthVol += vol;
    } else if (w.date.startsWith(prevMonthPrefix)) {
      prevMonthVol += vol;
    }
  });

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  let monthOverMonth = null;
  if (prevMonthVol > 0 || curMonthVol > 0) {
    const momDeltaKg = curMonthVol - prevMonthVol;
    const momDeltaPercent = prevMonthVol > 0 
      ? Math.round(((curMonthVol - prevMonthVol) / prevMonthVol) * 1000) / 10 
      : 0;
    monthOverMonth = {
      currentMonthVolumeKg: curMonthVol,
      previousMonthVolumeKg: prevMonthVol,
      momDeltaKg,
      momDeltaPercent,
      currentMonthName: monthNames[curMonth],
      previousMonthName: monthNames[prevMonth]
    };
  }

  // Muscle group deltas (last 14 days vs prior 14 days)
  const d14Ago = new Date();
  d14Ago.setDate(d14Ago.getDate() - 14);
  const d14AgoStr = formatDateISO(d14Ago);

  const d28Ago = new Date();
  d28Ago.setDate(d28Ago.getDate() - 28);
  const d28AgoStr = formatDateISO(d28Ago);

  const recentMuscles = new Map<string, number>();
  const priorMuscles = new Map<string, number>();

  completed.forEach(w => {
    const isRecent = w.date >= d14AgoStr;
    const isPrior = w.date >= d28AgoStr && w.date < d14AgoStr;
    if (!isRecent && !isPrior) return;

    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    wExs.forEach(we => {
      const ex = exMap.get(we.exerciseId);
      const cat = ex?.category || 'Other';
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);

      weSets.forEach(s => {
        const vol = calculateSetVolume(s.weight, s.reps);
        if (isRecent) {
          recentMuscles.set(cat, (recentMuscles.get(cat) || 0) + vol);
        } else {
          priorMuscles.set(cat, (priorMuscles.get(cat) || 0) + vol);
        }
      });
    });
  });

  const allCategories = Array.from(new Set([...recentMuscles.keys(), ...priorMuscles.keys()]));
  const muscleGroupDeltas = allCategories.map(cat => {
    const recent = recentMuscles.get(cat) || 0;
    const prior = priorMuscles.get(cat) || 0;
    const deltaKg = recent - prior;
    const deltaPercent = prior > 0 ? Math.round(((recent - prior) / prior) * 1000) / 10 : (recent > 0 ? 100 : 0);
    return {
      category: cat,
      recentVolumeKg: recent,
      priorVolumeKg: prior,
      deltaKg,
      deltaPercent
    };
  }).sort((a, b) => b.recentVolumeKg - a.recentVolumeKg);

  // Progressive Overload Status
  let overloadStatus: 'increasing' | 'maintaining' | 'deloading' | 'insufficient_data' = 'insufficient_data';
  let overloadPercentChange = 0;

  if (weeklyProgressions.length >= 2) {
    const latest = weeklyProgressions[weeklyProgressions.length - 1];
    if (latest.wowDeltaPercent !== null) {
      overloadPercentChange = latest.wowDeltaPercent;
      if (latest.wowDeltaPercent > 3.0) {
        overloadStatus = 'increasing';
      } else if (latest.wowDeltaPercent < -3.0) {
        overloadStatus = 'deloading';
      } else {
        overloadStatus = 'maintaining';
      }
    }
  }

  // Factual Bullets
  const factualBullets: string[] = [];
  if (weeklyProgressions.length >= 2) {
    const latest = weeklyProgressions[weeklyProgressions.length - 1];
    const prev = weeklyProgressions[weeklyProgressions.length - 2];
    const diffKg = latest.volumeKg - prev.volumeKg;
    const diffSign = diffKg >= 0 ? '+' : '';
    factualBullets.push(
      `Latest weekly volume: ${latest.volumeKg.toLocaleString()} kg vs ${prev.volumeKg.toLocaleString()} kg prior (${diffSign}${latest.wowDeltaPercent}% change).`
    );
    factualBullets.push(
      `Progressive overload status: ${overloadStatus.toUpperCase()} (${diffSign}${overloadPercentChange}% week-over-week).`
    );
  } else if (weeklyProgressions.length === 1) {
    factualBullets.push(`Current recorded weekly volume: ${weeklyProgressions[0].volumeKg.toLocaleString()} kg across ${weeklyProgressions[0].workoutsCount} sessions.`);
  }

  if (monthOverMonth && monthOverMonth.previousMonthVolumeKg > 0) {
    const sign = monthOverMonth.momDeltaKg >= 0 ? '+' : '';
    factualBullets.push(
      `Month-over-month volume comparison: ${monthOverMonth.currentMonthName} (${monthOverMonth.currentMonthVolumeKg.toLocaleString()} kg) vs ${monthOverMonth.previousMonthName} (${monthOverMonth.previousMonthVolumeKg.toLocaleString()} kg), net ${sign}${monthOverMonth.momDeltaKg.toLocaleString()} kg (${sign}${monthOverMonth.momDeltaPercent}%).`
    );
  }

  return {
    weeklyProgressions,
    monthOverMonth,
    muscleGroupDeltas,
    overloadStatus,
    overloadPercentChange,
    factualBullets
  };
}

// ==========================================
// 5. PR EVENTS ENGINE
// ==========================================

export function detectSmartPRs(
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  exercises: Exercise[]
): DetectedSmartPR[] {
  const completedWorkouts = workouts
    .filter(w => w.completed)
    .sort((a, b) => a.date.localeCompare(b.date));

  const exMap = new Map(exercises.map(e => [e.id, e]));
  const detectedPRs: DetectedSmartPR[] = [];

  // Track running all-time maximums per exercise
  const maxWeightMap = new Map<string, number>();
  const max1RMMap = new Map<string, number>();

  completedWorkouts.forEach(w => {
    const wExs = workoutExercises.filter(we => we.workoutId === w.id);

    wExs.forEach(we => {
      const ex = exMap.get(we.exerciseId);
      const exName = ex?.name || 'Exercise';
      const category = ex?.category || 'General';
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed && s.weight > 0 && s.reps > 0);

      weSets.forEach(s => {
        const e1rm = calculateEstimated1RM(s.weight, s.reps);

        // Check Max Weight PR
        const curMaxWeight = maxWeightMap.get(we.exerciseId) || 0;
        if (s.weight > curMaxWeight) {
          const delta = Math.round((s.weight - curMaxWeight) * 10) / 10;
          const percentGain = curMaxWeight > 0 ? Math.round((delta / curMaxWeight) * 1000) / 10 : 100;

          detectedPRs.push({
            id: `pr-weight-${we.exerciseId}-${s.id}`,
            exerciseId: we.exerciseId,
            exerciseName: exName,
            category,
            date: w.date,
            workoutId: w.id,
            workoutName: w.name,
            metricType: 'weight',
            newValue: s.weight,
            previousValue: curMaxWeight,
            delta,
            percentGain,
            reps: s.reps,
            weight: s.weight
          });

          maxWeightMap.set(we.exerciseId, s.weight);
        }

        // Check Estimated 1RM PR
        const curMax1RM = max1RMMap.get(we.exerciseId) || 0;
        if (e1rm > curMax1RM) {
          const delta = Math.round((e1rm - curMax1RM) * 10) / 10;
          const percentGain = curMax1RM > 0 ? Math.round((delta / curMax1RM) * 1000) / 10 : 100;

          detectedPRs.push({
            id: `pr-1rm-${we.exerciseId}-${s.id}`,
            exerciseId: we.exerciseId,
            exerciseName: exName,
            category,
            date: w.date,
            workoutId: w.id,
            workoutName: w.name,
            metricType: 'estimated1RM',
            newValue: e1rm,
            previousValue: curMax1RM,
            delta,
            percentGain,
            reps: s.reps,
            weight: s.weight
          });

          max1RMMap.set(we.exerciseId, e1rm);
        }
      });
    });
  });

  return detectedPRs.sort((a, b) => b.date.localeCompare(a.date));
}

export function generatePREvents(
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  exercises: Exercise[]
): PREventData {
  const prs = detectSmartPRs(workouts, workoutExercises, sets, exercises);

  const d7Ago = new Date();
  d7Ago.setDate(d7Ago.getDate() - 7);
  const d7AgoStr = formatDateISO(d7Ago);

  const d30Ago = new Date();
  d30Ago.setDate(d30Ago.getDate() - 30);
  const d30AgoStr = formatDateISO(d30Ago);

  const prs7 = prs.filter(p => p.date >= d7AgoStr).length;
  const prs30 = prs.filter(p => p.date >= d30AgoStr).length;

  // Group by exercise
  const exSummaryMap = new Map<string, { name: string; count: number; best1RM: number; bestWeight: number; lastDate: string }>();
  prs.forEach(p => {
    const cur = exSummaryMap.get(p.exerciseId) || {
      name: p.exerciseName,
      count: 0,
      best1RM: 0,
      bestWeight: 0,
      lastDate: p.date
    };
    cur.count += 1;
    if (p.metricType === 'weight' && p.newValue > cur.bestWeight) cur.bestWeight = p.newValue;
    if (p.metricType === 'estimated1RM' && p.newValue > cur.best1RM) cur.best1RM = p.newValue;
    if (p.date > cur.lastDate) cur.lastDate = p.date;
    exSummaryMap.set(p.exerciseId, cur);
  });

  const exercisePRSummary = Array.from(exSummaryMap.values()).map(e => ({
    exerciseName: e.name,
    totalPRs: e.count,
    best1RM: e.best1RM,
    bestWeight: e.bestWeight,
    lastPRDate: e.lastDate
  })).sort((a, b) => b.totalPRs - a.totalPRs);

  const factualBullets: string[] = [];
  factualBullets.push(`Total verified Personal Records established all-time: ${prs.length}.`);
  factualBullets.push(`PRs achieved in the past 7 days: ${prs7} | Past 30 days: ${prs30}.`);
  if (exercisePRSummary.length > 0) {
    const top = exercisePRSummary[0];
    factualBullets.push(`Most PR-active exercise: ${top.exerciseName} with ${top.totalPRs} records (Peak 1RM: ${top.best1RM} kg).`);
  }

  return {
    allPREvents: prs,
    totalPRsAllTime: prs.length,
    prsLast7Days: prs7,
    prsLast30Days: prs30,
    exercisePRSummary,
    factualBullets
  };
}

// ==========================================
// 6. MISSED WORKOUTS ENGINE
// ==========================================

export function generateMissedWorkouts(
  workouts: Workout[],
  targetWorkoutsPerWeek: number = 4
): MissedWorkoutData {
  const todayStr = formatDateISO(new Date());

  // 1. Scheduled workouts in the past that are incomplete
  const uncompletedScheduledWorkouts = workouts
    .filter(w => !w.completed && w.date < todayStr)
    .map(w => ({
      id: w.id,
      name: w.name,
      scheduledDate: w.date,
      reason: 'scheduled_past_uncompleted' as const
    }))
    .sort((a, b) => b.scheduledDate.localeCompare(a.scheduledDate));

  // 2. Weekly deficits against target frequency for completed past weeks
  const completedWorkouts = workouts
    .filter(w => w.completed)
    .sort((a, b) => a.date.localeCompare(b.date));

  const weekMap = new Map<string, { count: number; startDate: string; endDate: string }>();

  completedWorkouts.forEach(w => {
    const monday = getMondayOfDate(new Date(w.date));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    const startStr = formatDateISO(monday);
    const endStr = formatDateISO(sunday);
    const key = startStr;

    const cur = weekMap.get(key) || { count: 0, startDate: startStr, endDate: endStr };
    cur.count += 1;
    weekMap.set(key, cur);
  });

  const weeklyDeficits: Array<{
    weekLabel: string;
    startDate: string;
    endDate: string;
    targetSessions: number;
    completedSessions: number;
    missedSessionsCount: number;
  }> = [];

  // Evaluate past weeks (not current week)
  const currentMondayStr = formatDateISO(getMondayOfDate(new Date()));
  let totalDeficitSessions = 0;
  let totalTargetSessions = 0;
  let totalCompletedInWeeks = 0;

  const sortedWeekKeys = Array.from(weekMap.keys()).sort();
  sortedWeekKeys.forEach(k => {
    if (k < currentMondayStr) {
      const data = weekMap.get(k)!;
      const missed = Math.max(0, targetWorkoutsPerWeek - data.count);
      totalTargetSessions += targetWorkoutsPerWeek;
      totalCompletedInWeeks += data.count;
      totalDeficitSessions += missed;

      if (missed > 0) {
        weeklyDeficits.push({
          weekLabel: `${data.startDate} to ${data.endDate}`,
          startDate: data.startDate,
          endDate: data.endDate,
          targetSessions: targetWorkoutsPerWeek,
          completedSessions: data.count,
          missedSessionsCount: missed
        });
      }
    }
  });

  // 3. Extended training gaps (> 3 days between consecutive workouts)
  const extendedTrainingGaps: Array<{
    startDate: string;
    endDate: string;
    gapDays: number;
    precedingWorkoutName: string;
    followingWorkoutName?: string;
  }> = [];

  for (let i = 1; i < completedWorkouts.length; i++) {
    const prev = completedWorkouts[i - 1];
    const curr = completedWorkouts[i];
    const days = getDayDiff(prev.date, curr.date);
    if (days > 3) {
      extendedTrainingGaps.push({
        startDate: prev.date,
        endDate: curr.date,
        gapDays: days,
        precedingWorkoutName: prev.name,
        followingWorkoutName: curr.name
      });
    }
  }

  // Also check gap from last workout to today
  if (completedWorkouts.length > 0) {
    const lastW = completedWorkouts[completedWorkouts.length - 1];
    const daysSince = getDayDiff(lastW.date, todayStr);
    if (daysSince > 3) {
      extendedTrainingGaps.push({
        startDate: lastW.date,
        endDate: todayStr,
        gapDays: daysSince,
        precedingWorkoutName: lastW.name
      });
    }
  }

  const totalMissedSessions = uncompletedScheduledWorkouts.length + totalDeficitSessions;
  const overallScheduleAdherencePercent = totalTargetSessions > 0
    ? Math.min(100, Math.round((totalCompletedInWeeks / totalTargetSessions) * 100))
    : 100;

  const factualBullets: string[] = [
    `Uncompleted past scheduled sessions in database: ${uncompletedScheduledWorkouts.length}.`,
    `Weekly target frequency deficits: ${totalDeficitSessions} missed session${totalDeficitSessions === 1 ? '' : 's'} across past concluded weeks.`,
    `Extended hiatus events (> 3 days without training): ${extendedTrainingGaps.length} detected.`,
    `Long-term schedule adherence rate: ${overallScheduleAdherencePercent}% (${totalCompletedInWeeks} completed / ${totalTargetSessions} target sessions).`
  ];

  return {
    uncompletedScheduledWorkouts,
    weeklyDeficits,
    extendedTrainingGaps,
    totalMissedSessions,
    overallScheduleAdherencePercent,
    factualBullets
  };
}

// ==========================================
// 7. RECOVERY OVERVIEW ENGINE
// ==========================================

export function generateRecoveryOverview(
  workouts: Workout[],
  workoutExercises: WorkoutExercise[],
  sets: Set[],
  sleepEntries: SleepEntry[],
  recoveryEntries: RecoveryEntry[]
): RecoveryOverviewData {
  const todayStr = formatDateISO(new Date());

  const d7Ago = new Date();
  d7Ago.setDate(d7Ago.getDate() - 7);
  const d7AgoStr = formatDateISO(d7Ago);

  const d14Ago = new Date();
  d14Ago.setDate(d14Ago.getDate() - 14);
  const d14AgoStr = formatDateISO(d14Ago);

  const d30Ago = new Date();
  d30Ago.setDate(d30Ago.getDate() - 30);
  const d30AgoStr = formatDateISO(d30Ago);

  // Sleep averages
  const validSleep = sleepEntries.filter(s => s.durationMinutes && s.durationMinutes > 0);
  const sleep7 = validSleep.filter(s => s.date >= d7AgoStr);
  const sleep30 = validSleep.filter(s => s.date >= d30AgoStr);

  const sleep7Avg = sleep7.length > 0 
    ? Math.round((sleep7.reduce((acc, s) => acc + (s.durationMinutes || 0), 0) / sleep7.length / 60) * 10) / 10 
    : null;

  const sleep30Avg = sleep30.length > 0 
    ? Math.round((sleep30.reduce((acc, s) => acc + (s.durationMinutes || 0), 0) / sleep30.length / 60) * 10) / 10 
    : null;

  let sleepMinHours: number | null = null;
  let sleepMaxHours: number | null = null;
  if (validSleep.length > 0) {
    const hours = validSleep.map(s => (s.durationMinutes || 0) / 60);
    sleepMinHours = Math.round(Math.min(...hours) * 10) / 10;
    sleepMaxHours = Math.round(Math.max(...hours) * 10) / 10;
  }

  // Recovery averages (soreness, energy)
  const recovery7 = recoveryEntries.filter(r => r.date >= d7AgoStr);
  const soreness7Avg = recovery7.length > 0
    ? Math.round((recovery7.reduce((acc, r) => acc + r.soreness, 0) / recovery7.length) * 10) / 10
    : null;
  const energy7Avg = recovery7.length > 0
    ? Math.round((recovery7.reduce((acc, r) => acc + r.energy, 0) / recovery7.length) * 10) / 10
    : null;

  const currentReadiness = calculateReadinessIndex(sleep7Avg, energy7Avg, soreness7Avg);

  // Rest days in last 7 and 14 days
  const completedWorkouts = workouts.filter(w => w.completed);
  const workoutDates7 = new Set(completedWorkouts.filter(w => w.date >= d7AgoStr).map(w => w.date));
  const workoutDates14 = new Set(completedWorkouts.filter(w => w.date >= d14AgoStr).map(w => w.date));

  const restDaysLast7Days = Math.max(0, 7 - workoutDates7.size);
  const restDaysLast14Days = Math.max(0, 14 - workoutDates14.size);

  // Training load vs Recovery Correlation
  // Calculate daily volume for each completed workout
  const dailyWorkoutVol = new Map<string, number>();
  completedWorkouts.forEach(w => {
    const wExs = workoutExercises.filter(we => we.workoutId === w.id);
    let vol = 0;
    wExs.forEach(we => {
      const weSets = sets.filter(s => s.workoutExerciseId === we.id && s.completed);
      weSets.forEach(s => {
        vol += calculateSetVolume(s.weight, s.reps);
      });
    });
    dailyWorkoutVol.set(w.date, (dailyWorkoutVol.get(w.date) || 0) + vol);
  });

  // Check next-day soreness following high-volume vs rest/low-volume days
  const allVols = Array.from(dailyWorkoutVol.values());
  let highLoadAvgSoreness: number | null = null;
  let lowLoadAvgSoreness: number | null = null;
  let sorenessDelta: number | null = null;
  let hasCorrelationData = false;

  if (allVols.length >= 3 && recoveryEntries.length >= 3) {
    const sortedVols = [...allVols].sort((a, b) => a - b);
    const medianVol = sortedVols[Math.floor(sortedVols.length / 2)];

    const highLoadSoreness: number[] = [];
    const lowLoadSoreness: number[] = [];

    recoveryEntries.forEach(r => {
      // Find workout on previous day
      const rDate = new Date(r.date);
      rDate.setDate(rDate.getDate() - 1);
      const prevDateStr = formatDateISO(rDate);

      const prevVol = dailyWorkoutVol.get(prevDateStr) || 0;
      if (prevVol >= medianVol && prevVol > 0) {
        highLoadSoreness.push(r.soreness);
      } else {
        lowLoadSoreness.push(r.soreness);
      }
    });

    if (highLoadSoreness.length > 0 && lowLoadSoreness.length > 0) {
      const highAvg = highLoadSoreness.reduce((a, b) => a + b, 0) / highLoadSoreness.length;
      const lowAvg = lowLoadSoreness.reduce((a, b) => a + b, 0) / lowLoadSoreness.length;
      highLoadAvgSoreness = Math.round(highAvg * 10) / 10;
      lowLoadAvgSoreness = Math.round(lowAvg * 10) / 10;
      sorenessDelta = Math.round((highAvg - lowAvg) * 10) / 10;
      hasCorrelationData = true;
    }
  }

  // Daily points for the last 14 days
  const dailyRecoveryPoints: RecoveryOverviewData['dailyRecoveryPoints'] = [];
  for (let d = 13; d >= 0; d--) {
    const ptDate = new Date();
    ptDate.setDate(ptDate.getDate() - d);
    const ptDateStr = formatDateISO(ptDate);

    const sl = sleepEntries.find(s => s.date === ptDateStr);
    const slHrs = sl?.durationMinutes ? Math.round((sl.durationMinutes / 60) * 10) / 10 : null;
    const rc = recoveryEntries.find(r => r.date === ptDateStr);
    const vol = dailyWorkoutVol.get(ptDateStr) || 0;

    dailyRecoveryPoints.push({
      date: ptDateStr,
      sleepHours: slHrs,
      soreness: rc?.soreness ?? null,
      energy: rc?.energy ?? null,
      readinessScore: calculateReadinessIndex(slHrs, rc?.energy ?? null, rc?.soreness ?? null),
      hadWorkout: dailyWorkoutVol.has(ptDateStr),
      workoutVolumeKg: vol
    });
  }

  const factualBullets: string[] = [];
  if (sleep7Avg !== null) {
    factualBullets.push(`7-day rolling average sleep: ${sleep7Avg} hours/night across ${sleep7.length} logged night${sleep7.length === 1 ? '' : 's'}.`);
  } else {
    factualBullets.push('No sleep logs recorded in the past 7 days.');
  }

  if (soreness7Avg !== null && energy7Avg !== null) {
    factualBullets.push(`Biometric 7-day baseline: Soreness ${soreness7Avg}/5, Energy ${energy7Avg}/5.`);
  }

  if (hasCorrelationData && sorenessDelta !== null && highLoadAvgSoreness !== null && lowLoadAvgSoreness !== null) {
    factualBullets.push(
      `Post-training fatigue delta: Next-day soreness averaged ${highLoadAvgSoreness}/5 following heavy sessions vs ${lowLoadAvgSoreness}/5 following rest or light days (Delta: ${sorenessDelta > 0 ? '+' : ''}${sorenessDelta}).`
    );
  }

  factualBullets.push(`Rest days accrued: ${restDaysLast7Days} in the past 7 days, ${restDaysLast14Days} in the past 14 days.`);

  return {
    sleep7DayAvg: sleep7Avg,
    sleep30DayAvg: sleep30Avg,
    sleepLoggedCount: validSleep.length,
    sleepMinHours,
    sleepMaxHours,
    soreness7DayAvg: soreness7Avg,
    energy7DayAvg: energy7Avg,
    readinessScoreCurrent: currentReadiness,
    restDaysLast7Days,
    restDaysLast14Days,
    trainingLoadCorrelation: {
      highLoadAvgSoreness,
      lowLoadAvgSoreness,
      sorenessDelta,
      hasCorrelationData
    },
    dailyRecoveryPoints,
    factualBullets
  };
}

// ==========================================
// 8. FACTUAL INSIGHTS ENGINE
// ==========================================

export function generateFactualInsights(
  daily: DailySummaryData,
  weekly: WeeklySummaryData,
  consistency: TrainingConsistencyData,
  volume: VolumeChangeData,
  prs: PREventData,
  missed: MissedWorkoutData,
  recovery: RecoveryOverviewData
): FactualInsightsData {
  const volumeOverload: string[] = [];
  const scheduleAdherence: string[] = [];
  const recoverySleep: string[] = [];
  const strengthRecords: string[] = [];

  // 1. Volume & Progressive Overload Insights
  if (volume.weeklyProgressions.length >= 2) {
    const latest = volume.weeklyProgressions[volume.weeklyProgressions.length - 1];
    const prev = volume.weeklyProgressions[volume.weeklyProgressions.length - 2];
    const sign = (latest.wowDeltaKg ?? 0) >= 0 ? '+' : '';
    volumeOverload.push(
      `Weekly training volume changed by ${sign}${latest.wowDeltaPercent}% (${sign}${latest.wowDeltaKg?.toLocaleString()} kg) compared to the prior week (${latest.volumeKg.toLocaleString()} kg vs ${prev.volumeKg.toLocaleString()} kg).`
    );
    volumeOverload.push(
      `Progressive overload classification: ${volume.overloadStatus.toUpperCase()} based on deterministic week-over-week workload delta.`
    );
  } else if (volume.weeklyProgressions.length === 1) {
    volumeOverload.push(
      `Current week training volume is ${volume.weeklyProgressions[0].volumeKg.toLocaleString()} kg recorded across ${volume.weeklyProgressions[0].workoutsCount} workout session${volume.weeklyProgressions[0].workoutsCount === 1 ? '' : 's'}.`
    );
  }

  if (weekly.muscleAllocation.length > 0) {
    const top = weekly.muscleAllocation[0];
    volumeOverload.push(
      `${top.category} received the largest volume allocation this week at ${top.percentage}% of total tonnage (${top.volumeKg.toLocaleString()} kg across ${top.setCount} completed sets).`
    );
  }

  if (volume.monthOverMonth && volume.monthOverMonth.previousMonthVolumeKg > 0) {
    const sign = volume.monthOverMonth.momDeltaKg >= 0 ? '+' : '';
    volumeOverload.push(
      `Month-over-month tonnage delta: ${sign}${volume.monthOverMonth.momDeltaKg.toLocaleString()} kg (${sign}${volume.monthOverMonth.momDeltaPercent}%) between ${volume.monthOverMonth.currentMonthName} and ${volume.monthOverMonth.previousMonthName}.`
    );
  }

  // 2. Schedule & Adherence Insights
  scheduleAdherence.push(
    `Completed ${weekly.workoutsCompleted} of ${weekly.workoutsPlanned} planned workouts this week (${weekly.adherencePercentage}% weekly adherence).`
  );
  scheduleAdherence.push(
    `28-day training frequency: ${consistency.frequencyLast4Weeks} sessions/week (${consistency.adherenceLast4WeeksPercent}% of ${consistency.targetFrequency}/week target).`
  );

  if (consistency.daysSinceLastWorkout !== null) {
    scheduleAdherence.push(
      `Last completed workout was ${consistency.daysSinceLastWorkout === 0 ? 'today' : `${consistency.daysSinceLastWorkout} day${consistency.daysSinceLastWorkout === 1 ? '' : 's'} ago`}.`
    );
  }

  if (missed.totalMissedSessions > 0) {
    scheduleAdherence.push(
      `${missed.totalMissedSessions} total missed session${missed.totalMissedSessions === 1 ? '' : 's'} identified across historical schedule targets.`
    );
  } else {
    scheduleAdherence.push('Zero uncompleted scheduled workouts or weekly deficits detected.');
  }

  // 3. Recovery & Sleep Insights
  if (recovery.sleep7DayAvg !== null) {
    recoverySleep.push(
      `7-day rolling sleep duration averaged ${recovery.sleep7DayAvg} hours/night.`
    );
  }

  if (recovery.readinessScoreCurrent !== null) {
    recoverySleep.push(
      `Current biometric readiness index is ${recovery.readinessScoreCurrent}/100 based on weighted sleep, energy, and muscle soreness scores.`
    );
  }

  if (recovery.trainingLoadCorrelation.hasCorrelationData && recovery.trainingLoadCorrelation.sorenessDelta !== null) {
    recoverySleep.push(
      `Next-day muscle soreness is ${recovery.trainingLoadCorrelation.sorenessDelta > 0 ? '+' : ''}${recovery.trainingLoadCorrelation.sorenessDelta} points higher following heavy sessions vs rest days.`
    );
  }

  recoverySleep.push(
    `Accumulated ${recovery.restDaysLast7Days} rest days over the past 7 days (${recovery.restDaysLast14Days} over the past 14 days).`
  );

  // 4. Strength & Personal Records Insights
  strengthRecords.push(
    `Total verified Personal Records established in database: ${prs.totalPRsAllTime}.`
  );

  if (prs.prsLast7Days > 0) {
    strengthRecords.push(
      `${prs.prsLast7Days} Personal Record${prs.prsLast7Days === 1 ? '' : 's'} established within the past 7 days.`
    );
  } else if (prs.prsLast30Days > 0) {
    strengthRecords.push(
      `${prs.prsLast30Days} Personal Record${prs.prsLast30Days === 1 ? '' : 's'} established within the past 30 days.`
    );
  }

  if (prs.exercisePRSummary.length > 0) {
    const top = prs.exercisePRSummary[0];
    strengthRecords.push(
      `${top.exerciseName} has the highest historical PR frequency with ${top.totalPRs} recorded milestones (Current peak 1RM: ${top.best1RM} kg).`
    );
  }

  const totalInsightsCount = 
    volumeOverload.length + scheduleAdherence.length + recoverySleep.length + strengthRecords.length;

  return {
    categories: {
      volumeOverload,
      scheduleAdherence,
      recoverySleep,
      strengthRecords
    },
    totalInsightsCount
  };
}

// ==========================================
// 9. AUTOMATED TEST & VERIFICATION SUITE
// ==========================================

export interface SmartTrackVerificationTest {
  name: string;
  category: string;
  passed: boolean;
  expected: any;
  actual: any;
  explanation: string;
}

export function runSmartTrackEngineVerificationSuite(): SmartTrackVerificationTest[] {
  const tests: SmartTrackVerificationTest[] = [];

  // Test 1: Readiness Index - Perfect inputs (8h sleep, 5 energy, 1 soreness) => 100/100
  const perfectReadiness = calculateReadinessIndex(8, 5, 1);
  tests.push({
    name: 'Readiness Index Ideal Baseline (8h, 5 energy, 1 soreness)',
    category: 'Recovery Math',
    passed: perfectReadiness === 100,
    expected: 100,
    actual: perfectReadiness,
    explanation: '40 (sleep) + 35 (energy) + 25 (soreness inverted) = 100.'
  });

  // Test 2: Readiness Index - Degraded inputs (6h sleep, 3 energy, 4 soreness)
  // sleep: (6/8)*40 = 30
  // energy: (3/5)*35 = 21
  // soreness: ((6-4)/5)*25 = 10
  // total = 30 + 21 + 10 = 61
  const degradedReadiness = calculateReadinessIndex(6, 3, 4);
  tests.push({
    name: 'Readiness Index Degraded Biometrics (6h, 3 energy, 4 soreness)',
    category: 'Recovery Math',
    passed: degradedReadiness === 61,
    expected: 61,
    actual: degradedReadiness,
    explanation: '30 + 21 + 10 = 61 index points.'
  });

  // Test 3: Daily Summary Volume Summation
  const mockWorkouts: Workout[] = [
    { id: 'w1', name: 'Upper Test', date: '2026-03-01', completed: true, startTime: '2026-03-01T10:00:00Z', endTime: '2026-03-01T11:00:00Z' }
  ];
  const mockWEs: WorkoutExercise[] = [
    { id: 'we1', workoutId: 'w1', exerciseId: 'ex1', order: 0 }
  ];
  const mockSets: Set[] = [
    { id: 's1', workoutExerciseId: 'we1', weight: 80, reps: 10, completed: true, order: 0 }, // 800 kg
    { id: 's2', workoutExerciseId: 'we1', weight: 90, reps: 6, completed: true, order: 1 }   // 540 kg -> sum = 1340 kg
  ];
  const mockExs: Exercise[] = [
    { id: 'ex1', name: 'Bench Press', category: 'Chest', targetMuscle: 'Chest', isArchived: false }
  ];

  const dailySummary = generateDailySummary(
    '2026-03-01',
    mockWorkouts,
    mockWEs,
    mockSets,
    mockExs,
    [],
    [],
    [],
    [],
    []
  );

  tests.push({
    name: 'Daily Summary Total Volume & Sets Math',
    category: 'Daily Summary',
    passed: dailySummary.totalDailyVolumeKg === 1340 && dailySummary.totalDailySets === 2,
    expected: { volume: 1340, sets: 2 },
    actual: { volume: dailySummary.totalDailyVolumeKg, sets: dailySummary.totalDailySets },
    explanation: '(80kg * 10) + (90kg * 6) = 800 + 540 = 1340 kg across 2 completed sets.'
  });

  // Test 4: Weekly Summary Adherence Math (3 of 4 target = 75%)
  const weeklySummary = generateWeeklySummary(
    '2026-03-01',
    4,
    mockWorkouts,
    mockWEs,
    mockSets,
    mockExs,
    [],
    []
  );

  tests.push({
    name: 'Weekly Summary Adherence Percentage (1 of 4 target)',
    category: 'Weekly Summary',
    passed: weeklySummary.adherencePercentage === 25,
    expected: 25,
    actual: weeklySummary.adherencePercentage,
    explanation: '1 completed workout / 4 target workouts = 25%.'
  });

  // Test 5: Volume Change Week-over-Week Percentage
  // Week 1: 1000 kg, Week 2: 1100 kg -> +10%
  const w1: Workout = { id: 'wA', name: 'W1', date: '2026-01-05', completed: true }; // Mon
  const w2: Workout = { id: 'wB', name: 'W2', date: '2026-01-12', completed: true }; // Mon next wk
  const weA: WorkoutExercise = { id: 'weA', workoutId: 'wA', exerciseId: 'ex1', order: 0 };
  const weB: WorkoutExercise = { id: 'weB', workoutId: 'wB', exerciseId: 'ex1', order: 0 };
  const sA: Set = { id: 'sA', workoutExerciseId: 'weA', weight: 100, reps: 10, completed: true, order: 0 }; // 1000 kg
  const sB: Set = { id: 'sB', workoutExerciseId: 'weB', weight: 110, reps: 10, completed: true, order: 0 }; // 1100 kg

  const volData = generateVolumeChanges([w1, w2], [weA, weB], [sA, sB], mockExs);
  const latestWoW = volData.weeklyProgressions[volData.weeklyProgressions.length - 1];

  tests.push({
    name: 'Volume Change WoW Formula (+10% Overload)',
    category: 'Volume Changes',
    passed: latestWoW.wowDeltaPercent === 10 && latestWoW.wowDeltaKg === 100,
    expected: { deltaKg: 100, deltaPercent: 10 },
    actual: { deltaKg: latestWoW.wowDeltaKg, deltaPercent: latestWoW.wowDeltaPercent },
    explanation: '((1100 - 1000) / 1000) * 100 = exactly +10.0%.'
  });

  // Test 6: Missed Workout Uncompleted Past Detection
  const pastUncompletedW: Workout = {
    id: 'missed1',
    name: 'Scheduled Leg Day',
    date: '2026-01-01',
    completed: false
  };
  const missedData = generateMissedWorkouts([pastUncompletedW], 4);
  tests.push({
    name: 'Missed Workout Detection for Past Incomplete Sessions',
    category: 'Missed Workouts',
    passed: missedData.uncompletedScheduledWorkouts.length === 1,
    expected: 1,
    actual: missedData.uncompletedScheduledWorkouts.length,
    explanation: 'Workout scheduled in past (2026-01-01) with completed=false correctly flagged as missed.'
  });

  // Test 7: Training Consistency Rest Interval Cadence
  const wDay1: Workout = { id: 'wD1', name: 'D1', date: '2026-01-01', completed: true };
  const wDay3: Workout = { id: 'wD3', name: 'D3', date: '2026-01-03', completed: true }; // 1 rest day between
  const wDay6: Workout = { id: 'wD6', name: 'D6', date: '2026-01-06', completed: true }; // 2 rest days between
  // total rest days = 1 + 2 = 3 / 2 intervals = 1.5 avg rest days
  const consistencyData = generateTrainingConsistency([wDay1, wDay3, wDay6], 3);
  tests.push({
    name: 'Training Consistency Rest Interval Math',
    category: 'Consistency',
    passed: consistencyData.averageRestIntervalDays === 1.5,
    expected: 1.5,
    actual: consistencyData.averageRestIntervalDays,
    explanation: '3 rest days across 2 intervals = exactly 1.5 days.'
  });

  return tests;
}
