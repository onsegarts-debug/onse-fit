import { db } from '../db';
import type { Workout, WorkoutExercise, Set, BodyWeight, Measurement, ProgressPhoto } from '../types';

/**
 * Deterministic Benchmark Dataset for ONSE FIT
 * Realistic 4-week strength training progression, body weight log, measurements, and progress photos.
 * Used for testing calculations against known sample data.
 */

export async function seedBenchmarkData() {
  // 1. Fetch available exercises
  const exercises = await db.exercises.toArray();
  const bench = exercises.find(e => e.name.includes('Bench Press')) || exercises[0];
  const squat = exercises.find(e => e.name.includes('Squat')) || exercises[1];
  const deadlift = exercises.find(e => e.name.includes('Deadlift')) || exercises[2];
  const ohp = exercises.find(e => e.name.includes('Overhead Press')) || exercises[3];
  const row = exercises.find(e => e.name.includes('Row')) || exercises[4];

  if (!bench || !squat || !deadlift) return;

  // 2. Prepare 4 weeks of structured workouts (3 sessions per week = 12 workouts)
  const baseDate = new Date();
  baseDate.setDate(baseDate.getDate() - 28); // 4 weeks ago

  const workoutsToAdd: Workout[] = [];
  const weToAdd: WorkoutExercise[] = [];
  const setsToAdd: Set[] = [];

  // Session definitions with progressive overload
  // Week 1 to 4 progression
  for (let week = 0; week < 4; week++) {
    const wDelta = week * 2.5; // +2.5kg per week progression

    // Workout A: Squat + Bench Press (Day 1 of week)
    const dateA = new Date(baseDate);
    dateA.setDate(baseDate.getDate() + week * 7);
    const dateAStr = dateA.toISOString().split('T')[0];
    const wAId = `benchmark-w-a-${week}`;

    workoutsToAdd.push({
      id: wAId,
      name: `Heavy Lower / Upper (Wk ${week + 1})`,
      date: dateAStr,
      startTime: `${dateAStr}T09:00:00.000Z`,
      endTime: `${dateAStr}T10:15:00.000Z`,
      completed: true,
      notes: `Week ${week + 1} session. Felt strong, good bar speed.`
    });

    // Squat WE & sets
    const weSquatId = `benchmark-we-sq-${week}`;
    weToAdd.push({ id: weSquatId, workoutId: wAId, exerciseId: squat.id, order: 0 });
    setsToAdd.push(
      { id: `s-sq-${week}-1`, workoutExerciseId: weSquatId, weight: 100 + wDelta, reps: 5, rpe: 7, completed: true, order: 0 },
      { id: `s-sq-${week}-2`, workoutExerciseId: weSquatId, weight: 100 + wDelta, reps: 5, rpe: 8, completed: true, order: 1 },
      { id: `s-sq-${week}-3`, workoutExerciseId: weSquatId, weight: 100 + wDelta, reps: 5 + (week === 3 ? 1 : 0), rpe: 9, completed: true, order: 2 }
    );

    // Bench WE & sets
    const weBenchId = `benchmark-we-bp-${week}`;
    weToAdd.push({ id: weBenchId, workoutId: wAId, exerciseId: bench.id, order: 1 });
    setsToAdd.push(
      { id: `s-bp-${week}-1`, workoutExerciseId: weBenchId, weight: 80 + wDelta, reps: 5, rpe: 7, completed: true, order: 0 },
      { id: `s-bp-${week}-2`, workoutExerciseId: weBenchId, weight: 80 + wDelta, reps: 5, rpe: 8, completed: true, order: 1 },
      { id: `s-bp-${week}-3`, workoutExerciseId: weBenchId, weight: 80 + wDelta, reps: 5 + (week >= 2 ? 1 : 0), rpe: 9, completed: true, order: 2 }
    );

    // Workout B: Deadlift + OHP + Row (Day 3 of week)
    const dateB = new Date(baseDate);
    dateB.setDate(baseDate.getDate() + week * 7 + 2);
    const dateBStr = dateB.toISOString().split('T')[0];
    const wBId = `benchmark-w-b-${week}`;

    workoutsToAdd.push({
      id: wBId,
      name: `Deadlift & Posterior Chain (Wk ${week + 1})`,
      date: dateBStr,
      startTime: `${dateBStr}T17:30:00.000Z`,
      endTime: `${dateBStr}T18:40:00.000Z`,
      completed: true,
      notes: `Deadlift volume was dialed in.`
    });

    // Deadlift
    const weDlId = `benchmark-we-dl-${week}`;
    weToAdd.push({ id: weDlId, workoutId: wBId, exerciseId: deadlift.id, order: 0 });
    setsToAdd.push(
      { id: `s-dl-${week}-1`, workoutExerciseId: weDlId, weight: 130 + wDelta * 2, reps: 4, rpe: 8, completed: true, order: 0 },
      { id: `s-dl-${week}-2`, workoutExerciseId: weDlId, weight: 130 + wDelta * 2, reps: 4, rpe: 8.5, completed: true, order: 1 }
    );

    // OHP
    if (ohp) {
      const weOhpId = `benchmark-we-ohp-${week}`;
      weToAdd.push({ id: weOhpId, workoutId: wBId, exerciseId: ohp.id, order: 1 });
      setsToAdd.push(
        { id: `s-ohp-${week}-1`, workoutExerciseId: weOhpId, weight: 50 + wDelta, reps: 6, rpe: 7.5, completed: true, order: 0 },
        { id: `s-ohp-${week}-2`, workoutExerciseId: weOhpId, weight: 50 + wDelta, reps: 6, rpe: 8.5, completed: true, order: 1 }
      );
    }

    // Row
    if (row) {
      const weRowId = `benchmark-we-row-${week}`;
      weToAdd.push({ id: weRowId, workoutId: wBId, exerciseId: row.id, order: 2 });
      setsToAdd.push(
        { id: `s-row-${week}-1`, workoutExerciseId: weRowId, weight: 70 + wDelta, reps: 8, rpe: 8, completed: true, order: 0 },
        { id: `s-row-${week}-2`, workoutExerciseId: weRowId, weight: 70 + wDelta, reps: 8, rpe: 8, completed: true, order: 1 }
      );
    }
  }

  // 3. Body Weights (28 days of daily weigh-ins with natural variance)
  const bodyWeightsToAdd: BodyWeight[] = [];
  const baseWeight = 83.5;
  for (let d = 0; d < 28; d++) {
    const curDate = new Date(baseDate);
    curDate.setDate(baseDate.getDate() + d);
    const dateStr = curDate.toISOString().split('T')[0];

    // Downward trend with daily water weight variance
    const progressLoss = (d / 28) * 1.8; // -1.8kg over 4 weeks
    const variance = (Math.sin(d * 1.3) * 0.35);
    const weight = Math.round((baseWeight - progressLoss + variance) * 10) / 10;

    bodyWeightsToAdd.push({
      id: `benchmark-bw-${d}`,
      date: dateStr,
      weight,
      notes: d % 7 === 0 ? 'Weekly check-in morning fasted' : undefined
    });
  }

  // 4. Measurements (Day 0, Day 14, Day 28)
  const measurementsToAdd: Measurement[] = [
    // Baseline Day 0
    { id: 'benchmark-m-w-0', type: 'waist', value: 87.5, unit: 'cm', date: workoutsToAdd[0].date, notes: 'Morning fasted' },
    { id: 'benchmark-m-c-0', type: 'chest', value: 104.0, unit: 'cm', date: workoutsToAdd[0].date },
    { id: 'benchmark-m-a-0', type: 'arms', value: 38.2, unit: 'cm', date: workoutsToAdd[0].date },
    { id: 'benchmark-m-t-0', type: 'thighs', value: 61.5, unit: 'cm', date: workoutsToAdd[0].date },

    // Midpoint Day 14
    { id: 'benchmark-m-w-14', type: 'waist', value: 86.0, unit: 'cm', date: workoutsToAdd[4].date, notes: 'Midpoint re-test' },
    { id: 'benchmark-m-c-14', type: 'chest', value: 104.5, unit: 'cm', date: workoutsToAdd[4].date },
    { id: 'benchmark-m-a-14', type: 'arms', value: 38.5, unit: 'cm', date: workoutsToAdd[4].date },
    { id: 'benchmark-m-t-14', type: 'thighs', value: 62.0, unit: 'cm', date: workoutsToAdd[4].date },

    // Latest Day 28
    { id: 'benchmark-m-w-28', type: 'waist', value: 84.8, unit: 'cm', date: workoutsToAdd[workoutsToAdd.length - 1].date, notes: 'End of 4-week block' },
    { id: 'benchmark-m-c-28', type: 'chest', value: 105.2, unit: 'cm', date: workoutsToAdd[workoutsToAdd.length - 1].date },
    { id: 'benchmark-m-a-28', type: 'arms', value: 38.8, unit: 'cm', date: workoutsToAdd[workoutsToAdd.length - 1].date },
    { id: 'benchmark-m-t-28', type: 'thighs', value: 62.4, unit: 'cm', date: workoutsToAdd[workoutsToAdd.length - 1].date }
  ];

  // 5. Progress Photos (Private by default)
  // Generate high-contrast clean SVG silhouettes as Data URLs
  const createSilhouetteDataUrl = (pose: string, label: string) => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="500" viewBox="0 0 400 500">
      <rect width="400" height="500" fill="#111111"/>
      <rect x="20" y="20" width="360" height="460" fill="none" stroke="#5B7CFF" stroke-width="2" stroke-dasharray="6,6"/>
      <circle cx="200" cy="110" r="45" fill="#F7F4ED"/>
      <path d="M 140 180 Q 200 170 260 180 L 250 310 L 225 450 L 175 450 L 150 310 Z" fill="#F7F4ED"/>
      <text x="200" y="30" fill="#5B7CFF" font-family="monospace" font-size="14" text-anchor="middle" font-weight="bold">ONSE FIT PRIVATE VAULT</text>
      <text x="200" y="470" fill="#F7F4ED" font-family="monospace" font-size="12" text-anchor="middle">${pose.toUpperCase()} POSE — ${label}</text>
    </svg>`;
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  };

  const day0Date = workoutsToAdd[0].date;
  const day28Date = workoutsToAdd[workoutsToAdd.length - 1].date;

  const photosToAdd: ProgressPhoto[] = [
    {
      id: 'benchmark-photo-1',
      date: day0Date,
      pose: 'front',
      photoUrl: createSilhouetteDataUrl('front', 'WEEK 1 BASELINE'),
      weightAtTime: 83.5,
      notes: 'Day 1 baseline photo. Morning fasted.',
      isPrivate: true, // Private by default
      isShared: false
    },
    {
      id: 'benchmark-photo-2',
      date: day0Date,
      pose: 'side',
      photoUrl: createSilhouetteDataUrl('side', 'WEEK 1 PROFILE'),
      weightAtTime: 83.5,
      notes: 'Day 1 side profile.',
      isPrivate: true,
      isShared: false
    },
    {
      id: 'benchmark-photo-3',
      date: day28Date,
      pose: 'front',
      photoUrl: createSilhouetteDataUrl('front', 'WEEK 4 CHECK-IN'),
      weightAtTime: 81.7,
      notes: 'Week 4 front pose. Visible core definition improvement.',
      isPrivate: true,
      isShared: false
    },
    {
      id: 'benchmark-photo-4',
      date: day28Date,
      pose: 'back',
      photoUrl: createSilhouetteDataUrl('back', 'WEEK 4 LAT SPREAD'),
      weightAtTime: 81.7,
      notes: 'Week 4 back pose. Lat width noticeable from pull-ups.',
      isPrivate: true,
      isShared: false
    }
  ];

  // 6. Sleep and Recovery Entries (28 days)
  const sleepEntriesToAdd: any[] = [];
  const recoveryEntriesToAdd: any[] = [];
  const workoutDatesSet = new Set(workoutsToAdd.filter(w => w.completed).map(w => w.date));

  for (let d = 0; d < 28; d++) {
    const curDate = new Date(baseDate);
    curDate.setDate(baseDate.getDate() + d);
    const dateStr = curDate.toISOString().split('T')[0];

    // Sleep duration between 6.8 and 8.3 hours (408 to 498 minutes)
    const sleepDuration = Math.round((7.2 + Math.sin(d * 0.9) * 0.7) * 60);
    const quality = sleepDuration >= 450 ? 4 : (sleepDuration >= 420 ? 3 : 2);

    sleepEntriesToAdd.push({
      id: `benchmark-sleep-${d}`,
      date: dateStr,
      durationMinutes: sleepDuration,
      quality,
      notes: d % 7 === 0 ? 'Rest day sleep check' : undefined
    });

    // Recovery: soreness higher on day after heavy workouts
    const prevDate = new Date(curDate);
    prevDate.setDate(curDate.getDate() - 1);
    const prevDateStr = prevDate.toISOString().split('T')[0];
    const hadWorkoutYesterday = workoutDatesSet.has(prevDateStr);

    const soreness = hadWorkoutYesterday ? (d > 14 ? 3 : 4) : 2;
    const energy = sleepDuration >= 440 ? 4 : 3;

    recoveryEntriesToAdd.push({
      id: `benchmark-rec-${d}`,
      date: dateStr,
      soreness,
      energy,
      stress: 2,
      rating: energy
    });
  }

  // 7. Add 1 uncompleted scheduled workout in the past to test missed workouts detection
  const missedDate = new Date(baseDate);
  missedDate.setDate(baseDate.getDate() + 11);
  const missedDateStr = missedDate.toISOString().split('T')[0];
  workoutsToAdd.push({
    id: 'benchmark-w-missed-1',
    name: 'Scheduled Conditioning & Core',
    date: missedDateStr,
    completed: false,
    notes: 'Planned session missed due to travel schedule.'
  });

  // 8. Benchmark Habits & Logs
  const habit1Id = 'benchmark-habit-1';
  const habit2Id = 'benchmark-habit-2';
  const habit3Id = 'benchmark-habit-3';

  const habitsToAdd = [
    { id: habit1Id, name: 'Creatine 5g', createdAt: workoutsToAdd[0].date + 'T08:00:00.000Z' },
    { id: habit2Id, name: 'Protein Target 160g', createdAt: workoutsToAdd[0].date + 'T08:00:00.000Z' },
    { id: habit3Id, name: 'Hydration 3L', createdAt: workoutsToAdd[0].date + 'T08:00:00.000Z' }
  ];

  const habitLogsToAdd: any[] = [];
  for (let d = 0; d < 28; d++) {
    const curDate = new Date(baseDate);
    curDate.setDate(baseDate.getDate() + d);
    const dateStr = curDate.toISOString().split('T')[0];

    habitLogsToAdd.push(
      { id: `benchmark-hl-1-${d}`, habitId: habit1Id, date: dateStr, completed: d % 7 !== 6 },
      { id: `benchmark-hl-2-${d}`, habitId: habit2Id, date: dateStr, completed: d % 5 !== 0 },
      { id: `benchmark-hl-3-${d}`, habitId: habit3Id, date: dateStr, completed: true }
    );
  }

  // 9. Benchmark Journal Notes
  const notesToAdd = [
    {
      id: 'benchmark-note-1',
      date: workoutsToAdd[0].date,
      type: 'training' as const,
      content: 'Felt explosive on barbell bench today. Arch was tight and bar path felt natural. Shoulder felt 100% stable.'
    },
    {
      id: 'benchmark-note-2',
      date: workoutsToAdd[4].date,
      type: 'lifestyle' as const,
      content: 'Sleep duration improved to 7.8h. Morning resting energy felt significantly higher.'
    },
    {
      id: 'benchmark-note-3',
      date: workoutsToAdd[8].date,
      type: 'training' as const,
      content: 'Squats felt heavy on warmups but hit all planned working sets with RPE 8. Added pause work on final set.'
    },
    {
      id: 'benchmark-note-4',
      date: workoutsToAdd[12].date,
      type: 'general' as const,
      content: 'End of 4-week benchmark block. Consistent training cadence maintained. Ready for reload phase.'
    }
  ];

  // Bulk add to database
  await db.transaction(
    'rw', 
    [db.workouts, db.workoutExercises, db.sets, db.bodyWeights, db.measurements, db.progressPhotos, db.sleepEntries, db.recoveryEntries, db.habits, db.habitLogs, db.notes], 
    async () => {
      await db.workouts.bulkPut(workoutsToAdd);
      await db.workoutExercises.bulkPut(weToAdd);
      await db.sets.bulkPut(setsToAdd);
      await db.bodyWeights.bulkPut(bodyWeightsToAdd);
      await db.measurements.bulkPut(measurementsToAdd);
      await db.progressPhotos.bulkPut(photosToAdd);
      await db.sleepEntries.bulkPut(sleepEntriesToAdd);
      await db.recoveryEntries.bulkPut(recoveryEntriesToAdd);
      await db.habits.bulkPut(habitsToAdd);
      await db.habitLogs.bulkPut(habitLogsToAdd);
      await db.notes.bulkPut(notesToAdd);
    }
  );
}

export async function clearBenchmarkData() {
  await db.transaction(
    'rw', 
    [db.workouts, db.workoutExercises, db.sets, db.bodyWeights, db.measurements, db.progressPhotos, db.sleepEntries, db.recoveryEntries, db.habits, db.habitLogs, db.notes], 
    async () => {
      // Delete items with 'benchmark-' prefix
      const allWorkouts = await db.workouts.toArray();
      const benchmarkWIds = allWorkouts.filter(w => w.id.startsWith('benchmark-')).map(w => w.id);
      await db.workouts.bulkDelete(benchmarkWIds);

      const allWE = await db.workoutExercises.toArray();
      const benchmarkWEIds = allWE.filter(we => we.id.startsWith('benchmark-') || benchmarkWIds.includes(we.workoutId)).map(we => we.id);
      await db.workoutExercises.bulkDelete(benchmarkWEIds);

      const allSets = await db.sets.toArray();
      const benchmarkSetIds = allSets.filter(s => s.id.startsWith('s-') || benchmarkWEIds.includes(s.workoutExerciseId)).map(s => s.id);
      await db.sets.bulkDelete(benchmarkSetIds);

      const allBW = await db.bodyWeights.toArray();
      const benchmarkBWIds = allBW.filter(b => b.id.startsWith('benchmark-')).map(b => b.id);
      await db.bodyWeights.bulkDelete(benchmarkBWIds);

      const allM = await db.measurements.toArray();
      const benchmarkMIds = allM.filter(m => m.id.startsWith('benchmark-')).map(m => m.id);
      await db.measurements.bulkDelete(benchmarkMIds);

      const allPhotos = await db.progressPhotos.toArray();
      const benchmarkPhotoIds = allPhotos.filter(p => p.id.startsWith('benchmark-')).map(p => p.id);
      await db.progressPhotos.bulkDelete(benchmarkPhotoIds);

      const allSleep = await db.sleepEntries.toArray();
      const benchmarkSleepIds = allSleep.filter(s => s.id.startsWith('benchmark-')).map(s => s.id);
      await db.sleepEntries.bulkDelete(benchmarkSleepIds);

      const allRecovery = await db.recoveryEntries.toArray();
      const benchmarkRecIds = allRecovery.filter(r => r.id.startsWith('benchmark-')).map(r => r.id);
      await db.recoveryEntries.bulkDelete(benchmarkRecIds);

      const allHabits = await db.habits.toArray();
      const benchmarkHabitIds = allHabits.filter(h => h.id.startsWith('benchmark-')).map(h => h.id);
      await db.habits.bulkDelete(benchmarkHabitIds);

      const allHabitLogs = await db.habitLogs.toArray();
      const benchmarkHLIds = allHabitLogs.filter(hl => hl.id.startsWith('benchmark-') || benchmarkHabitIds.includes(hl.habitId)).map(hl => hl.id);
      await db.habitLogs.bulkDelete(benchmarkHLIds);

      const allNotes = await db.notes.toArray();
      const benchmarkNoteIds = allNotes.filter(n => n.id.startsWith('benchmark-')).map(n => n.id);
      await db.notes.bulkDelete(benchmarkNoteIds);
    }
  );
}
