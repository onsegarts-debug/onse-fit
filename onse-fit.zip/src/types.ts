/**
 * ONSE FIT
 * Global Types Definition
 */

export type Theme = 'light' | 'dark' | 'system';

export interface Profile {
  id: string;
  name: string;
  goal: string;
  currentProgramId?: string;
  trainingStreak: number;
  bodyWeight?: number;
}

export interface Program {
  id: string;
  name: string;
  description?: string;
  createdAt: string; // ISO Date string
  spotifyPlaylistId?: string;
  spotifyPlaylistName?: string;
  spotifyPlaylistUri?: string;
}

export interface Workout {
  id: string;
  programId?: string;
  name: string;
  date: string; // YYYY-MM-DD
  startTime?: string; // ISO string
  endTime?: string; // ISO string
  notes?: string;
  completed: boolean;
  spotifyPlaylistId?: string;
  spotifyPlaylistName?: string;
  spotifyPlaylistUri?: string;
}

export interface Exercise {
  id: string;
  name: string;
  targetMuscle: string;
  category: string; // chest, back, shoulders, etc.
  isArchived: boolean;
}

export interface WorkoutExercise {
  id: string;
  workoutId: string;
  exerciseId: string;
  order: number;
  notes?: string;
}

export interface Set {
  id: string;
  workoutExerciseId: string;
  weight: number;
  reps: number;
  rpe?: number;
  completed: boolean;
  order: number;
}

export interface PersonalRecord {
  id: string;
  exerciseId: string;
  workoutId?: string;
  type: 'weight' | 'reps' | 'volume' | 'estimated1RM';
  value: number;
  reps?: number;
  weight?: number;
  date: string; // YYYY-MM-DD
  notes?: string;
}

export interface BodyWeight {
  id: string;
  weight: number;
  date: string; // YYYY-MM-DD
  notes?: string;
}

export interface Measurement {
  id: string;
  type: string; // waist, chest, arms, thighs, hips, shoulders, neck, calves
  value: number;
  unit: string;
  date: string; // YYYY-MM-DD
  notes?: string;
}

export interface ProgressPhoto {
  id: string;
  date: string; // YYYY-MM-DD
  pose: 'front' | 'side' | 'back' | 'other';
  photoUrl: string; // Base64 data URL
  weightAtTime?: number;
  notes?: string;
  isPrivate: boolean; // default true - photos must remain private unless explicitly shared
  isShared?: boolean; // explicitly shared flag
}

export interface SleepEntry {
  id: string;
  date: string; // YYYY-MM-DD
  bedtime?: string; // ISO string
  wakeTime?: string; // ISO string
  durationMinutes?: number;
  quality?: number; // 1-5
  notes?: string;
}

export interface Habit {
  id: string;
  name: string;
  createdAt: string; // ISO string
}

export interface HabitLog {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  completed: boolean;
}

export interface RecoveryEntry {
  id: string;
  date: string; // YYYY-MM-DD
  soreness: number; // 1-5
  energy: number; // 1-5
  stress: number; // 1-5
  rating: number; // 1-5
  notes?: string;
}

export interface Note {
  id: string;
  date: string; // YYYY-MM-DD
  content: string;
  type: 'general' | 'training' | 'lifestyle';
}

export interface Reminder {
  id: string;
  title: string;
  time: string; // HH:mm
  isActive: boolean;
}

export interface AppSetting {
  key: string;
  value: any;
}

export type SpotifyConnectionStatus = 
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'auth_required'
  | 'permission_denied'
  | 'network_unavailable'
  | 'spotify_unavailable'
  | 'auth_failed';

export interface SpotifyUserProfile {
  id: string;
  displayName: string;
  email?: string;
  product?: string; // 'premium' | 'free'
  imageUrl?: string;
  uri?: string;
  externalUrl?: string;
}

export interface SpotifyPlaylist {
  id: string;
  name: string;
  description?: string;
  uri: string;
  externalUrl: string;
  imageUrl?: string;
  tracksTotal: number;
  ownerName?: string;
}

export interface SpotifyTokens {
  accessToken: string;
  refreshToken?: string;
  expiresIn: number;
  expiresAt: number; // epoch ms
  scope?: string;
  tokenType?: string;
}

export interface SpotifyAssociation {
  id: string; // `${type}_${targetId}`
  type: 'workout' | 'program' | 'day';
  targetId: string; // workoutId, programId, or 'YYYY-MM-DD'
  playlistId: string;
  playlistName: string;
  playlistUri: string;
  updatedAt: string;
}

// ONSENSEI Assistant Types
export type OnsenseiRole = 'user' | 'assistant' | 'system';

export interface OnsenseiMessage {
  id: string;
  conversationId: string;
  role: OnsenseiRole;
  content: string;
  timestamp: string; // ISO string
  status?: 'sending' | 'sent' | 'error';
  error?: string;
  provider?: string;
  model?: string;
}

export interface OnsenseiConversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
}

