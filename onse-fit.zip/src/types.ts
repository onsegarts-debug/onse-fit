/**
 * ONSE FIT
 * Global Types Definition
 */

export type Theme = 'light' | 'dark' | 'system';

export interface Profile {
  id: string;
  name: string;
  goal: string;
  currentProgramId?: string;
  trainingStreak: number;
  bodyWeight?: number;
}

export interface Program {
  id: string;
  name: string;
  description?: string;
  createdAt: string; // ISO Date string
}

export interface Workout {
  id: string;
  programId?: string;
  name: string;
  date: string; // YYYY-MM-DD
  startTime?: string; // ISO string
  endTime?: string; // ISO string
  notes?: string;
  completed: boolean;
}

export interface Exercise {
  id: string;
  name: string;
  targetMuscle: string;
  category: string; // chest, back, shoulders, etc.
  isArchived: boolean;
}

export interface WorkoutExercise {
  id: string;
  workoutId: string;
  exerciseId: string;
  order: number;
  notes?: string;
}

export interface Set {
  id: string;
  workoutExerciseId: string;
  weight: number;
  reps: number;
  rpe?: number;
  completed: boolean;
  order: number;
}

export interface PersonalRecord {
  id: string;
  exerciseId: string;
  workoutId?: string;
  type: 'weight' | 'reps' | 'volume' | 'estimated1RM';
  value: number;
  date: string; // YYYY-MM-DD
}

export interface BodyWeight {
  id: string;
  weight: number;
  date: string; // YYYY-MM-DD
}

export interface Measurement {
  id: string;
  type: string; // waist, chest, arms, etc.
  value: number;
  unit: string;
  date: string; // YYYY-MM-DD
}

export interface SleepEntry {
  id: string;
  date: string; // YYYY-MM-DD
  bedtime?: string; // ISO string
  wakeTime?: string; // ISO string
  durationMinutes?: number;
  quality?: number; // 1-5
  notes?: string;
}

export interface Habit {
  id: string;
  name: string;
  createdAt: string; // ISO string
}

export interface HabitLog {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  completed: boolean;
}

export interface RecoveryEntry {
  id: string;
  date: string; // YYYY-MM-DD
  soreness: number; // 1-5
  energy: number; // 1-5
  stress: number; // 1-5
  rating: number; // 1-5
  notes?: string;
}

export interface Note {
  id: string;
  date: string; // YYYY-MM-DD
  content: string;
  type: 'general' | 'training' | 'lifestyle';
}

export interface Reminder {
  id: string;
  title: string;
  time: string; // HH:mm
  isActive: boolean;
}

export interface AppSetting {
  key: string;
  value: any;
}

