/**
 * ONSE FIT
 * Theme tokens
 */

export const colors = {
  primary: '#F7F4ED',
  secondary: '#111111',
  accent1: '#5B7CFF',
  accent2: '#FFB833',
};

export const typography = {
  primary: 'Space Grotesk, sans-serif',
  accent: 'Space Mono, monospace',
};
