/**
 * ONSE FIT
 * Application Entry Root
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppShell } from './components/layout/AppShell';
import { Training } from './pages/Training';
import { Calendar } from './pages/Calendar';
import { Lifestyle } from './pages/Lifestyle';
import { Progress } from './pages/Progress';
import { Smart } from './pages/Smart';
import { Profile } from './pages/Profile';
import { WorkoutSession } from './pages/training/WorkoutSession';
import { SpotifyIntegration } from './pages/profile/SpotifyIntegration';
import { SpotifyCallback } from './pages/SpotifyCallback';
import { SpotifyProvider } from './lib/spotify/SpotifyContext';
import { OnsenseiProvider } from './lib/onsensei/OnsenseiContext';
import { FloatingOnsenseiButton } from './components/onsensei/FloatingOnsenseiButton';
import { OnsenseiChatModal } from './components/onsensei/OnsenseiChatModal';

export default function App() {
  return (
    <SpotifyProvider>
      <OnsenseiProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<AppShell />}>
              <Route index element={<Training />} />
              <Route path="calendar" element={<Calendar />} />
              <Route path="lifestyle" element={<Lifestyle />} />
              <Route path="progress" element={<Progress />} />
              <Route path="smart" element={<Smart />} />
              <Route path="profile" element={<Profile />} />
              <Route path="profile/integrations/spotify" element={<SpotifyIntegration />} />
            </Route>
            <Route path="/training/workout/:id" element={<WorkoutSession />} />
            <Route path="/callback/spotify" element={<SpotifyCallback />} />
            <Route path="/auth/callback" element={<SpotifyCallback />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>

          {/* Global ONSENSEI Assistant Layer */}
          <FloatingOnsenseiButton />
          <OnsenseiChatModal />
        </BrowserRouter>
      </OnsenseiProvider>
    </SpotifyProvider>
  );
}
