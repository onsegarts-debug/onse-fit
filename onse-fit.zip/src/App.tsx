/**
 * ONSE FIT
 * Application Entry Root
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppShell } from './components/layout/AppShell';
import { Training } from './pages/Training';
import { Lifestyle } from './pages/Lifestyle';
import { Progress } from './pages/Progress';
import { Smart } from './pages/Smart';
import { Profile } from './pages/Profile';
import { WorkoutSession } from './pages/training/WorkoutSession';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppShell />}>
          <Route index element={<Training />} />
          <Route path="lifestyle" element={<Lifestyle />} />
          <Route path="progress" element={<Progress />} />
          <Route path="smart" element={<Smart />} />
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="/training/workout/:id" element={<WorkoutSession />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
