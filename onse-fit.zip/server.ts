import express from "express";
import http from "http";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const httpServer = http.createServer(app);
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy-initialized Gemini client
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return genAIClient;
}

// Health check
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

// ONSENSEI Provider Status
app.get("/api/onsensei/status", (_req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  const isConfigured = Boolean(apiKey && apiKey.trim() !== "" && apiKey !== "MY_GEMINI_API_KEY");
  res.json({
    configured: isConfigured,
    provider: "Gemini",
    model: "gemini-3.8-flash",
  });
});

// Helper for backoff delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Helper: Call Gemini with safe retry and exponential backoff
async function generateWithRetry(
  ai: GoogleGenAI,
  contents: any[],
  systemInstruction: string
): Promise<{ text: string; model: string }> {
  // Primary model and fallback models according to official @google/genai guidelines
  const modelsToTry = ["gemini-3.8-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
  const maxAttemptsPerModel = 2;

  let lastError: any = null;

  for (const model of modelsToTry) {
    for (let attempt = 1; attempt <= maxAttemptsPerModel; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        const text = response?.text?.trim();
        if (text && text.length > 0) {
          return { text, model };
        }

        // Empty text received
        console.warn(`[ONSENSEI] Received empty text from ${model} (attempt ${attempt}/${maxAttemptsPerModel})`);
        lastError = new Error("Empty response received from AI provider.");
        lastError.code = "EMPTY_RESPONSE";
      } catch (err: any) {
        lastError = err;
        const errMsg = String(err?.message || "");
        const rawStatus = err?.status || err?.statusCode || err?.code;

        const isTransient =
          rawStatus === 503 ||
          rawStatus === "UNAVAILABLE" ||
          rawStatus === 429 ||
          rawStatus === "RESOURCE_EXHAUSTED" ||
          errMsg.includes("503") ||
          errMsg.includes("UNAVAILABLE") ||
          errMsg.includes("high demand") ||
          errMsg.includes("overloaded") ||
          errMsg.includes("rate limit") ||
          errMsg.includes("timeout") ||
          errMsg.includes("ECONNRESET");

        if (!isTransient) {
          // If it's a non-transient error (e.g. invalid arguments/auth), throw immediately
          throw err;
        }

        console.warn(
          `[ONSENSEI] Transient provider failure on ${model} (attempt ${attempt}/${maxAttemptsPerModel}):`,
          errMsg
        );

        // Exponential backoff with jitter: attempt 1 -> ~800-1000ms
        if (attempt < maxAttemptsPerModel) {
          const backoff = 800 * Math.pow(2, attempt - 1) + Math.random() * 200;
          await delay(backoff);
        }
      }
    }
  }

  throw lastError;
}

// ONSENSEI Chat Completion
app.post("/api/onsensei/chat", async (req, res) => {
  try {
    const { messages, context } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Missing or invalid messages array." });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: "GEMINI_API_KEY is not configured in the server environment. Please configure it in AI Studio Settings.",
        code: "UNCONFIGURED",
      });
    }

    const hasFitnessContext = Boolean(context && typeof context === "string" && context.trim().length > 0);

    const systemInstruction = `
You are ONSENSEI, a general-purpose AI assistant AND the disciplined personal strength and fitness advisor inside ONSE FIT.

Capabilities:
1. General Conversational AI:
   - You can answer ANY question across all domains: programming, computer science, mathematics, science, writing, brainstorming, study questions, history, everyday topics, and general exercise science.
   - Do NOT restrict yourself to ONSE FIT or fitness topics. If the user asks a general question, answer thoroughly, intelligently, and clearly with high analytical precision.
   - For general fitness questions that do not require personal logs, provide evidence-based principles directly.

2. Personal ONSE FIT Training Advisor:
   - When the user asks about their personal workouts, routines, progress, personal records (PRs), streak, sleep, recovery, or habits, reference their authenticated ONSE FIT logbook data provided below.
   - Strict Data Integrity: Always reference their authentic logged exercises, sets, reps, weights, and dates. If the user asks about a personal session or metric that is NOT in their logbook data, state clearly that it has not been logged yet in their ONSE FIT logbook. Never fabricate or assume personal numbers.

3. Combined Intelligence:
   - When a question connects general knowledge with personal logs (e.g., explaining progressive overload mechanics and applying it to their specific bench press sets from today), seamlessly integrate scientific theory with their personal logged numbers.

Aesthetic & Tone:
- Neo-brutalist discipline, high clarity, concise, direct, evidence-based, and objective.
- Avoid generic filler, sycophantic praise, or ungrounded claims.
- Format responses cleanly using markdown bullet points, bold key stats, and short structured paragraphs.

${hasFitnessContext ? `[RELEVANT ONSE FIT LOGBOOK DATA]\n${context}` : "[No personal ONSE FIT logbook context required for this general request.]"}
`.trim();

    // Map conversation messages to Gemini format
    const contents = messages
      .filter((m: any) => m && m.content && typeof m.content === "string")
      .map((m: any) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      }));

    if (contents.length === 0) {
      return res.status(400).json({ error: "No valid message content provided." });
    }

    // Call with safe retry & exponential backoff
    const { text: outputText, model: usedModel } = await generateWithRetry(
      ai,
      contents,
      systemInstruction
    );

    if (!outputText) {
      return res.status(502).json({
        error: "Empty response received from AI provider. Please retry your question.",
        code: "EMPTY_RESPONSE",
      });
    }

    return res.json({
      content: outputText,
      provider: "Gemini",
      model: usedModel,
    });
  } catch (error: any) {
    console.error("[ONSENSEI] generation error caught safely:", error?.message || error);

    let httpStatus = 500;
    let errorCode = "PROVIDER_ERROR";
    let userMessage = "An unexpected error occurred while consulting ONSENSEI.";

    const errorMsg = String(error?.message || "");
    const rawStatus = error?.status || error?.statusCode || error?.code;

    if (
      rawStatus === 503 ||
      rawStatus === "UNAVAILABLE" ||
      errorMsg.includes("503") ||
      errorMsg.includes("UNAVAILABLE") ||
      errorMsg.includes("high demand") ||
      errorMsg.includes("overloaded")
    ) {
      httpStatus = 503;
      errorCode = "HIGH_DEMAND";
      userMessage = "ONSENSEI is currently experiencing high demand. Please try again in a few moments.";
    } else if (
      rawStatus === 429 ||
      rawStatus === "RESOURCE_EXHAUSTED" ||
      errorMsg.includes("429") ||
      errorMsg.includes("quota") ||
      errorMsg.includes("rate limit")
    ) {
      httpStatus = 429;
      errorCode = "RATE_LIMIT";
      userMessage = "Rate limit reached. Please wait a few moments before trying again.";
    } else if (
      rawStatus === 401 ||
      rawStatus === 403 ||
      rawStatus === "PERMISSION_DENIED" ||
      rawStatus === "UNAUTHENTICATED"
    ) {
      httpStatus = 401;
      errorCode = "AUTH_ERROR";
      userMessage = "API key configuration error. Please verify GEMINI_API_KEY in AI Studio Settings.";
    } else if (
      errorMsg.includes("Empty response") ||
      rawStatus === "EMPTY_RESPONSE"
    ) {
      httpStatus = 502;
      errorCode = "EMPTY_RESPONSE";
      userMessage = "Empty response received from AI provider. Please retry your question.";
    } else if (
      errorMsg.includes("timeout") ||
      errorMsg.includes("timed out") ||
      rawStatus === "DEADLINE_EXCEEDED"
    ) {
      httpStatus = 504;
      errorCode = "TIMEOUT";
      userMessage = "Request timed out. ONSENSEI took too long to respond.";
    }

    return res.status(httpStatus).json({
      error: userMessage,
      code: errorCode,
      details: process.env.NODE_ENV !== "production" ? errorMsg : undefined,
    });
  }
});

// Vite middleware for development vs Static serving for production
async function startServer() {
  const isHmrDisabled = process.env.DISABLE_HMR === "true";

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
        watch: isHmrDisabled ? null : undefined,
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
